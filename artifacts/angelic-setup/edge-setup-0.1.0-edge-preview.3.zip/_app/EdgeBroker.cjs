"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// src/automation/edge-cdp-pipe.js
var require_edge_cdp_pipe = __commonJS({
  "src/automation/edge-cdp-pipe.js"(exports2, module2) {
    "use strict";
    var fault = (code) => Object.assign(new Error(code), { code });
    function createChromePipe(chrome, { origin = "https://x.com", timeoutMs = 1e4, includeApplicationServerKey = false, browserMode = "chrome", calibration = false } = {}) {
      if (!chrome?.stdio?.[3] || !chrome?.stdio?.[4] || typeof origin !== "string" || typeof includeApplicationServerKey !== "boolean" || typeof calibration !== "boolean" || !["chrome", "edge"].includes(browserMode) || !Number.isSafeInteger(timeoutMs) || timeoutMs < 100 || timeoutMs > 6e4 || origin !== "https://x.com" && !/^http:\/\/127\.0\.0\.1:[1-9][0-9]{0,4}$/.test(origin)) throw fault("X_CHROME_PIPE_INVALID");
      if (calibration) {
        try {
          if (browserMode !== "edge" || origin === "https://x.com" || new URL(origin).origin !== origin) throw new Error();
        } catch {
          throw fault("X_CHROME_PIPE_INVALID");
        }
      }
      const input = chrome.stdio[3], output = chrome.stdio[4], waiting = /* @__PURE__ */ new Map();
      let sequence = 0, buffer = Buffer.alloc(0), failed = false;
      function abort() {
        if (failed) return;
        failed = true;
        for (const item of waiting.values()) {
          clearTimeout(item.timer);
          item.reject(fault("X_CHROME_PIPE_CLOSED"));
        }
        waiting.clear();
      }
      output.on("data", (chunk) => {
        if (failed) return;
        if (!Buffer.isBuffer(chunk) || buffer.length + chunk.length > 1024 * 1024) {
          abort();
          return;
        }
        buffer = Buffer.concat([buffer, chunk]);
        for (; ; ) {
          const end = buffer.indexOf(0);
          if (end < 0) break;
          const frame = buffer.subarray(0, end);
          buffer = buffer.subarray(end + 1);
          try {
            const message = JSON.parse(frame.toString("utf8"));
            if (!Number.isSafeInteger(message.id) || !waiting.has(message.id)) continue;
            const item = waiting.get(message.id);
            waiting.delete(message.id);
            clearTimeout(item.timer);
            if (message.error || !message.result) item.reject(fault("X_CHROME_PIPE_COMMAND_FAILED"));
            else item.resolve(message.result);
          } catch {
            abort();
            return;
          }
        }
      });
      output.on("error", abort);
      output.on("end", abort);
      input.on("error", abort);
      chrome.on("error", abort);
      chrome.on("exit", abort);
      function call(method, params = {}, sessionId) {
        if (failed || waiting.size >= 4 || sequence >= Number.MAX_SAFE_INTEGER) return Promise.reject(fault("X_CHROME_PIPE_CLOSED"));
        const id = ++sequence, data = Buffer.from(JSON.stringify({ id, method, params, ...sessionId ? { sessionId } : {} }) + "\0");
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            waiting.delete(id);
            reject(fault("X_CHROME_PIPE_TIMEOUT"));
          }, timeoutMs);
          waiting.set(id, { resolve, reject, timer });
          try {
            input.write(data, (error) => {
              if (error) abort();
            });
          } catch {
            abort();
          }
        });
      }
      async function ready() {
        const version = await call("Browser.getVersion");
        const pattern = browserMode === "edge" ? /^Edg\/[0-9]{1,3}(?:\.[0-9]{1,5}){3}$/ : /^Chrome\/[0-9]{1,3}(?:\.[0-9]{1,5}){3}$/;
        if (typeof version.product !== "string" || !pattern.test(version.product)) throw fault("X_CHROME_PIPE_INVALID");
        return version.product.slice(version.product.indexOf("/") + 1);
      }
      async function capture() {
        const result = await call("Target.getTargets");
        if (!Array.isArray(result.targetInfos) || result.targetInfos.length > 256) throw fault("X_CHROME_CAPTURE_INVALID");
        const matches = result.targetInfos.filter((target) => {
          try {
            return target && target.type === "page" && new URL(target.url).origin === origin;
          } catch {
            return false;
          }
        });
        if (!matches.length) throw fault("X_CHROME_CAPTURE_NOT_FOUND");
        if (matches.length > 8 || new Set(matches.map((target) => target.browserContextId || "")).size !== 1 || matches.some((target) => typeof target.targetId !== "string" || !target.targetId || target.targetId.length > 256) || new Set(matches.map((target) => target.targetId)).size !== matches.length) throw fault("X_CHROME_CAPTURE_AMBIGUOUS");
        const captureTarget = async (target) => {
          const attached = await call("Target.attachToTarget", { targetId: target.targetId, flatten: true });
          if (typeof attached.sessionId !== "string" || attached.sessionId.length > 256) throw fault("X_CHROME_CAPTURE_INVALID");
          try {
            const expression = `(async()=>{if(location.origin!==${JSON.stringify(origin)})throw Error('origin');const found=[];for(const r of await navigator.serviceWorker.getRegistrations()){if(new URL(r.scope).origin!==${JSON.stringify(origin)})continue;const s=await r.pushManager.getSubscription();if(s){const v={scope:r.scope,...s.toJSON()};` + (includeApplicationServerKey ? `const k=s.options?.applicationServerKey;if(!k||k.byteLength!==65)throw Error('key');v.applicationServerKey=btoa(String.fromCharCode(...new Uint8Array(k))).replace(/\\+/g,'-').replace(/\\//g,'_').replace(/=+$/,'');` : "") + `found.push(v);}}if(location.origin!==${JSON.stringify(origin)}||found.length!==1)throw Error('subscription');return found[0]})()`;
            const response = await call("Runtime.evaluate", { expression, awaitPromise: true, returnByValue: true }, attached.sessionId);
            const value = response.result?.value;
            if (response.exceptionDetails || response.result?.type !== "object" || !value || typeof value.scope !== "string" || typeof value.endpoint !== "string" || value.scope.length > 4096 || value.endpoint.length > 4096 || !value.keys || typeof value.keys.p256dh !== "string" || typeof value.keys.auth !== "string" || includeApplicationServerKey && (typeof value.applicationServerKey !== "string" || !/^[A-Za-z0-9_-]{87}$/.test(value.applicationServerKey) || Buffer.from(value.applicationServerKey, "base64url").toString("base64url") !== value.applicationServerKey)) throw fault("X_CHROME_CAPTURE_INVALID");
            return {
              scope: value.scope,
              endpoint: value.endpoint,
              keys: { p256dh: value.keys.p256dh, auth: value.keys.auth },
              ...includeApplicationServerKey ? { applicationServerKey: value.applicationServerKey } : {}
            };
          } finally {
            await call("Target.detachFromTarget", { sessionId: attached.sessionId }).catch(() => {
            });
          }
        };
        let selected;
        for (const target of matches) {
          let value;
          try {
            value = await captureTarget(target);
          } catch (error) {
            if (matches.length > 1) throw fault("X_CHROME_CAPTURE_AMBIGUOUS");
            throw error;
          }
          if (selected && (value.scope !== selected.scope || value.endpoint !== selected.endpoint || value.keys.p256dh !== selected.keys.p256dh || value.keys.auth !== selected.keys.auth || includeApplicationServerKey && value.applicationServerKey !== selected.applicationServerKey))
            throw fault("X_CHROME_CAPTURE_AMBIGUOUS");
          selected = value;
        }
        return selected;
      }
      async function closeBrowser() {
        if (chrome.exitCode !== null) return;
        const exited = new Promise((resolve) => chrome.once("exit", resolve));
        await call("Browser.close").catch(() => {
        });
        let timer;
        try {
          await Promise.race([exited, new Promise((_resolve, reject) => {
            timer = setTimeout(() => reject(fault("X_CHROME_CAPTURE_TIMEOUT")), 15e3);
          })]);
        } finally {
          clearTimeout(timer);
        }
      }
      async function prepareCalibration(applicationServerKey) {
        if (!calibration || typeof applicationServerKey !== "string" || !/^[A-Za-z0-9_-]{87}$/.test(applicationServerKey)) throw fault("X_CHROME_PIPE_INVALID");
        const key = Buffer.from(applicationServerKey, "base64url");
        try {
          if (key.length !== 65 || key.toString("base64url") !== applicationServerKey || key[0] !== 4) throw fault("X_CHROME_PIPE_INVALID");
          require("node:crypto").ECDH.convertKey(key, "prime256v1", void 0, void 0, "uncompressed");
        } catch {
          throw fault("X_CHROME_PIPE_INVALID");
        } finally {
          key.fill(0);
        }
        await call("Browser.grantPermissions", { origin, permissions: ["notifications"] });
        const target = await call("Target.createTarget", { url: "about:blank" });
        if (typeof target.targetId !== "string" || !target.targetId || target.targetId.length > 256) throw fault("X_CHROME_PIPE_INVALID");
        const attached = await call("Target.attachToTarget", { targetId: target.targetId, flatten: true });
        if (typeof attached.sessionId !== "string" || !attached.sessionId || attached.sessionId.length > 256) throw fault("X_CHROME_PIPE_INVALID");
        try {
          await call("Page.enable", {}, attached.sessionId);
          await call("Page.navigate", { url: `${origin}/` }, attached.sessionId);
          const deadline = Date.now() + timeoutMs;
          let loaded = false;
          while (Date.now() < deadline) {
            const state = await call("Runtime.evaluate", { expression: "location.origin", returnByValue: true }, attached.sessionId);
            if (state.result?.value === origin) {
              loaded = true;
              break;
            }
            await new Promise((resolve) => setTimeout(resolve, 100));
          }
          if (!loaded) throw fault("X_CHROME_PIPE_TIMEOUT");
          const expression = `(async()=>{if(location.origin!==${JSON.stringify(origin)})throw Error('origin');const v=${JSON.stringify(applicationServerKey)}.replace(/-/g,'+').replace(/_/g,'/');const key=Uint8Array.from(atob(v),c=>c.charCodeAt(0));const r=await navigator.serviceWorker.register('/sw.js');await navigator.serviceWorker.ready;const s=await r.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:key});return Boolean(s&&s.endpoint)})()`;
          const response = await call("Runtime.evaluate", { expression, awaitPromise: true, returnByValue: true }, attached.sessionId);
          if (response.exceptionDetails || response.result?.value !== true) throw fault("X_CHROME_PIPE_INVALID");
          return true;
        } finally {
          await call("Target.detachFromTarget", { sessionId: attached.sessionId }).catch(() => {
          });
        }
      }
      return { ready, capture, closeBrowser, ...calibration ? { prepareCalibration } : {} };
    }
    module2.exports = { createChromePipe };
  }
});

// src/automation/strict-json.js
var require_strict_json = __commonJS({
  "src/automation/strict-json.js"(exports2, module2) {
    "use strict";
    function parseUniqueJson2(source, maxDepth = 12) {
      const reject = () => {
        throw new Error("INVALID_JSON");
      };
      if (typeof source !== "string" || !Number.isInteger(maxDepth) || maxDepth < 1 || maxDepth > 64) reject();
      let offset = 0;
      const stringToken = /"(?:[^"\\\u0000-\u001f]|\\(?:["\\/bfnrt]|u[0-9a-fA-F]{4}))*"/y;
      const numberToken = /-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/y;
      const whitespace = () => {
        while (offset < source.length && /[ \t\r\n]/.test(source[offset])) offset++;
      };
      function readString() {
        stringToken.lastIndex = offset;
        const match = stringToken.exec(source);
        if (!match) reject();
        offset = stringToken.lastIndex;
        return JSON.parse(match[0]);
      }
      function value(depth) {
        if (depth > maxDepth) reject();
        whitespace();
        if (source[offset] === "{") {
          offset++;
          whitespace();
          const names = /* @__PURE__ */ new Set();
          if (source[offset] === "}") {
            offset++;
            return;
          }
          while (true) {
            whitespace();
            const name = readString();
            if (names.has(name) || ["__proto__", "prototype", "constructor"].includes(name)) reject();
            names.add(name);
            whitespace();
            if (source[offset++] !== ":") reject();
            value(depth + 1);
            whitespace();
            const next = source[offset++];
            if (next === "}") return;
            if (next !== ",") reject();
          }
        }
        if (source[offset] === "[") {
          offset++;
          whitespace();
          if (source[offset] === "]") {
            offset++;
            return;
          }
          while (true) {
            value(depth + 1);
            whitespace();
            const next = source[offset++];
            if (next === "]") return;
            if (next !== ",") reject();
          }
        }
        if (source[offset] === '"') {
          readString();
          return;
        }
        for (const literal of ["true", "false", "null"]) {
          if (source.startsWith(literal, offset)) {
            offset += literal.length;
            return;
          }
        }
        numberToken.lastIndex = offset;
        if (!numberToken.exec(source)) reject();
        offset = numberToken.lastIndex;
      }
      value(0);
      whitespace();
      if (offset !== source.length) reject();
      return JSON.parse(source);
    }
    module2.exports = { parseUniqueJson: parseUniqueJson2 };
  }
});

// src/automation/edge-private-broker.js
var require_edge_private_broker = __commonJS({
  "src/automation/edge-private-broker.js"(exports2, module2) {
    "use strict";
    var net = require("node:net");
    var { spawn } = require("node:child_process");
    var { randomBytes, timingSafeEqual } = require("node:crypto");
    var { createChromePipe } = require_edge_cdp_pipe();
    var { parseUniqueJson: parseUniqueJson2 } = require_strict_json();
    var fault = (code) => Object.assign(new Error(code), { code });
    async function startChromeBroker2({ chromePath, profilePath, origin = "https://x.com", extraArgs = [], spawnChrome = spawn, includeApplicationServerKey = false, browserMode = "chrome" }) {
      if (typeof chromePath !== "string" || typeof profilePath !== "string" || typeof spawnChrome !== "function" || !Array.isArray(extraArgs) || extraArgs.some((arg) => typeof arg !== "string") || typeof includeApplicationServerKey !== "boolean" || !["chrome", "edge"].includes(browserMode) || browserMode === "edge" && !includeApplicationServerKey || origin !== "https://x.com" && !/^http:\/\/127\.0\.0\.1:[1-9][0-9]{0,4}$/.test(origin)) throw fault("X_CHROME_BROKER_INVALID");
      const token = randomBytes(32), chrome = spawnChrome(
        chromePath,
        [
          "--remote-debugging-pipe",
          ...browserMode === "chrome" ? ["--gcm-mcs-endpoint=https://127.0.0.1:1", "--host-resolver-rules=MAP mtalk.google.com ~NOTFOUND"] : [],
          `--user-data-dir=${profilePath}`,
          "--no-first-run",
          "--no-default-browser-check",
          ...extraArgs,
          `${origin}/`
        ],
        { windowsHide: false, stdio: ["ignore", "ignore", "ignore", "pipe", "pipe"] }
      );
      const pipe = createChromePipe(chrome, { origin, includeApplicationServerKey, browserMode });
      let engineVersion;
      try {
        engineVersion = await pipe.ready();
      } catch (error) {
        if (chrome.exitCode === null) chrome.kill();
        throw error;
      }
      let busy = false, stopped = false;
      const clients = /* @__PURE__ */ new Set();
      const server = net.createServer((socket) => {
        if (stopped || clients.size >= 8 || socket.remoteAddress !== "127.0.0.1") {
          socket.destroy();
          return;
        }
        clients.add(socket);
        socket.setTimeout(5e3, () => socket.destroy());
        let data = Buffer.alloc(0), handled = false;
        socket.on("close", () => clients.delete(socket));
        socket.on("error", () => socket.destroy());
        socket.on("data", (chunk) => {
          if (handled || !Buffer.isBuffer(chunk) || data.length + chunk.length > 4096) {
            socket.destroy();
            return;
          }
          data = Buffer.concat([data, chunk]);
          const end = data.indexOf(10);
          if (end < 0) return;
          handled = true;
          if (end !== data.length - 1) {
            socket.destroy();
            return;
          }
          let input;
          try {
            input = parseUniqueJson2(data.subarray(0, end).toString("utf8"));
          } catch {
            socket.destroy();
            return;
          }
          if (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).sort().join(",") !== "command,token" || input.command !== "capture" || typeof input.token !== "string" || !/^[0-9a-f]{64}$/.test(input.token) || !timingSafeEqual(Buffer.from(input.token, "hex"), token)) {
            socket.destroy();
            return;
          }
          if (busy) {
            socket.end(JSON.stringify({ ok: false, errorCode: "X_CHROME_CAPTURE_BUSY" }) + "\n");
            return;
          }
          busy = true;
          socket.setTimeout(3e4, () => socket.destroy());
          Promise.resolve().then(async () => {
            const subscription = await pipe.capture();
            if (socket.destroyed) {
              busy = false;
              return;
            }
            await pipe.closeBrowser();
            if (socket.destroyed) {
              busy = false;
              await stop();
              return;
            }
            socket.once("finish", () => {
              void stop();
            });
            socket.end(JSON.stringify({ ok: true, subscription }) + "\n");
          }).catch((error) => {
            const code = /^X_CHROME_CAPTURE_[A-Z_]+$/.test(String(error?.code || "")) ? error.code : "X_CHROME_CAPTURE_UNAVAILABLE";
            socket.end(JSON.stringify({ ok: false, errorCode: code }) + "\n");
            busy = false;
            if (chrome.exitCode !== null) void stop();
          });
        });
      });
      async function stop() {
        if (stopped) return;
        stopped = true;
        token.fill(0);
        for (const client of clients) client.destroy();
        await new Promise((resolve) => server.close(resolve));
      }
      chrome.once("exit", () => {
        if (!busy) void stop();
      });
      try {
        await new Promise((resolve, reject) => {
          server.once("error", reject);
          server.listen({ port: 0, host: "127.0.0.1" }, () => resolve(void 0));
        });
      } catch (error) {
        if (chrome.exitCode === null) chrome.kill();
        throw error;
      }
      if (chrome.exitCode !== null) {
        await stop();
        throw fault("X_CHROME_BROKER_INVALID");
      }
      const address = server.address();
      if (!address || typeof address === "string") {
        await stop();
        if (chrome.exitCode === null) chrome.kill();
        throw fault("X_CHROME_BROKER_INVALID");
      }
      return { port: address.port, token: token.toString("hex"), pid: process.pid, browserPid: chrome.pid, engineVersion, stop, chrome };
    }
    module2.exports = { startChromeBroker: startChromeBroker2 };
  }
});

// scripts/edge-setup-broker.cjs
var { startChromeBroker } = require_edge_private_broker();
var { parseUniqueJson } = require_strict_json();
async function main() {
  let length = 0;
  const chunks = [];
  let combined;
  try {
    for await (const chunk of process.stdin) {
      length += chunk.length;
      if (length > 8192) throw new Error();
      chunks.push(chunk);
    }
    combined = Buffer.concat(chunks);
    const input = parseUniqueJson(combined.toString("utf8"));
    if (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).sort().join(",") !== "edgePath,profilePath") throw new Error();
    const broker = await startChromeBroker({ chromePath: input.edgePath, profilePath: input.profilePath, browserMode: "edge", includeApplicationServerKey: true });
    process.stdout.write(JSON.stringify({ ok: true, port: broker.port, token: broker.token, pid: broker.pid, browserPid: broker.browserPid, engineVersion: broker.engineVersion }) + "\n");
  } finally {
    combined?.fill(0);
    for (const chunk of chunks) chunk.fill(0);
  }
}
main().catch(() => {
  process.stdout.write('{"ok":false,"errorCode":"X_EDGE_BROKER_FAILED"}\n');
  process.exitCode = 1;
});
