"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// src/automation/strict-json.js
var require_strict_json = __commonJS({
  "src/automation/strict-json.js"(exports2, module2) {
    "use strict";
    function parseUniqueJson2(source, maxDepth = 12) {
      const reject = () => {
        throw new Error("INVALID_JSON");
      };
      if (typeof source !== "string" || !Number.isInteger(maxDepth) || maxDepth < 1 || maxDepth > 64) reject();
      let offset = 0;
      const stringToken = /"(?:[^"\\\u0000-\u001f]|\\(?:["\\/bfnrt]|u[0-9a-fA-F]{4}))*"/y;
      const numberToken = /-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/y;
      const whitespace = () => {
        while (offset < source.length && /[ \t\r\n]/.test(source[offset])) offset++;
      };
      function readString() {
        stringToken.lastIndex = offset;
        const match = stringToken.exec(source);
        if (!match) reject();
        offset = stringToken.lastIndex;
        return JSON.parse(match[0]);
      }
      function value(depth) {
        if (depth > maxDepth) reject();
        whitespace();
        if (source[offset] === "{") {
          offset++;
          whitespace();
          const names = /* @__PURE__ */ new Set();
          if (source[offset] === "}") {
            offset++;
            return;
          }
          while (true) {
            whitespace();
            const name = readString();
            if (names.has(name) || ["__proto__", "prototype", "constructor"].includes(name)) reject();
            names.add(name);
            whitespace();
            if (source[offset++] !== ":") reject();
            value(depth + 1);
            whitespace();
            const next = source[offset++];
            if (next === "}") return;
            if (next !== ",") reject();
          }
        }
        if (source[offset] === "[") {
          offset++;
          whitespace();
          if (source[offset] === "]") {
            offset++;
            return;
          }
          while (true) {
            value(depth + 1);
            whitespace();
            const next = source[offset++];
            if (next === "]") return;
            if (next !== ",") reject();
          }
        }
        if (source[offset] === '"') {
          readString();
          return;
        }
        for (const literal of ["true", "false", "null"]) {
          if (source.startsWith(literal, offset)) {
            offset += literal.length;
            return;
          }
        }
        numberToken.lastIndex = offset;
        if (!numberToken.exec(source)) reject();
        offset = numberToken.lastIndex;
      }
      value(0);
      whitespace();
      if (offset !== source.length) reject();
      return JSON.parse(source);
    }
    module2.exports = { parseUniqueJson: parseUniqueJson2 };
  }
});

// src/automation/chrome-broker-client.js
var require_chrome_broker_client = __commonJS({
  "src/automation/chrome-broker-client.js"(exports2, module2) {
    "use strict";
    var net = require("node:net");
    var { parseUniqueJson: parseUniqueJson2 } = require_strict_json();
    var fault = (code) => Object.assign(new Error(code), { code });
    async function captureFromBroker2({ port, token }) {
      if (!Number.isInteger(port) || port < 1024 || port > 65535 || typeof token !== "string" || !/^[0-9a-f]{64}$/.test(token))
        throw fault("X_CHROME_CAPTURE_INVALID");
      return new Promise((resolve, reject) => {
        const socket = net.connect({ host: "127.0.0.1", port });
        let done = false, data = Buffer.alloc(0);
        const timer = setTimeout(() => finish(fault("X_CHROME_CAPTURE_TIMEOUT")), 3e4);
        function finish(error, result) {
          if (done) return;
          done = true;
          clearTimeout(timer);
          socket.destroy();
          if (error) reject(error);
          else resolve(result);
        }
        socket.on("connect", () => socket.write(JSON.stringify({ command: "capture", token }) + "\n"));
        socket.on("data", (chunk) => {
          if (!Buffer.isBuffer(chunk) || data.length + chunk.length > 65536) {
            finish(fault("X_CHROME_CAPTURE_INVALID"));
            return;
          }
          data = Buffer.concat([data, chunk]);
          const end = data.indexOf(10);
          if (end < 0) return;
          if (end !== data.length - 1) {
            finish(fault("X_CHROME_CAPTURE_INVALID"));
            return;
          }
          try {
            const response = parseUniqueJson2(data.subarray(0, end).toString("utf8"));
            if (response.ok !== true) {
              const code = /^X_CHROME_CAPTURE_[A-Z_]+$/.test(String(response.errorCode || "")) ? response.errorCode : "X_CHROME_CAPTURE_UNAVAILABLE";
              finish(fault(code));
              return;
            }
            const value = response.subscription;
            if (!value || typeof value.scope !== "string" || typeof value.endpoint !== "string" || !value.keys || typeof value.keys.p256dh !== "string" || typeof value.keys.auth !== "string") throw new Error();
            finish(null, { scope: value.scope, endpoint: value.endpoint, keys: { p256dh: value.keys.p256dh, auth: value.keys.auth } });
          } catch {
            finish(fault("X_CHROME_CAPTURE_INVALID"));
          }
        });
        socket.on("error", () => finish(fault("X_CHROME_CAPTURE_UNAVAILABLE")));
        socket.on("close", () => {
          if (!done) finish(fault("X_CHROME_CAPTURE_UNAVAILABLE"));
        });
      });
    }
    module2.exports = { captureFromBroker: captureFromBroker2 };
  }
});

// scripts/chrome-setup-capture.cjs
var { captureFromBroker } = require_chrome_broker_client();
var { parseUniqueJson } = require_strict_json();
async function main() {
  const chunks = [];
  let size = 0;
  for await (const chunk of process.stdin) {
    size += chunk.length;
    if (size > 4096) throw new Error("X_CHROME_CAPTURE_INVALID");
    chunks.push(chunk);
  }
  const input = parseUniqueJson(Buffer.concat(chunks).toString("utf8"));
  if (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).sort().join(",") !== "port,token")
    throw new Error("X_CHROME_CAPTURE_INVALID");
  const subscription = await captureFromBroker(input);
  process.stdout.write(JSON.stringify({ ok: true, subscription }));
}
main().catch((error) => {
  const code = /^X_CHROME_CAPTURE_[A-Z_]+$/.test(String(error?.code || error?.message || "")) ? String(error.code || error.message) : "X_CHROME_CAPTURE_INVALID";
  process.stdout.write(JSON.stringify({ ok: false, errorCode: code }));
  process.exitCode = 1;
});
