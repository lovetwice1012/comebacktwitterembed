"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// node_modules/level-supports/index.js
var require_level_supports = __commonJS({
  "node_modules/level-supports/index.js"(exports2) {
    "use strict";
    exports2.supports = function supports(...manifests) {
      const manifest = manifests.reduce((acc, m) => Object.assign(acc, m), {});
      const implicitSnapshots = manifest.implicitSnapshots || manifest.snapshots || false;
      const explicitSnapshots = manifest.explicitSnapshots || false;
      return Object.assign(manifest, {
        implicitSnapshots,
        explicitSnapshots,
        snapshots: implicitSnapshots,
        has: manifest.has || false,
        permanence: manifest.permanence || false,
        seek: manifest.seek || false,
        createIfMissing: manifest.createIfMissing || false,
        errorIfExists: manifest.errorIfExists || false,
        deferredOpen: manifest.deferredOpen || false,
        streams: manifest.streams || false,
        encodings: Object.assign({}, manifest.encodings),
        events: Object.assign({}, manifest.events),
        additionalMethods: Object.assign({}, manifest.additionalMethods),
        signals: Object.assign({}, manifest.signals)
      });
    };
  }
});

// node_modules/module-error/index.js
var require_module_error = __commonJS({
  "node_modules/module-error/index.js"(exports2, module2) {
    "use strict";
    module2.exports = class ModuleError extends Error {
      /**
       * @param {string} message Error message
       * @param {{ code?: string, cause?: Error, expected?: boolean, transient?: boolean }} [options]
       */
      constructor(message, options) {
        super(message || "");
        if (typeof options === "object" && options !== null) {
          if (options.code) this.code = String(options.code);
          if (options.expected) this.expected = true;
          if (options.transient) this.transient = true;
          if (options.cause) this.cause = options.cause;
        }
        if (Error.captureStackTrace) {
          Error.captureStackTrace(this, this.constructor);
        }
      }
    };
  }
});

// node_modules/level-transcoder/lib/text-endec.js
var require_text_endec = __commonJS({
  "node_modules/level-transcoder/lib/text-endec.js"(exports2, module2) {
    "use strict";
    var lazy = null;
    module2.exports = function() {
      if (lazy === null) {
        lazy = {
          textEncoder: new TextEncoder(),
          textDecoder: new TextDecoder()
        };
      }
      return lazy;
    };
  }
});

// node_modules/level-transcoder/lib/encoding.js
var require_encoding = __commonJS({
  "node_modules/level-transcoder/lib/encoding.js"(exports2) {
    "use strict";
    var ModuleError = require_module_error();
    var formats = /* @__PURE__ */ new Set(["buffer", "view", "utf8"]);
    var Encoding = class {
      /**
       * @param {IEncoding<TIn,TFormat,TOut>} options
       */
      constructor(options) {
        this.encode = options.encode || this.encode;
        this.decode = options.decode || this.decode;
        this.name = options.name || this.name;
        this.format = options.format || this.format;
        if (typeof this.encode !== "function") {
          throw new TypeError("The 'encode' property must be a function");
        }
        if (typeof this.decode !== "function") {
          throw new TypeError("The 'decode' property must be a function");
        }
        this.encode = this.encode.bind(this);
        this.decode = this.decode.bind(this);
        if (typeof this.name !== "string" || this.name === "") {
          throw new TypeError("The 'name' property must be a string");
        }
        if (typeof this.format !== "string" || !formats.has(this.format)) {
          throw new TypeError("The 'format' property must be one of 'buffer', 'view', 'utf8'");
        }
        if (options.createViewTranscoder) {
          this.createViewTranscoder = options.createViewTranscoder;
        }
        if (options.createBufferTranscoder) {
          this.createBufferTranscoder = options.createBufferTranscoder;
        }
        if (options.createUTF8Transcoder) {
          this.createUTF8Transcoder = options.createUTF8Transcoder;
        }
      }
      get commonName() {
        return (
          /** @type {string} */
          this.name.split("+")[0]
        );
      }
      /** @return {BufferFormat<TIn,TOut>} */
      createBufferTranscoder() {
        throw new ModuleError(`Encoding '${this.name}' cannot be transcoded to 'buffer'`, {
          code: "LEVEL_ENCODING_NOT_SUPPORTED"
        });
      }
      /** @return {ViewFormat<TIn,TOut>} */
      createViewTranscoder() {
        throw new ModuleError(`Encoding '${this.name}' cannot be transcoded to 'view'`, {
          code: "LEVEL_ENCODING_NOT_SUPPORTED"
        });
      }
      /** @return {UTF8Format<TIn,TOut>} */
      createUTF8Transcoder() {
        throw new ModuleError(`Encoding '${this.name}' cannot be transcoded to 'utf8'`, {
          code: "LEVEL_ENCODING_NOT_SUPPORTED"
        });
      }
    };
    exports2.Encoding = Encoding;
  }
});

// node_modules/level-transcoder/lib/formats.js
var require_formats = __commonJS({
  "node_modules/level-transcoder/lib/formats.js"(exports2) {
    "use strict";
    var { Buffer: Buffer2 } = require("buffer") || {};
    var { Encoding } = require_encoding();
    var textEndec = require_text_endec();
    var BufferFormat = class extends Encoding {
      /**
       * @param {Omit<IEncoding<TIn, Buffer, TOut>, 'format'>} options
       */
      constructor(options) {
        super({ ...options, format: "buffer" });
      }
      /** @override */
      createViewTranscoder() {
        return new ViewFormat({
          encode: this.encode,
          // Buffer is a view (UInt8Array)
          decode: (data) => this.decode(
            Buffer2.from(data.buffer, data.byteOffset, data.byteLength)
          ),
          name: `${this.name}+view`
        });
      }
      /** @override */
      createBufferTranscoder() {
        return this;
      }
    };
    var ViewFormat = class extends Encoding {
      /**
       * @param {Omit<IEncoding<TIn, Uint8Array, TOut>, 'format'>} options
       */
      constructor(options) {
        super({ ...options, format: "view" });
      }
      /** @override */
      createBufferTranscoder() {
        return new BufferFormat({
          encode: (data) => {
            const view = this.encode(data);
            return Buffer2.from(view.buffer, view.byteOffset, view.byteLength);
          },
          decode: this.decode,
          // Buffer is a view (UInt8Array)
          name: `${this.name}+buffer`
        });
      }
      /** @override */
      createViewTranscoder() {
        return this;
      }
    };
    var UTF8Format = class extends Encoding {
      /**
       * @param {Omit<IEncoding<TIn, string, TOut>, 'format'>} options
       */
      constructor(options) {
        super({ ...options, format: "utf8" });
      }
      /** @override */
      createBufferTranscoder() {
        return new BufferFormat({
          encode: (data) => Buffer2.from(this.encode(data), "utf8"),
          decode: (data) => this.decode(data.toString("utf8")),
          name: `${this.name}+buffer`
        });
      }
      /** @override */
      createViewTranscoder() {
        const { textEncoder, textDecoder } = textEndec();
        return new ViewFormat({
          encode: (data) => textEncoder.encode(this.encode(data)),
          decode: (data) => this.decode(textDecoder.decode(data)),
          name: `${this.name}+view`
        });
      }
      /** @override */
      createUTF8Transcoder() {
        return this;
      }
    };
    exports2.BufferFormat = BufferFormat;
    exports2.ViewFormat = ViewFormat;
    exports2.UTF8Format = UTF8Format;
  }
});

// node_modules/level-transcoder/lib/encodings.js
var require_encodings = __commonJS({
  "node_modules/level-transcoder/lib/encodings.js"(exports2) {
    "use strict";
    var { Buffer: Buffer2 } = require("buffer") || { Buffer: { isBuffer: () => false } };
    var { textEncoder, textDecoder } = require_text_endec()();
    var { BufferFormat, ViewFormat, UTF8Format } = require_formats();
    var identity = (v) => v;
    exports2.utf8 = new UTF8Format({
      encode: function(data) {
        return Buffer2.isBuffer(data) ? data.toString("utf8") : ArrayBuffer.isView(data) ? textDecoder.decode(data) : String(data);
      },
      decode: identity,
      name: "utf8",
      createViewTranscoder() {
        return new ViewFormat({
          encode: function(data) {
            return ArrayBuffer.isView(data) ? data : textEncoder.encode(data);
          },
          decode: function(data) {
            return textDecoder.decode(data);
          },
          name: `${this.name}+view`
        });
      },
      createBufferTranscoder() {
        return new BufferFormat({
          encode: function(data) {
            return Buffer2.isBuffer(data) ? data : ArrayBuffer.isView(data) ? Buffer2.from(data.buffer, data.byteOffset, data.byteLength) : Buffer2.from(String(data), "utf8");
          },
          decode: function(data) {
            return data.toString("utf8");
          },
          name: `${this.name}+buffer`
        });
      }
    });
    exports2.json = new UTF8Format({
      encode: JSON.stringify,
      decode: JSON.parse,
      name: "json"
    });
    exports2.buffer = new BufferFormat({
      encode: function(data) {
        return Buffer2.isBuffer(data) ? data : ArrayBuffer.isView(data) ? Buffer2.from(data.buffer, data.byteOffset, data.byteLength) : Buffer2.from(String(data), "utf8");
      },
      decode: identity,
      name: "buffer",
      createViewTranscoder() {
        return new ViewFormat({
          encode: function(data) {
            return ArrayBuffer.isView(data) ? data : Buffer2.from(String(data), "utf8");
          },
          decode: function(data) {
            return Buffer2.from(data.buffer, data.byteOffset, data.byteLength);
          },
          name: `${this.name}+view`
        });
      }
    });
    exports2.view = new ViewFormat({
      encode: function(data) {
        return ArrayBuffer.isView(data) ? data : textEncoder.encode(data);
      },
      decode: identity,
      name: "view",
      createBufferTranscoder() {
        return new BufferFormat({
          encode: function(data) {
            return Buffer2.isBuffer(data) ? data : ArrayBuffer.isView(data) ? Buffer2.from(data.buffer, data.byteOffset, data.byteLength) : Buffer2.from(String(data), "utf8");
          },
          decode: identity,
          name: `${this.name}+buffer`
        });
      }
    });
    exports2.hex = new BufferFormat({
      encode: function(data) {
        return Buffer2.isBuffer(data) ? data : Buffer2.from(String(data), "hex");
      },
      decode: function(buffer) {
        return buffer.toString("hex");
      },
      name: "hex"
    });
    exports2.base64 = new BufferFormat({
      encode: function(data) {
        return Buffer2.isBuffer(data) ? data : Buffer2.from(String(data), "base64");
      },
      decode: function(buffer) {
        return buffer.toString("base64");
      },
      name: "base64"
    });
  }
});

// node_modules/level-transcoder/index.js
var require_level_transcoder = __commonJS({
  "node_modules/level-transcoder/index.js"(exports2) {
    "use strict";
    var ModuleError = require_module_error();
    var encodings = require_encodings();
    var { Encoding } = require_encoding();
    var { BufferFormat, ViewFormat, UTF8Format } = require_formats();
    var kFormats = /* @__PURE__ */ Symbol("formats");
    var kEncodings = /* @__PURE__ */ Symbol("encodings");
    var validFormats = /* @__PURE__ */ new Set(["buffer", "view", "utf8"]);
    var Transcoder = class {
      /**
       * @param {Array<'buffer'|'view'|'utf8'>} formats
       */
      constructor(formats) {
        if (!Array.isArray(formats)) {
          throw new TypeError("The first argument 'formats' must be an array");
        } else if (!formats.every((f) => validFormats.has(f))) {
          throw new TypeError("Format must be one of 'buffer', 'view', 'utf8'");
        }
        this[kEncodings] = /* @__PURE__ */ new Map();
        this[kFormats] = new Set(formats);
        for (const k in encodings) {
          try {
            this.encoding(k);
          } catch (err) {
            if (err.code !== "LEVEL_ENCODING_NOT_SUPPORTED") throw err;
          }
        }
      }
      /**
       * @returns {Array<Encoding<any,T,any>>}
       */
      encodings() {
        return Array.from(new Set(this[kEncodings].values()));
      }
      /**
       * @param {string|MixedEncoding<any, any, any>} encoding
       * @returns {Encoding<any, T, any>}
       */
      encoding(encoding) {
        let resolved = this[kEncodings].get(encoding);
        if (resolved === void 0) {
          if (typeof encoding === "string" && encoding !== "") {
            resolved = lookup[encoding];
            if (!resolved) {
              throw new ModuleError(`Encoding '${encoding}' is not found`, {
                code: "LEVEL_ENCODING_NOT_FOUND"
              });
            }
          } else if (typeof encoding !== "object" || encoding === null) {
            throw new TypeError("First argument 'encoding' must be a string or object");
          } else {
            resolved = from(encoding);
          }
          const { name, format } = resolved;
          if (!this[kFormats].has(format)) {
            if (this[kFormats].has("view")) {
              resolved = resolved.createViewTranscoder();
            } else if (this[kFormats].has("buffer")) {
              resolved = resolved.createBufferTranscoder();
            } else if (this[kFormats].has("utf8")) {
              resolved = resolved.createUTF8Transcoder();
            } else {
              throw new ModuleError(`Encoding '${name}' cannot be transcoded`, {
                code: "LEVEL_ENCODING_NOT_SUPPORTED"
              });
            }
          }
          for (const k of [encoding, name, resolved.name, resolved.commonName]) {
            this[kEncodings].set(k, resolved);
          }
        }
        return resolved;
      }
    };
    exports2.Transcoder = Transcoder;
    function from(options) {
      if (options instanceof Encoding) {
        return options;
      }
      const maybeType = "type" in options && typeof options.type === "string" ? options.type : void 0;
      const name = options.name || maybeType || `anonymous-${anonymousCount++}`;
      switch (detectFormat(options)) {
        case "view":
          return new ViewFormat({ ...options, name });
        case "utf8":
          return new UTF8Format({ ...options, name });
        case "buffer":
          return new BufferFormat({ ...options, name });
        default: {
          throw new TypeError("Format must be one of 'buffer', 'view', 'utf8'");
        }
      }
    }
    function detectFormat(options) {
      if ("format" in options && options.format !== void 0) {
        return options.format;
      } else if ("buffer" in options && typeof options.buffer === "boolean") {
        return options.buffer ? "buffer" : "utf8";
      } else if ("code" in options && Number.isInteger(options.code)) {
        return "view";
      } else {
        return "buffer";
      }
    }
    var aliases = {
      binary: encodings.buffer,
      "utf-8": encodings.utf8
    };
    var lookup = {
      ...encodings,
      ...aliases
    };
    var anonymousCount = 0;
  }
});

// node_modules/maybe-combine-errors/index.js
var require_maybe_combine_errors = __commonJS({
  "node_modules/maybe-combine-errors/index.js"(exports2, module2) {
    "use strict";
    var kErrors = /* @__PURE__ */ Symbol("kErrors");
    module2.exports = function(errors) {
      errors = errors.filter(defined);
      if (errors.length === 0) return;
      if (errors.length === 1) return errors[0];
      return new CombinedError(errors);
    };
    var CombinedError = class extends Error {
      constructor(errors) {
        const unique = new Set(errors.map(getMessage).filter(Boolean));
        const message = Array.from(unique).join("; ");
        super(message);
        value(this, "name", "CombinedError");
        value(this, kErrors, errors);
        getter(this, "stack", () => errors.map(getStack).join("\n\n"));
        getter(this, "transient", () => errors.length > 0 && errors.every(transient));
        getter(this, "expected", () => errors.length > 0 && errors.every(expected));
      }
      [Symbol.iterator]() {
        return this[kErrors][Symbol.iterator]();
      }
    };
    function value(obj, prop, value2) {
      Object.defineProperty(obj, prop, { value: value2 });
    }
    function getter(obj, prop, get) {
      Object.defineProperty(obj, prop, { get });
    }
    function defined(err) {
      return err != null;
    }
    function getMessage(err) {
      return err.message;
    }
    function getStack(err) {
      return err.stack;
    }
    function transient(err) {
      return err.transient === true;
    }
    function expected(err) {
      return err.expected === true;
    }
  }
});

// node_modules/abstract-level/lib/common.js
var require_common = __commonJS({
  "node_modules/abstract-level/lib/common.js"(exports2) {
    "use strict";
    var ModuleError = require_module_error();
    var deprecations = /* @__PURE__ */ new Set();
    exports2.getOptions = function(options, def) {
      if (typeof options === "object" && options !== null) {
        return options;
      }
      if (def !== void 0) {
        return def;
      }
      return {};
    };
    exports2.emptyOptions = Object.freeze({});
    exports2.noop = function() {
    };
    exports2.resolvedPromise = Promise.resolve();
    exports2.deprecate = function(message) {
      if (!deprecations.has(message)) {
        deprecations.add(message);
        const c = globalThis.console;
        if (typeof c !== "undefined" && typeof c.warn === "function") {
          c.warn(new ModuleError(message, { code: "LEVEL_LEGACY" }));
        }
      }
    };
  }
});

// node_modules/abstract-level/lib/errors.js
var require_errors = __commonJS({
  "node_modules/abstract-level/lib/errors.js"(exports2) {
    "use strict";
    var ModuleError = require_module_error();
    var AbortError = class extends ModuleError {
      constructor(cause) {
        super("Operation has been aborted", {
          code: "LEVEL_ABORTED",
          cause
        });
      }
      // Set name to AbortError for web compatibility. See:
      // https://dom.spec.whatwg.org/#aborting-ongoing-activities
      // https://github.com/nodejs/node/pull/35911#discussion_r515779306
      get name() {
        return "AbortError";
      }
    };
    exports2.AbortError = AbortError;
  }
});

// node_modules/abstract-level/abstract-iterator.js
var require_abstract_iterator = __commonJS({
  "node_modules/abstract-level/abstract-iterator.js"(exports2) {
    "use strict";
    var ModuleError = require_module_error();
    var combineErrors = require_maybe_combine_errors();
    var { getOptions, emptyOptions, noop } = require_common();
    var { AbortError } = require_errors();
    var kDecodeOne = /* @__PURE__ */ Symbol("decodeOne");
    var kDecodeMany = /* @__PURE__ */ Symbol("decodeMany");
    var kKeyEncoding = /* @__PURE__ */ Symbol("keyEncoding");
    var kValueEncoding = /* @__PURE__ */ Symbol("valueEncoding");
    var CommonIterator = class {
      #working = false;
      #pendingClose = null;
      #closingPromise = null;
      #count = 0;
      #signal;
      #limit;
      #ended;
      #snapshot;
      constructor(db, options) {
        if (typeof db !== "object" || db === null) {
          const hint = db === null ? "null" : typeof db;
          throw new TypeError(`The first argument must be an abstract-level database, received ${hint}`);
        }
        if (typeof options !== "object" || options === null) {
          throw new TypeError("The second argument must be an options object");
        }
        this[kKeyEncoding] = options[kKeyEncoding];
        this[kValueEncoding] = options[kValueEncoding];
        this.#limit = Number.isInteger(options.limit) && options.limit >= 0 ? options.limit : Infinity;
        this.#signal = options.signal != null ? options.signal : null;
        this.#snapshot = options.snapshot != null ? options.snapshot : null;
        this.#ended = false;
        this.db = db;
        this.db.attachResource(this);
      }
      get count() {
        return this.#count;
      }
      get limit() {
        return this.#limit;
      }
      async next() {
        this.#startWork();
        try {
          if (this.#ended || this.#count >= this.#limit) {
            this.#ended = true;
            return void 0;
          }
          let item = await this._next();
          if (item === void 0) {
            this.#ended = true;
            return void 0;
          }
          try {
            item = this[kDecodeOne](item);
          } catch (err) {
            throw new IteratorDecodeError(err);
          }
          this.#count++;
          return item;
        } finally {
          this.#endWork();
        }
      }
      async _next() {
      }
      async nextv(size, options) {
        if (!Number.isInteger(size)) {
          throw new TypeError("The first argument 'size' must be an integer");
        }
        options = getOptions(options, emptyOptions);
        if (size < 1) size = 1;
        if (this.#limit < Infinity) size = Math.min(size, this.#limit - this.#count);
        this.#startWork();
        try {
          if (this.#ended || size <= 0) {
            this.#ended = true;
            return [];
          }
          const items = await this._nextv(size, options);
          if (items.length === 0) {
            this.#ended = true;
            return items;
          }
          try {
            this[kDecodeMany](items);
          } catch (err) {
            throw new IteratorDecodeError(err);
          }
          this.#count += items.length;
          return items;
        } finally {
          this.#endWork();
        }
      }
      async _nextv(size, options) {
        const acc = [];
        while (acc.length < size) {
          const item = await this._next(options);
          if (item !== void 0) {
            acc.push(item);
          } else {
            this.#ended = true;
            break;
          }
        }
        return acc;
      }
      async all(options) {
        options = getOptions(options, emptyOptions);
        this.#startWork();
        try {
          if (this.#ended || this.#count >= this.#limit) {
            return [];
          }
          const items = await this._all(options);
          try {
            this[kDecodeMany](items);
          } catch (err) {
            throw new IteratorDecodeError(err);
          }
          this.#count += items.length;
          return items;
        } catch (err) {
          this.#endWork();
          await this.#destroy(err);
        } finally {
          this.#ended = true;
          if (this.#working) {
            this.#endWork();
            await this.close();
          }
        }
      }
      async _all(options) {
        let count = this.#count;
        const acc = [];
        while (true) {
          const size = this.#limit < Infinity ? Math.min(1e3, this.#limit - count) : 1e3;
          if (size <= 0) {
            return acc;
          }
          const items = await this._nextv(size, options);
          if (items.length === 0) {
            return acc;
          }
          acc.push.apply(acc, items);
          count += items.length;
        }
      }
      seek(target, options) {
        options = getOptions(options, emptyOptions);
        if (this.#closingPromise !== null) {
        } else if (this.#working) {
          throw new ModuleError("Iterator is busy: cannot call seek() until next() has completed", {
            code: "LEVEL_ITERATOR_BUSY"
          });
        } else {
          const keyEncoding = this.db.keyEncoding(options.keyEncoding || this[kKeyEncoding]);
          const keyFormat = keyEncoding.format;
          if (options.keyEncoding !== keyFormat) {
            options = { ...options, keyEncoding: keyFormat };
          }
          const mapped = this.db.prefixKey(keyEncoding.encode(target), keyFormat, false);
          this._seek(mapped, options);
          this.#ended = false;
        }
      }
      _seek(target, options) {
        throw new ModuleError("Iterator does not implement seek()", {
          code: "LEVEL_NOT_SUPPORTED"
        });
      }
      async close() {
        if (this.#closingPromise !== null) {
          return this.#closingPromise.catch(noop);
        }
        this.#closingPromise = new Promise((resolve, reject) => {
          this.#pendingClose = () => {
            this.#pendingClose = null;
            this.#privateClose().then(resolve, reject);
          };
        });
        if (!this.#working) {
          this.#pendingClose();
        }
        return this.#closingPromise;
      }
      async _close() {
      }
      async *[Symbol.asyncIterator]() {
        try {
          let item;
          while ((item = await this.next()) !== void 0) {
            yield item;
          }
        } catch (err) {
          await this.#destroy(err);
        } finally {
          await this.close();
        }
      }
      #startWork() {
        if (this.#closingPromise !== null) {
          throw new ModuleError("Iterator is not open: cannot read after close()", {
            code: "LEVEL_ITERATOR_NOT_OPEN"
          });
        } else if (this.#working) {
          throw new ModuleError("Iterator is busy: cannot read until previous read has completed", {
            code: "LEVEL_ITERATOR_BUSY"
          });
        } else if (this.#signal?.aborted) {
          throw new AbortError();
        }
        this.#snapshot?.ref();
        this.#working = true;
      }
      #endWork() {
        this.#working = false;
        this.#pendingClose?.();
        this.#snapshot?.unref();
      }
      async #privateClose() {
        await this._close();
        this.db.detachResource(this);
      }
      async #destroy(err) {
        try {
          await this.close();
        } catch (closeErr) {
          throw combineErrors([err, closeErr]);
        }
        throw err;
      }
    };
    if (typeof Symbol.asyncDispose === "symbol") {
      CommonIterator.prototype[Symbol.asyncDispose] = async function() {
        return this.close();
      };
    }
    var AbstractIterator = class extends CommonIterator {
      #keys;
      #values;
      constructor(db, options) {
        super(db, options);
        this.#keys = options.keys !== false;
        this.#values = options.values !== false;
      }
      [kDecodeOne](entry) {
        const key = entry[0];
        const value = entry[1];
        if (key !== void 0) {
          entry[0] = this.#keys ? this[kKeyEncoding].decode(key) : void 0;
        }
        if (value !== void 0) {
          entry[1] = this.#values ? this[kValueEncoding].decode(value) : void 0;
        }
        return entry;
      }
      [kDecodeMany](entries) {
        const keyEncoding = this[kKeyEncoding];
        const valueEncoding = this[kValueEncoding];
        for (const entry of entries) {
          const key = entry[0];
          const value = entry[1];
          if (key !== void 0) entry[0] = this.#keys ? keyEncoding.decode(key) : void 0;
          if (value !== void 0) entry[1] = this.#values ? valueEncoding.decode(value) : void 0;
        }
      }
    };
    var AbstractKeyIterator = class extends CommonIterator {
      [kDecodeOne](key) {
        return this[kKeyEncoding].decode(key);
      }
      [kDecodeMany](keys) {
        const keyEncoding = this[kKeyEncoding];
        for (let i = 0; i < keys.length; i++) {
          const key = keys[i];
          if (key !== void 0) keys[i] = keyEncoding.decode(key);
        }
      }
    };
    var AbstractValueIterator = class extends CommonIterator {
      [kDecodeOne](value) {
        return this[kValueEncoding].decode(value);
      }
      [kDecodeMany](values) {
        const valueEncoding = this[kValueEncoding];
        for (let i = 0; i < values.length; i++) {
          const value = values[i];
          if (value !== void 0) values[i] = valueEncoding.decode(value);
        }
      }
    };
    var IteratorDecodeError = class extends ModuleError {
      constructor(cause) {
        super("Iterator could not decode data", {
          code: "LEVEL_DECODE_ERROR",
          cause
        });
      }
    };
    AbstractIterator.keyEncoding = kKeyEncoding;
    AbstractIterator.valueEncoding = kValueEncoding;
    exports2.AbstractIterator = AbstractIterator;
    exports2.AbstractKeyIterator = AbstractKeyIterator;
    exports2.AbstractValueIterator = AbstractValueIterator;
  }
});

// node_modules/abstract-level/lib/default-kv-iterator.js
var require_default_kv_iterator = __commonJS({
  "node_modules/abstract-level/lib/default-kv-iterator.js"(exports2) {
    "use strict";
    var { AbstractKeyIterator, AbstractValueIterator } = require_abstract_iterator();
    var kIterator = /* @__PURE__ */ Symbol("iterator");
    var kHandleOne = /* @__PURE__ */ Symbol("handleOne");
    var kHandleMany = /* @__PURE__ */ Symbol("handleMany");
    var DefaultKeyIterator = class extends AbstractKeyIterator {
      constructor(db, options) {
        super(db, options);
        this[kIterator] = db.iterator({ ...options, keys: true, values: false });
      }
      [kHandleOne](entry) {
        return entry[0];
      }
      [kHandleMany](entries) {
        for (let i = 0; i < entries.length; i++) {
          entries[i] = entries[i][0];
        }
      }
    };
    var DefaultValueIterator = class extends AbstractValueIterator {
      constructor(db, options) {
        super(db, options);
        this[kIterator] = db.iterator({ ...options, keys: false, values: true });
      }
      [kHandleOne](entry) {
        return entry[1];
      }
      [kHandleMany](entries) {
        for (let i = 0; i < entries.length; i++) {
          entries[i] = entries[i][1];
        }
      }
    };
    for (const Iterator of [DefaultKeyIterator, DefaultValueIterator]) {
      Iterator.prototype._next = async function() {
        const entry = await this[kIterator].next();
        return entry === void 0 ? entry : this[kHandleOne](entry);
      };
      Iterator.prototype._nextv = async function(size, options) {
        const entries = await this[kIterator].nextv(size, options);
        this[kHandleMany](entries);
        return entries;
      };
      Iterator.prototype._all = async function(options) {
        const entries = await this[kIterator].all(options);
        this[kHandleMany](entries);
        return entries;
      };
      Iterator.prototype._seek = function(target, options) {
        this[kIterator].seek(target, options);
      };
      Iterator.prototype._close = async function() {
        return this[kIterator].close();
      };
    }
    exports2.DefaultKeyIterator = DefaultKeyIterator;
    exports2.DefaultValueIterator = DefaultValueIterator;
  }
});

// node_modules/abstract-level/lib/deferred-iterator.js
var require_deferred_iterator = __commonJS({
  "node_modules/abstract-level/lib/deferred-iterator.js"(exports2) {
    "use strict";
    var { AbstractIterator, AbstractKeyIterator, AbstractValueIterator } = require_abstract_iterator();
    var ModuleError = require_module_error();
    var kNut = /* @__PURE__ */ Symbol("nut");
    var kUndefer = /* @__PURE__ */ Symbol("undefer");
    var kFactory = /* @__PURE__ */ Symbol("factory");
    var kSignalOptions = /* @__PURE__ */ Symbol("signalOptions");
    var DeferredIterator = class extends AbstractIterator {
      constructor(db, options) {
        super(db, options);
        this[kNut] = null;
        this[kFactory] = () => db.iterator(options);
        this[kSignalOptions] = { signal: options.signal };
        this.db.defer(() => this[kUndefer](), this[kSignalOptions]);
      }
    };
    var DeferredKeyIterator = class extends AbstractKeyIterator {
      constructor(db, options) {
        super(db, options);
        this[kNut] = null;
        this[kFactory] = () => db.keys(options);
        this[kSignalOptions] = { signal: options.signal };
        this.db.defer(() => this[kUndefer](), this[kSignalOptions]);
      }
    };
    var DeferredValueIterator = class extends AbstractValueIterator {
      constructor(db, options) {
        super(db, options);
        this[kNut] = null;
        this[kFactory] = () => db.values(options);
        this[kSignalOptions] = { signal: options.signal };
        this.db.defer(() => this[kUndefer](), this[kSignalOptions]);
      }
    };
    for (const Iterator of [DeferredIterator, DeferredKeyIterator, DeferredValueIterator]) {
      Iterator.prototype[kUndefer] = function() {
        if (this.db.status === "open") {
          this[kNut] = this[kFactory]();
        }
      };
      Iterator.prototype._next = async function() {
        if (this[kNut] !== null) {
          return this[kNut].next();
        } else if (this.db.status === "opening") {
          return this.db.deferAsync(() => this._next(), this[kSignalOptions]);
        } else {
          throw new ModuleError("Iterator is not open: cannot call next() after close()", {
            code: "LEVEL_ITERATOR_NOT_OPEN"
          });
        }
      };
      Iterator.prototype._nextv = async function(size, options) {
        if (this[kNut] !== null) {
          return this[kNut].nextv(size, options);
        } else if (this.db.status === "opening") {
          return this.db.deferAsync(() => this._nextv(size, options), this[kSignalOptions]);
        } else {
          throw new ModuleError("Iterator is not open: cannot call nextv() after close()", {
            code: "LEVEL_ITERATOR_NOT_OPEN"
          });
        }
      };
      Iterator.prototype._all = async function(options) {
        if (this[kNut] !== null) {
          return this[kNut].all();
        } else if (this.db.status === "opening") {
          return this.db.deferAsync(() => this._all(options), this[kSignalOptions]);
        } else {
          throw new ModuleError("Iterator is not open: cannot call all() after close()", {
            code: "LEVEL_ITERATOR_NOT_OPEN"
          });
        }
      };
      Iterator.prototype._seek = function(target, options) {
        if (this[kNut] !== null) {
          this[kNut]._seek(target, options);
        } else if (this.db.status === "opening") {
          this.db.defer(() => this._seek(target, options), this[kSignalOptions]);
        }
      };
      Iterator.prototype._close = async function() {
        if (this[kNut] !== null) {
          return this[kNut].close();
        } else if (this.db.status === "opening") {
          return this.db.deferAsync(() => this._close());
        }
      };
    }
    exports2.DeferredIterator = DeferredIterator;
    exports2.DeferredKeyIterator = DeferredKeyIterator;
    exports2.DeferredValueIterator = DeferredValueIterator;
  }
});

// node_modules/abstract-level/lib/prefixes.js
var require_prefixes = __commonJS({
  "node_modules/abstract-level/lib/prefixes.js"(exports2) {
    "use strict";
    exports2.prefixDescendantKey = function(key, keyFormat, descendant, ancestor) {
      while (descendant !== null && descendant !== ancestor) {
        key = descendant.prefixKey(key, keyFormat, true);
        descendant = descendant.parent;
      }
      return key;
    };
    exports2.isDescendant = function(db, ancestor) {
      while (true) {
        if (db.parent == null) return false;
        if (db.parent === ancestor) return true;
        db = db.parent;
      }
    };
  }
});

// node_modules/abstract-level/lib/prewrite-batch.js
var require_prewrite_batch = __commonJS({
  "node_modules/abstract-level/lib/prewrite-batch.js"(exports2) {
    "use strict";
    var { prefixDescendantKey, isDescendant } = require_prefixes();
    var PrewriteBatch = class {
      #db;
      #privateOperations;
      #publicOperations;
      constructor(db, privateOperations, publicOperations) {
        this.#db = db;
        this.#privateOperations = privateOperations;
        this.#publicOperations = publicOperations;
      }
      add(op) {
        const isPut = op.type === "put";
        const delegated = op.sublevel != null;
        const db = delegated ? op.sublevel : this.#db;
        db._assertValidKey(op.key);
        op.keyEncoding = db.keyEncoding(op.keyEncoding);
        if (isPut) {
          db._assertValidValue(op.value);
          op.valueEncoding = db.valueEncoding(op.valueEncoding);
        } else if (op.type !== "del") {
          throw new TypeError("A batch operation must have a type property that is 'put' or 'del'");
        }
        const keyEncoding = op.keyEncoding;
        const preencodedKey = keyEncoding.encode(op.key);
        const keyFormat = keyEncoding.format;
        const siblings = delegated && !isDescendant(op.sublevel, this.#db) && op.sublevel !== this.#db;
        const encodedKey = delegated && !siblings ? prefixDescendantKey(preencodedKey, keyFormat, db, this.#db) : preencodedKey;
        if (delegated && !siblings) {
          op.sublevel = null;
        }
        let publicOperation = null;
        if (this.#publicOperations !== null && !siblings) {
          publicOperation = { ...op };
          publicOperation.encodedKey = encodedKey;
          if (delegated) {
            publicOperation.key = encodedKey;
            publicOperation.keyEncoding = this.#db.keyEncoding(keyFormat);
          }
          this.#publicOperations.push(publicOperation);
        }
        op.key = siblings ? encodedKey : this.#db.prefixKey(encodedKey, keyFormat, true);
        op.keyEncoding = keyFormat;
        if (isPut) {
          const valueEncoding = op.valueEncoding;
          const encodedValue = valueEncoding.encode(op.value);
          const valueFormat = valueEncoding.format;
          op.value = encodedValue;
          op.valueEncoding = valueFormat;
          if (publicOperation !== null) {
            publicOperation.encodedValue = encodedValue;
            if (delegated) {
              publicOperation.value = encodedValue;
              publicOperation.valueEncoding = this.#db.valueEncoding(valueFormat);
            }
          }
        }
        this.#privateOperations.push(op);
        return this;
      }
    };
    exports2.PrewriteBatch = PrewriteBatch;
  }
});

// node_modules/abstract-level/abstract-chained-batch.js
var require_abstract_chained_batch = __commonJS({
  "node_modules/abstract-level/abstract-chained-batch.js"(exports2) {
    "use strict";
    var combineErrors = require_maybe_combine_errors();
    var ModuleError = require_module_error();
    var { getOptions, emptyOptions, noop } = require_common();
    var { prefixDescendantKey, isDescendant } = require_prefixes();
    var { PrewriteBatch } = require_prewrite_batch();
    var kPublicOperations = /* @__PURE__ */ Symbol("publicOperations");
    var kPrivateOperations = /* @__PURE__ */ Symbol("privateOperations");
    var AbstractChainedBatch = class {
      #status = "open";
      #length = 0;
      #closePromise = null;
      #publicOperations;
      #prewriteRun;
      #prewriteBatch;
      #prewriteData;
      #addMode;
      constructor(db, options) {
        if (typeof db !== "object" || db === null) {
          const hint = db === null ? "null" : typeof db;
          throw new TypeError(`The first argument must be an abstract-level database, received ${hint}`);
        }
        const enableWriteEvent = db.listenerCount("write") > 0;
        const enablePrewriteHook = !db.hooks.prewrite.noop;
        this.#publicOperations = enableWriteEvent ? [] : null;
        this.#addMode = getOptions(options, emptyOptions).add === true;
        if (enablePrewriteHook) {
          const data = new PrewriteData([], enableWriteEvent ? [] : null);
          this.#prewriteData = data;
          this.#prewriteBatch = new PrewriteBatch(db, data[kPrivateOperations], data[kPublicOperations]);
          this.#prewriteRun = db.hooks.prewrite.run;
        } else {
          this.#prewriteData = null;
          this.#prewriteBatch = null;
          this.#prewriteRun = null;
        }
        this.db = db;
        this.db.attachResource(this);
      }
      get length() {
        if (this.#prewriteData !== null) {
          return this.#length + this.#prewriteData.length;
        } else {
          return this.#length;
        }
      }
      put(key, value, options) {
        this.#assertStatus();
        options = getOptions(options, emptyOptions);
        const delegated = options.sublevel != null;
        const db = delegated ? options.sublevel : this.db;
        db._assertValidKey(key);
        db._assertValidValue(value);
        const op = {
          ...options,
          type: "put",
          key,
          value,
          keyEncoding: db.keyEncoding(options.keyEncoding),
          valueEncoding: db.valueEncoding(options.valueEncoding)
        };
        if (this.#prewriteRun !== null) {
          try {
            this.#prewriteRun(op, this.#prewriteBatch);
            op.keyEncoding = db.keyEncoding(op.keyEncoding);
            op.valueEncoding = db.valueEncoding(op.valueEncoding);
          } catch (err) {
            throw new ModuleError("The prewrite hook failed on batch.put()", {
              code: "LEVEL_HOOK_ERROR",
              cause: err
            });
          }
        }
        const keyEncoding = op.keyEncoding;
        const preencodedKey = keyEncoding.encode(op.key);
        const keyFormat = keyEncoding.format;
        const siblings = delegated && !isDescendant(op.sublevel, this.db) && op.sublevel !== this.db;
        const encodedKey = delegated && !siblings ? prefixDescendantKey(preencodedKey, keyFormat, db, this.db) : preencodedKey;
        const valueEncoding = op.valueEncoding;
        const encodedValue = valueEncoding.encode(op.value);
        const valueFormat = valueEncoding.format;
        if (delegated && !siblings) {
          op.sublevel = null;
        }
        if (this.#publicOperations !== null && !siblings) {
          const publicOperation = { ...op };
          publicOperation.encodedKey = encodedKey;
          publicOperation.encodedValue = encodedValue;
          if (delegated) {
            publicOperation.key = encodedKey;
            publicOperation.value = encodedValue;
            publicOperation.keyEncoding = this.db.keyEncoding(keyFormat);
            publicOperation.valueEncoding = this.db.valueEncoding(valueFormat);
          }
          this.#publicOperations.push(publicOperation);
        }
        op.key = siblings ? encodedKey : this.db.prefixKey(encodedKey, keyFormat, true);
        op.value = encodedValue;
        op.keyEncoding = keyFormat;
        op.valueEncoding = valueFormat;
        if (this.#addMode) {
          this._add(op);
        } else {
          this._put(op.key, encodedValue, op);
        }
        this.#length++;
        return this;
      }
      _put(key, value, options) {
      }
      del(key, options) {
        this.#assertStatus();
        options = getOptions(options, emptyOptions);
        const delegated = options.sublevel != null;
        const db = delegated ? options.sublevel : this.db;
        db._assertValidKey(key);
        const op = {
          ...options,
          type: "del",
          key,
          keyEncoding: db.keyEncoding(options.keyEncoding)
        };
        if (this.#prewriteRun !== null) {
          try {
            this.#prewriteRun(op, this.#prewriteBatch);
            op.keyEncoding = db.keyEncoding(op.keyEncoding);
          } catch (err) {
            throw new ModuleError("The prewrite hook failed on batch.del()", {
              code: "LEVEL_HOOK_ERROR",
              cause: err
            });
          }
        }
        const keyEncoding = op.keyEncoding;
        const preencodedKey = keyEncoding.encode(op.key);
        const keyFormat = keyEncoding.format;
        const encodedKey = delegated ? prefixDescendantKey(preencodedKey, keyFormat, db, this.db) : preencodedKey;
        if (delegated) op.sublevel = null;
        if (this.#publicOperations !== null) {
          const publicOperation = { ...op };
          publicOperation.encodedKey = encodedKey;
          if (delegated) {
            publicOperation.key = encodedKey;
            publicOperation.keyEncoding = this.db.keyEncoding(keyFormat);
          }
          this.#publicOperations.push(publicOperation);
        }
        op.key = this.db.prefixKey(encodedKey, keyFormat, true);
        op.keyEncoding = keyFormat;
        if (this.#addMode) {
          this._add(op);
        } else {
          this._del(op.key, op);
        }
        this.#length++;
        return this;
      }
      _del(key, options) {
      }
      _add(op) {
      }
      clear() {
        this.#assertStatus();
        this._clear();
        if (this.#publicOperations !== null) this.#publicOperations = [];
        if (this.#prewriteData !== null) this.#prewriteData.clear();
        this.#length = 0;
        return this;
      }
      _clear() {
      }
      async write(options) {
        this.#assertStatus();
        options = getOptions(options);
        if (this.#length === 0) {
          return this.close();
        } else {
          this.#status = "writing";
          const close = this.#prepareClose();
          try {
            if (this.#prewriteData !== null) {
              const publicOperations = this.#prewriteData[kPublicOperations];
              const privateOperations = this.#prewriteData[kPrivateOperations];
              const length = this.#prewriteData.length;
              for (let i = 0; i < length; i++) {
                const op = privateOperations[i];
                if (this.#addMode) {
                  this._add(op);
                } else if (op.type === "put") {
                  this._put(op.key, op.value, op);
                } else {
                  this._del(op.key, op);
                }
              }
              if (publicOperations !== null && length !== 0) {
                this.#publicOperations = this.#publicOperations.concat(publicOperations);
              }
            }
            await this._write(options);
          } catch (err) {
            close();
            try {
              await this.#closePromise;
            } catch (closeErr) {
              err = combineErrors([err, closeErr]);
            }
            throw err;
          }
          close();
          if (this.#publicOperations !== null) {
            this.db.emit("write", this.#publicOperations);
          }
          return this.#closePromise;
        }
      }
      async _write(options) {
      }
      async close() {
        if (this.#closePromise !== null) {
          return this.#closePromise.catch(noop);
        } else {
          this.#prepareClose()();
          return this.#closePromise;
        }
      }
      async _close() {
      }
      #assertStatus() {
        if (this.#status !== "open") {
          throw new ModuleError("Batch is not open: cannot change operations after write() or close()", {
            code: "LEVEL_BATCH_NOT_OPEN"
          });
        }
        if (this.db.status !== "open") {
          throw new ModuleError("Database is not open", {
            code: "LEVEL_DATABASE_NOT_OPEN"
          });
        }
      }
      #prepareClose() {
        let close;
        this.#closePromise = new Promise((resolve, reject) => {
          close = () => {
            this.#privateClose().then(resolve, reject);
          };
        });
        return close;
      }
      async #privateClose() {
        this.#status = "closing";
        await this._close();
        this.db.detachResource(this);
      }
    };
    if (typeof Symbol.asyncDispose === "symbol") {
      AbstractChainedBatch.prototype[Symbol.asyncDispose] = async function() {
        return this.close();
      };
    }
    var PrewriteData = class {
      constructor(privateOperations, publicOperations) {
        this[kPrivateOperations] = privateOperations;
        this[kPublicOperations] = publicOperations;
      }
      get length() {
        return this[kPrivateOperations].length;
      }
      clear() {
        for (const k of [kPublicOperations, kPrivateOperations]) {
          const ops = this[k];
          if (ops !== null) {
            ops.splice(0, ops.length);
          }
        }
      }
    };
    exports2.AbstractChainedBatch = AbstractChainedBatch;
  }
});

// node_modules/abstract-level/lib/default-chained-batch.js
var require_default_chained_batch = __commonJS({
  "node_modules/abstract-level/lib/default-chained-batch.js"(exports2) {
    "use strict";
    var { AbstractChainedBatch } = require_abstract_chained_batch();
    var DefaultChainedBatch = class extends AbstractChainedBatch {
      #encoded = [];
      constructor(db) {
        super(db, { add: true });
      }
      _add(op) {
        this.#encoded.push(op);
      }
      _clear() {
        this.#encoded = [];
      }
      async _write(options) {
        return this.db._batch(this.#encoded, options);
      }
    };
    exports2.DefaultChainedBatch = DefaultChainedBatch;
  }
});

// node_modules/abstract-level/lib/hooks.js
var require_hooks = __commonJS({
  "node_modules/abstract-level/lib/hooks.js"(exports2) {
    "use strict";
    var { noop } = require_common();
    var DatabaseHooks = class {
      constructor() {
        this.postopen = new Hook({ async: true });
        this.prewrite = new Hook({ async: false });
        this.newsub = new Hook({ async: false });
      }
    };
    var Hook = class {
      #functions = /* @__PURE__ */ new Set();
      #isAsync;
      constructor(options) {
        this.#isAsync = options.async;
        this.noop = true;
        this.run = this.#runner();
      }
      add(fn) {
        assertFunction(fn);
        this.#functions.add(fn);
        this.noop = false;
        this.run = this.#runner();
      }
      delete(fn) {
        assertFunction(fn);
        this.#functions.delete(fn);
        this.noop = this.#functions.size === 0;
        this.run = this.#runner();
      }
      #runner() {
        if (this.noop) {
          return noop;
        } else if (this.#functions.size === 1) {
          const [fn] = this.#functions;
          return fn;
        } else if (this.#isAsync) {
          const run = async function(functions, ...args) {
            for (const fn of functions) {
              await fn(...args);
            }
          };
          return run.bind(null, Array.from(this.#functions));
        } else {
          const run = function(functions, ...args) {
            for (const fn of functions) {
              fn(...args);
            }
          };
          return run.bind(null, Array.from(this.#functions));
        }
      }
    };
    var assertFunction = function(fn) {
      if (typeof fn !== "function") {
        const hint = fn === null ? "null" : typeof fn;
        throw new TypeError(`The first argument must be a function, received ${hint}`);
      }
    };
    exports2.DatabaseHooks = DatabaseHooks;
  }
});

// node_modules/abstract-level/lib/event-monitor.js
var require_event_monitor = __commonJS({
  "node_modules/abstract-level/lib/event-monitor.js"(exports2) {
    "use strict";
    var { deprecate } = require_common();
    exports2.EventMonitor = class EventMonitor {
      constructor(emitter) {
        this.write = false;
        const beforeAdded = (name) => {
          if (name === "write") {
            this.write = true;
          }
          if (name === "put" || name === "del" || name === "batch") {
            deprecate(`The '${name}' event has been removed in favor of 'write'`);
          }
        };
        const afterRemoved = (name) => {
          if (name === "write") {
            this.write = emitter.listenerCount("write") > 0;
          }
        };
        emitter.on("newListener", beforeAdded);
        emitter.on("removeListener", afterRemoved);
      }
    };
  }
});

// node_modules/abstract-level/lib/deferred-queue.js
var require_deferred_queue = __commonJS({
  "node_modules/abstract-level/lib/deferred-queue.js"(exports2) {
    "use strict";
    var { getOptions, emptyOptions } = require_common();
    var { AbortError } = require_errors();
    var DeferredOperation = class {
      constructor(fn, signal) {
        this.fn = fn;
        this.signal = signal;
      }
    };
    var DeferredQueue = class {
      #operations;
      #signals;
      constructor() {
        this.#operations = [];
        this.#signals = /* @__PURE__ */ new Set();
      }
      add(fn, options) {
        options = getOptions(options, emptyOptions);
        const signal = options.signal;
        if (signal == null) {
          this.#operations.push(new DeferredOperation(fn, null));
          return;
        }
        if (signal.aborted) {
          fn(new AbortError());
          return;
        }
        if (!this.#signals.has(signal)) {
          this.#signals.add(signal);
          signal.addEventListener("abort", this.#handleAbort, { once: true });
        }
        this.#operations.push(new DeferredOperation(fn, signal));
      }
      drain() {
        const operations = this.#operations;
        const signals = this.#signals;
        this.#operations = [];
        this.#signals = /* @__PURE__ */ new Set();
        for (const signal of signals) {
          signal.removeEventListener("abort", this.#handleAbort);
        }
        for (const operation of operations) {
          operation.fn.call(null);
        }
      }
      #handleAbort = (ev) => {
        const signal = ev.target;
        const err = new AbortError();
        const aborted = [];
        this.#operations = this.#operations.filter(function(operation) {
          if (operation.signal !== null && operation.signal === signal) {
            aborted.push(operation);
            return false;
          } else {
            return true;
          }
        });
        this.#signals.delete(signal);
        for (const operation of aborted) {
          operation.fn.call(null, err);
        }
      };
    };
    exports2.DeferredQueue = DeferredQueue;
  }
});

// node_modules/abstract-level/lib/range-options.js
var require_range_options = __commonJS({
  "node_modules/abstract-level/lib/range-options.js"(exports2, module2) {
    "use strict";
    var hasOwnProperty = Object.prototype.hasOwnProperty;
    var rangeOptions = /* @__PURE__ */ new Set(["lt", "lte", "gt", "gte"]);
    module2.exports = function(options, keyEncoding) {
      const result = {};
      for (const k in options) {
        if (!hasOwnProperty.call(options, k)) continue;
        if (k === "keyEncoding" || k === "valueEncoding") continue;
        if (rangeOptions.has(k)) {
          result[k] = keyEncoding.encode(options[k]);
        } else {
          result[k] = options[k];
        }
      }
      result.reverse = !!result.reverse;
      result.limit = Number.isInteger(result.limit) && result.limit >= 0 ? result.limit : -1;
      return result;
    };
  }
});

// node_modules/abstract-level/lib/abstract-sublevel-iterator.js
var require_abstract_sublevel_iterator = __commonJS({
  "node_modules/abstract-level/lib/abstract-sublevel-iterator.js"(exports2) {
    "use strict";
    var { AbstractIterator, AbstractKeyIterator, AbstractValueIterator } = require_abstract_iterator();
    var AbstractSublevelIterator = class extends AbstractIterator {
      #iterator;
      #unfix;
      constructor(db, options, iterator, unfix) {
        super(db, options);
        this.#iterator = iterator;
        this.#unfix = unfix;
      }
      async _next() {
        const entry = await this.#iterator.next();
        if (entry !== void 0) {
          const key = entry[0];
          if (key !== void 0) entry[0] = this.#unfix(key);
        }
        return entry;
      }
      async _nextv(size, options) {
        const entries = await this.#iterator.nextv(size, options);
        const unfix = this.#unfix;
        for (const entry of entries) {
          const key = entry[0];
          if (key !== void 0) entry[0] = unfix(key);
        }
        return entries;
      }
      async _all(options) {
        const entries = await this.#iterator.all(options);
        const unfix = this.#unfix;
        for (const entry of entries) {
          const key = entry[0];
          if (key !== void 0) entry[0] = unfix(key);
        }
        return entries;
      }
      _seek(target, options) {
        this.#iterator.seek(target, options);
      }
      async _close() {
        return this.#iterator.close();
      }
    };
    var AbstractSublevelKeyIterator = class extends AbstractKeyIterator {
      #iterator;
      #unfix;
      constructor(db, options, iterator, unfix) {
        super(db, options);
        this.#iterator = iterator;
        this.#unfix = unfix;
      }
      async _next() {
        const key = await this.#iterator.next();
        return key === void 0 ? key : this.#unfix(key);
      }
      async _nextv(size, options) {
        const keys = await this.#iterator.nextv(size, options);
        const unfix = this.#unfix;
        for (let i = 0; i < keys.length; i++) {
          const key = keys[i];
          if (key !== void 0) keys[i] = unfix(key);
        }
        return keys;
      }
      async _all(options) {
        const keys = await this.#iterator.all(options);
        const unfix = this.#unfix;
        for (let i = 0; i < keys.length; i++) {
          const key = keys[i];
          if (key !== void 0) keys[i] = unfix(key);
        }
        return keys;
      }
      _seek(target, options) {
        this.#iterator.seek(target, options);
      }
      async _close() {
        return this.#iterator.close();
      }
    };
    var AbstractSublevelValueIterator = class extends AbstractValueIterator {
      #iterator;
      constructor(db, options, iterator) {
        super(db, options);
        this.#iterator = iterator;
      }
      async _next() {
        return this.#iterator.next();
      }
      async _nextv(size, options) {
        return this.#iterator.nextv(size, options);
      }
      async _all(options) {
        return this.#iterator.all(options);
      }
      _seek(target, options) {
        this.#iterator.seek(target, options);
      }
      async _close() {
        return this.#iterator.close();
      }
    };
    exports2.AbstractSublevelIterator = AbstractSublevelIterator;
    exports2.AbstractSublevelKeyIterator = AbstractSublevelKeyIterator;
    exports2.AbstractSublevelValueIterator = AbstractSublevelValueIterator;
  }
});

// node_modules/abstract-level/lib/abstract-sublevel.js
var require_abstract_sublevel = __commonJS({
  "node_modules/abstract-level/lib/abstract-sublevel.js"(exports2, module2) {
    "use strict";
    var ModuleError = require_module_error();
    var { Buffer: Buffer2 } = require("buffer") || {};
    var {
      AbstractSublevelIterator,
      AbstractSublevelKeyIterator,
      AbstractSublevelValueIterator
    } = require_abstract_sublevel_iterator();
    var kRoot = /* @__PURE__ */ Symbol("root");
    var textEncoder = new TextEncoder();
    var defaults = { separator: "!" };
    module2.exports = function({ AbstractLevel }) {
      class AbstractSublevel extends AbstractLevel {
        #globalPrefix;
        #localPrefix;
        #localPath;
        #globalPath;
        #globalUpperBound;
        #parent;
        #unfix;
        static defaults(options) {
          if (options == null) {
            return defaults;
          } else if (!options.separator) {
            return { ...options, separator: "!" };
          } else {
            return options;
          }
        }
        constructor(db, name, options) {
          const { separator, manifest, ...forward } = AbstractSublevel.defaults(options);
          const names = [].concat(name).map((name2) => trim(name2, separator));
          const reserved = separator.charCodeAt(0) + 1;
          const root = db[kRoot] || db;
          if (!names.every((name2) => textEncoder.encode(name2).every((x) => x > reserved && x < 127))) {
            throw new ModuleError(`Sublevel name must use bytes > ${reserved} < ${127}`, {
              code: "LEVEL_INVALID_PREFIX"
            });
          }
          super(mergeManifests(db, manifest), forward);
          const localPrefix = names.map((name2) => separator + name2 + separator).join("");
          const globalPrefix = (db.prefix || "") + localPrefix;
          const globalUpperBound = globalPrefix.slice(0, -1) + String.fromCharCode(reserved);
          this[kRoot] = root;
          this.#parent = db;
          this.#localPath = names;
          this.#globalPath = db.prefix ? db.path().concat(names) : names;
          this.#globalPrefix = new MultiFormat(globalPrefix);
          this.#globalUpperBound = new MultiFormat(globalUpperBound);
          this.#localPrefix = new MultiFormat(localPrefix);
          this.#unfix = new Unfixer();
        }
        prefixKey(key, keyFormat, local) {
          const prefix = local ? this.#localPrefix : this.#globalPrefix;
          if (keyFormat === "utf8") {
            return prefix.utf8 + key;
          } else if (key.byteLength === 0) {
            return prefix[keyFormat];
          } else if (keyFormat === "view") {
            const view = prefix.view;
            const result = new Uint8Array(view.byteLength + key.byteLength);
            result.set(view, 0);
            result.set(key, view.byteLength);
            return result;
          } else {
            const buffer = prefix.buffer;
            return Buffer2.concat([buffer, key], buffer.byteLength + key.byteLength);
          }
        }
        // Not exposed for now.
        #prefixRange(range, keyFormat) {
          if (range.gte !== void 0) {
            range.gte = this.prefixKey(range.gte, keyFormat, false);
          } else if (range.gt !== void 0) {
            range.gt = this.prefixKey(range.gt, keyFormat, false);
          } else {
            range.gte = this.#globalPrefix[keyFormat];
          }
          if (range.lte !== void 0) {
            range.lte = this.prefixKey(range.lte, keyFormat, false);
          } else if (range.lt !== void 0) {
            range.lt = this.prefixKey(range.lt, keyFormat, false);
          } else {
            range.lte = this.#globalUpperBound[keyFormat];
          }
        }
        get prefix() {
          return this.#globalPrefix.utf8;
        }
        get db() {
          return this[kRoot];
        }
        get parent() {
          return this.#parent;
        }
        path(local = false) {
          return local ? this.#localPath : this.#globalPath;
        }
        async _open(options) {
          await this.#parent.open({ passive: true });
          this.#parent.attachResource(this);
        }
        async _close() {
          this.#parent.detachResource(this);
        }
        async _put(key, value, options) {
          return this.#parent.put(key, value, options);
        }
        async _get(key, options) {
          return this.#parent.get(key, options);
        }
        _getSync(key, options) {
          return this.#parent.getSync(key, options);
        }
        async _getMany(keys, options) {
          return this.#parent.getMany(keys, options);
        }
        async _has(key, options) {
          return this.#parent.has(key, options);
        }
        async _hasMany(keys, options) {
          return this.#parent.hasMany(keys, options);
        }
        async _del(key, options) {
          return this.#parent.del(key, options);
        }
        async _batch(operations, options) {
          return this.#parent.batch(operations, options);
        }
        // TODO: call parent instead of root
        async _clear(options) {
          this.#prefixRange(options, options.keyEncoding);
          return this[kRoot].clear(options);
        }
        // TODO: call parent instead of root
        _iterator(options) {
          this.#prefixRange(options, options.keyEncoding);
          const iterator = this[kRoot].iterator(options);
          const unfix = this.#unfix.get(this.#globalPrefix.utf8.length, options.keyEncoding);
          return new AbstractSublevelIterator(this, options, iterator, unfix);
        }
        _keys(options) {
          this.#prefixRange(options, options.keyEncoding);
          const iterator = this[kRoot].keys(options);
          const unfix = this.#unfix.get(this.#globalPrefix.utf8.length, options.keyEncoding);
          return new AbstractSublevelKeyIterator(this, options, iterator, unfix);
        }
        _values(options) {
          this.#prefixRange(options, options.keyEncoding);
          const iterator = this[kRoot].values(options);
          return new AbstractSublevelValueIterator(this, options, iterator);
        }
        _snapshot(options) {
          return this[kRoot].snapshot(options);
        }
      }
      return { AbstractSublevel };
    };
    var mergeManifests = function(parent, manifest) {
      return {
        // Inherit manifest of parent db
        ...parent.supports,
        // Disable unsupported features
        createIfMissing: false,
        errorIfExists: false,
        // Unset additional events because we're not forwarding them
        events: {},
        // Unset additional methods (like approximateSize) which we can't support here unless
        // the AbstractSublevel class is overridden by an implementation of `abstract-level`.
        additionalMethods: {},
        // Inherit manifest of custom AbstractSublevel subclass. Such a class is not
        // allowed to override encodings.
        ...manifest,
        encodings: {
          utf8: supportsEncoding(parent, "utf8"),
          buffer: supportsEncoding(parent, "buffer"),
          view: supportsEncoding(parent, "view")
        }
      };
    };
    var supportsEncoding = function(parent, encoding) {
      return parent.supports.encodings[encoding] ? parent.keyEncoding(encoding).name === encoding : false;
    };
    var MultiFormat = class {
      constructor(key) {
        this.utf8 = key;
        this.view = textEncoder.encode(key);
        this.buffer = Buffer2 ? Buffer2.from(this.view.buffer, 0, this.view.byteLength) : {};
      }
    };
    var Unfixer = class {
      constructor() {
        this.cache = /* @__PURE__ */ new Map();
      }
      get(prefixLength, keyFormat) {
        let unfix = this.cache.get(keyFormat);
        if (unfix === void 0) {
          if (keyFormat === "view") {
            unfix = function(prefixLength2, key) {
              return key.subarray(prefixLength2);
            }.bind(null, prefixLength);
          } else {
            unfix = function(prefixLength2, key) {
              return key.slice(prefixLength2);
            }.bind(null, prefixLength);
          }
          this.cache.set(keyFormat, unfix);
        }
        return unfix;
      }
    };
    var trim = function(str, char) {
      let start = 0;
      let end = str.length;
      while (start < end && str[start] === char) start++;
      while (end > start && str[end - 1] === char) end--;
      return str.slice(start, end);
    };
  }
});

// node_modules/abstract-level/abstract-level.js
var require_abstract_level = __commonJS({
  "node_modules/abstract-level/abstract-level.js"(exports2) {
    "use strict";
    var { supports } = require_level_supports();
    var { Transcoder } = require_level_transcoder();
    var { EventEmitter } = require("events");
    var ModuleError = require_module_error();
    var combineErrors = require_maybe_combine_errors();
    var { AbstractIterator } = require_abstract_iterator();
    var { DefaultKeyIterator, DefaultValueIterator } = require_default_kv_iterator();
    var { DeferredIterator, DeferredKeyIterator, DeferredValueIterator } = require_deferred_iterator();
    var { DefaultChainedBatch } = require_default_chained_batch();
    var { DatabaseHooks } = require_hooks();
    var { PrewriteBatch } = require_prewrite_batch();
    var { EventMonitor } = require_event_monitor();
    var { getOptions, noop, emptyOptions, resolvedPromise } = require_common();
    var { prefixDescendantKey, isDescendant } = require_prefixes();
    var { DeferredQueue } = require_deferred_queue();
    var rangeOptions = require_range_options();
    var AbstractLevel = class extends EventEmitter {
      #status = "opening";
      #deferOpen = true;
      #statusChange = null;
      #statusLocked = false;
      #resources;
      #queue;
      #options;
      #defaultOptions;
      #transcoder;
      #keyEncoding;
      #valueEncoding;
      #eventMonitor;
      constructor(manifest, options) {
        super();
        if (typeof manifest !== "object" || manifest === null) {
          throw new TypeError("The first argument 'manifest' must be an object");
        }
        options = getOptions(options);
        const { keyEncoding, valueEncoding, passive, ...forward } = options;
        this.#resources = /* @__PURE__ */ new Set();
        this.#queue = new DeferredQueue();
        this.#options = forward;
        const implicitSnapshots = manifest.snapshots !== false && manifest.implicitSnapshots !== false;
        this.hooks = new DatabaseHooks();
        this.supports = supports(manifest, {
          deferredOpen: true,
          seek: true,
          implicitSnapshots,
          permanence: manifest.permanence !== false,
          encodings: manifest.encodings || {},
          events: {
            ...manifest.events,
            opening: true,
            open: true,
            closing: true,
            closed: true,
            write: true,
            clear: true
          }
        });
        this.#eventMonitor = new EventMonitor(this);
        this.#transcoder = new Transcoder(formats(this));
        this.#keyEncoding = this.#transcoder.encoding(keyEncoding || "utf8");
        this.#valueEncoding = this.#transcoder.encoding(valueEncoding || "utf8");
        for (const encoding of this.#transcoder.encodings()) {
          if (!this.supports.encodings[encoding.commonName]) {
            this.supports.encodings[encoding.commonName] = true;
          }
        }
        this.#defaultOptions = {
          empty: emptyOptions,
          entry: Object.freeze({
            keyEncoding: this.#keyEncoding.commonName,
            valueEncoding: this.#valueEncoding.commonName
          }),
          entryFormat: Object.freeze({
            keyEncoding: this.#keyEncoding.format,
            valueEncoding: this.#valueEncoding.format
          }),
          key: Object.freeze({
            keyEncoding: this.#keyEncoding.commonName
          }),
          keyFormat: Object.freeze({
            keyEncoding: this.#keyEncoding.format
          }),
          owner: Object.freeze({
            owner: this
          })
        };
        queueMicrotask(() => {
          if (this.#deferOpen) {
            this.open({ passive: false }).catch(noop);
          }
        });
      }
      get status() {
        return this.#status;
      }
      get parent() {
        return null;
      }
      keyEncoding(encoding) {
        return this.#transcoder.encoding(encoding ?? this.#keyEncoding);
      }
      valueEncoding(encoding) {
        return this.#transcoder.encoding(encoding ?? this.#valueEncoding);
      }
      async open(options) {
        options = { ...this.#options, ...getOptions(options) };
        options.createIfMissing = options.createIfMissing !== false;
        options.errorIfExists = !!options.errorIfExists;
        const postopen = this.hooks.postopen.noop ? null : this.hooks.postopen.run;
        const passive = options.passive;
        if (passive && this.#deferOpen) {
          await void 0;
        }
        this.#assertUnlocked();
        while (this.#statusChange !== null) await this.#statusChange.catch(noop);
        this.#assertUnlocked();
        if (passive) {
          if (this.#status !== "open") throw new NotOpenError();
        } else if (this.#status === "closed" || this.#deferOpen) {
          this.#deferOpen = false;
          this.#statusChange = resolvedPromise;
          this.#statusChange = (async () => {
            this.#status = "opening";
            try {
              this.emit("opening");
              await this._open(options);
            } catch (err) {
              this.#status = "closed";
              this.#queue.drain();
              try {
                await this.#closeResources();
              } catch (resourceErr) {
                err = combineErrors([err, resourceErr]);
              }
              throw new NotOpenError(err);
            }
            this.#status = "open";
            if (postopen !== null) {
              let hookErr;
              try {
                this.#statusLocked = true;
                await postopen(options);
              } catch (err) {
                hookErr = convertRejection(err);
              } finally {
                this.#statusLocked = false;
              }
              if (hookErr) {
                this.#status = "closing";
                this.#queue.drain();
                try {
                  await this.#closeResources();
                  await this._close();
                } catch (closeErr) {
                  this.#statusLocked = true;
                  hookErr = combineErrors([hookErr, closeErr]);
                }
                this.#status = "closed";
                throw new ModuleError("The postopen hook failed on open()", {
                  code: "LEVEL_HOOK_ERROR",
                  cause: hookErr
                });
              }
            }
            this.#queue.drain();
            this.emit("open");
          })();
          try {
            await this.#statusChange;
          } finally {
            this.#statusChange = null;
          }
        } else if (this.#status !== "open") {
          throw new NotOpenError();
        }
      }
      async _open(options) {
      }
      async close() {
        this.#assertUnlocked();
        while (this.#statusChange !== null) await this.#statusChange.catch(noop);
        this.#assertUnlocked();
        if (this.#status === "open" || this.#deferOpen) {
          const fromInitial = this.#deferOpen;
          this.#deferOpen = false;
          this.#statusChange = resolvedPromise;
          this.#statusChange = (async () => {
            this.#status = "closing";
            this.#queue.drain();
            try {
              this.emit("closing");
              await this.#closeResources();
              if (!fromInitial) await this._close();
            } catch (err) {
              this.#status = "open";
              this.#queue.drain();
              throw new NotClosedError(err);
            }
            this.#status = "closed";
            this.#queue.drain();
            this.emit("closed");
          })();
          try {
            await this.#statusChange;
          } finally {
            this.#statusChange = null;
          }
        } else if (this.#status !== "closed") {
          throw new NotClosedError();
        }
      }
      async #closeResources() {
        if (this.#resources.size === 0) {
          return;
        }
        const resources = Array.from(this.#resources);
        const promises = resources.map(closeResource);
        const results = await Promise.allSettled(promises);
        const errors = [];
        for (let i = 0; i < results.length; i++) {
          if (results[i].status === "fulfilled") {
            this.#resources.delete(resources[i]);
          } else {
            errors.push(convertRejection(results[i].reason));
          }
        }
        if (errors.length > 0) {
          throw combineErrors(errors);
        }
      }
      async _close() {
      }
      async get(key, options) {
        options = getOptions(options, this.#defaultOptions.entry);
        if (this.#status === "opening") {
          return this.deferAsync(() => this.get(key, options));
        }
        this.#assertOpen();
        this._assertValidKey(key);
        const snapshot = options.snapshot;
        const keyEncoding = this.keyEncoding(options.keyEncoding);
        const valueEncoding = this.valueEncoding(options.valueEncoding);
        const keyFormat = keyEncoding.format;
        const valueFormat = valueEncoding.format;
        if (options === this.#defaultOptions.entry) {
          options = this.#defaultOptions.entryFormat;
        } else if (options.keyEncoding !== keyFormat || options.valueEncoding !== valueFormat) {
          options = { ...options, keyEncoding: keyFormat, valueEncoding: valueFormat };
        }
        const encodedKey = keyEncoding.encode(key);
        const mappedKey = this.prefixKey(encodedKey, keyFormat, true);
        snapshot?.ref();
        let value;
        try {
          value = await this._get(mappedKey, options);
        } finally {
          snapshot?.unref();
        }
        try {
          return value === void 0 ? value : valueEncoding.decode(value);
        } catch (err) {
          throw new ModuleError("Could not decode value", {
            code: "LEVEL_DECODE_ERROR",
            cause: err
          });
        }
      }
      async _get(key, options) {
        return void 0;
      }
      getSync(key, options) {
        if (this.status !== "open") {
          throw new ModuleError("Database is not open", {
            code: "LEVEL_DATABASE_NOT_OPEN"
          });
        }
        this._assertValidKey(key);
        if (options == null) {
          const encodedKey2 = this.#keyEncoding.encode(key);
          const mappedKey2 = this.prefixKey(encodedKey2, this.#keyEncoding.format, true);
          const value2 = this._getSync(mappedKey2, this.#defaultOptions.entryFormat);
          try {
            return value2 !== void 0 ? this.#valueEncoding.decode(value2) : void 0;
          } catch (err) {
            throw new ModuleError("Could not decode value", {
              code: "LEVEL_DECODE_ERROR",
              cause: err
            });
          }
        }
        const snapshot = options.snapshot;
        const keyEncoding = this.keyEncoding(options.keyEncoding);
        const valueEncoding = this.valueEncoding(options.valueEncoding);
        const keyFormat = keyEncoding.format;
        const valueFormat = valueEncoding.format;
        if (options.keyEncoding !== keyFormat || options.valueEncoding !== valueFormat) {
          options = { ...options, keyEncoding: keyFormat, valueEncoding: valueFormat };
        }
        const encodedKey = keyEncoding.encode(key);
        const mappedKey = this.prefixKey(encodedKey, keyFormat, true);
        let value;
        snapshot?.ref();
        try {
          value = this._getSync(mappedKey, options);
        } finally {
          snapshot?.unref();
        }
        try {
          return value !== void 0 ? valueEncoding.decode(value) : void 0;
        } catch (err) {
          throw new ModuleError("Could not decode value", {
            code: "LEVEL_DECODE_ERROR",
            cause: err
          });
        }
      }
      _getSync(key, options) {
        throw new ModuleError("Database does not support getSync()", {
          code: "LEVEL_NOT_SUPPORTED"
        });
      }
      async getMany(keys, options) {
        options = getOptions(options, this.#defaultOptions.entry);
        if (this.#status === "opening") {
          return this.deferAsync(() => this.getMany(keys, options));
        }
        this.#assertOpen();
        if (!Array.isArray(keys)) {
          throw new TypeError("The first argument 'keys' must be an array");
        }
        if (keys.length === 0) {
          return [];
        }
        const snapshot = options.snapshot;
        const keyEncoding = this.keyEncoding(options.keyEncoding);
        const valueEncoding = this.valueEncoding(options.valueEncoding);
        const keyFormat = keyEncoding.format;
        const valueFormat = valueEncoding.format;
        if (options === this.#defaultOptions.entry) {
          options = this.#defaultOptions.entryFormat;
        } else if (options.keyEncoding !== keyFormat || options.valueEncoding !== valueFormat) {
          options = { ...options, keyEncoding: keyFormat, valueEncoding: valueFormat };
        }
        const mappedKeys = new Array(keys.length);
        for (let i = 0; i < keys.length; i++) {
          const key = keys[i];
          this._assertValidKey(key);
          mappedKeys[i] = this.prefixKey(keyEncoding.encode(key), keyFormat, true);
        }
        snapshot?.ref();
        let values;
        try {
          values = await this._getMany(mappedKeys, options);
        } finally {
          snapshot?.unref();
        }
        try {
          for (let i = 0; i < values.length; i++) {
            if (values[i] !== void 0) {
              values[i] = valueEncoding.decode(values[i]);
            }
          }
        } catch (err) {
          throw new ModuleError(`Could not decode one or more of ${values.length} value(s)`, {
            code: "LEVEL_DECODE_ERROR",
            cause: err
          });
        }
        return values;
      }
      async _getMany(keys, options) {
        return new Array(keys.length).fill(void 0);
      }
      async has(key, options) {
        options = getOptions(options, this.#defaultOptions.key);
        if (this.#status === "opening") {
          return this.deferAsync(() => this.has(key, options));
        }
        this.#assertOpen();
        this._assertValidKey(key);
        const snapshot = options.snapshot;
        const keyEncoding = this.keyEncoding(options.keyEncoding);
        const keyFormat = keyEncoding.format;
        if (options === this.#defaultOptions.key) {
          options = this.#defaultOptions.keyFormat;
        } else if (options.keyEncoding !== keyFormat) {
          options = { ...options, keyEncoding: keyFormat };
        }
        const encodedKey = keyEncoding.encode(key);
        const mappedKey = this.prefixKey(encodedKey, keyFormat, true);
        snapshot?.ref();
        try {
          return this._has(mappedKey, options);
        } finally {
          snapshot?.unref();
        }
      }
      async _has(key, options) {
        throw new ModuleError("Database does not support has()", {
          code: "LEVEL_NOT_SUPPORTED"
        });
      }
      async hasMany(keys, options) {
        options = getOptions(options, this.#defaultOptions.key);
        if (this.#status === "opening") {
          return this.deferAsync(() => this.hasMany(keys, options));
        }
        this.#assertOpen();
        if (!Array.isArray(keys)) {
          throw new TypeError("The first argument 'keys' must be an array");
        }
        if (keys.length === 0) {
          return [];
        }
        const snapshot = options.snapshot;
        const keyEncoding = this.keyEncoding(options.keyEncoding);
        const keyFormat = keyEncoding.format;
        if (options === this.#defaultOptions.key) {
          options = this.#defaultOptions.keyFormat;
        } else if (options.keyEncoding !== keyFormat) {
          options = { ...options, keyEncoding: keyFormat };
        }
        const mappedKeys = new Array(keys.length);
        for (let i = 0; i < keys.length; i++) {
          const key = keys[i];
          this._assertValidKey(key);
          mappedKeys[i] = this.prefixKey(keyEncoding.encode(key), keyFormat, true);
        }
        snapshot?.ref();
        try {
          return this._hasMany(mappedKeys, options);
        } finally {
          snapshot?.unref();
        }
      }
      async _hasMany(keys, options) {
        throw new ModuleError("Database does not support hasMany()", {
          code: "LEVEL_NOT_SUPPORTED"
        });
      }
      async put(key, value, options) {
        if (!this.hooks.prewrite.noop) {
          return this.batch([{ type: "put", key, value }], options);
        }
        options = getOptions(options, this.#defaultOptions.entry);
        if (this.#status === "opening") {
          return this.deferAsync(() => this.put(key, value, options));
        }
        this.#assertOpen();
        this._assertValidKey(key);
        this._assertValidValue(value);
        const keyEncoding = this.keyEncoding(options.keyEncoding);
        const valueEncoding = this.valueEncoding(options.valueEncoding);
        const keyFormat = keyEncoding.format;
        const valueFormat = valueEncoding.format;
        const enableWriteEvent = this.#eventMonitor.write;
        const original = options;
        if (options === this.#defaultOptions.entry) {
          options = this.#defaultOptions.entryFormat;
        } else if (options.keyEncoding !== keyFormat || options.valueEncoding !== valueFormat) {
          options = { ...options, keyEncoding: keyFormat, valueEncoding: valueFormat };
        }
        const encodedKey = keyEncoding.encode(key);
        const prefixedKey = this.prefixKey(encodedKey, keyFormat, true);
        const encodedValue = valueEncoding.encode(value);
        await this._put(prefixedKey, encodedValue, options);
        if (enableWriteEvent) {
          const op = {
            ...original,
            type: "put",
            key,
            value,
            keyEncoding,
            valueEncoding,
            encodedKey,
            encodedValue
          };
          this.emit("write", [op]);
        }
      }
      async _put(key, value, options) {
      }
      async del(key, options) {
        if (!this.hooks.prewrite.noop) {
          return this.batch([{ type: "del", key }], options);
        }
        options = getOptions(options, this.#defaultOptions.key);
        if (this.#status === "opening") {
          return this.deferAsync(() => this.del(key, options));
        }
        this.#assertOpen();
        this._assertValidKey(key);
        const keyEncoding = this.keyEncoding(options.keyEncoding);
        const keyFormat = keyEncoding.format;
        const enableWriteEvent = this.#eventMonitor.write;
        const original = options;
        if (options === this.#defaultOptions.key) {
          options = this.#defaultOptions.keyFormat;
        } else if (options.keyEncoding !== keyFormat) {
          options = { ...options, keyEncoding: keyFormat };
        }
        const encodedKey = keyEncoding.encode(key);
        const prefixedKey = this.prefixKey(encodedKey, keyFormat, true);
        await this._del(prefixedKey, options);
        if (enableWriteEvent) {
          const op = {
            ...original,
            type: "del",
            key,
            keyEncoding,
            encodedKey
          };
          this.emit("write", [op]);
        }
      }
      async _del(key, options) {
      }
      // TODO (future): add way for implementations to declare which options are for the
      // whole batch rather than defaults for individual operations. E.g. the sync option
      // of classic-level, that should not be copied to individual operations.
      batch(operations, options) {
        if (!arguments.length) {
          this.#assertOpen();
          return this._chainedBatch();
        }
        options = getOptions(options, this.#defaultOptions.empty);
        return this.#arrayBatch(operations, options);
      }
      // Wrapped for async error handling
      async #arrayBatch(operations, options) {
        if (this.#status === "opening") {
          return this.deferAsync(() => this.#arrayBatch(operations, options));
        }
        this.#assertOpen();
        if (!Array.isArray(operations)) {
          throw new TypeError("The first argument 'operations' must be an array");
        }
        if (operations.length === 0) {
          return;
        }
        const length = operations.length;
        const enablePrewriteHook = !this.hooks.prewrite.noop;
        const enableWriteEvent = this.#eventMonitor.write;
        const publicOperations = enableWriteEvent ? new Array(length) : null;
        const privateOperations = new Array(length);
        const prewriteBatch = enablePrewriteHook ? new PrewriteBatch(this, privateOperations, publicOperations) : null;
        for (let i = 0; i < length; i++) {
          const op = { ...options, ...operations[i] };
          const isPut = op.type === "put";
          const delegated = op.sublevel != null;
          const db = delegated ? op.sublevel : this;
          db._assertValidKey(op.key);
          op.keyEncoding = db.keyEncoding(op.keyEncoding);
          if (isPut) {
            db._assertValidValue(op.value);
            op.valueEncoding = db.valueEncoding(op.valueEncoding);
          } else if (op.type !== "del") {
            throw new TypeError("A batch operation must have a type property that is 'put' or 'del'");
          }
          if (enablePrewriteHook) {
            try {
              this.hooks.prewrite.run(op, prewriteBatch);
              op.keyEncoding = db.keyEncoding(op.keyEncoding);
              if (isPut) op.valueEncoding = db.valueEncoding(op.valueEncoding);
            } catch (err) {
              throw new ModuleError("The prewrite hook failed on batch()", {
                code: "LEVEL_HOOK_ERROR",
                cause: err
              });
            }
          }
          const keyEncoding = op.keyEncoding;
          const preencodedKey = keyEncoding.encode(op.key);
          const keyFormat = keyEncoding.format;
          const siblings = delegated && !isDescendant(op.sublevel, this) && op.sublevel !== this;
          const encodedKey = delegated && !siblings ? prefixDescendantKey(preencodedKey, keyFormat, db, this) : preencodedKey;
          if (delegated && !siblings) {
            op.sublevel = null;
          }
          let publicOperation = null;
          if (enableWriteEvent && !siblings) {
            publicOperation = { ...op };
            publicOperation.encodedKey = encodedKey;
            if (delegated) {
              publicOperation.key = encodedKey;
              publicOperation.keyEncoding = this.keyEncoding(keyFormat);
            }
            publicOperations[i] = publicOperation;
          }
          op.key = siblings ? encodedKey : this.prefixKey(encodedKey, keyFormat, true);
          op.keyEncoding = keyFormat;
          if (isPut) {
            const valueEncoding = op.valueEncoding;
            const encodedValue = valueEncoding.encode(op.value);
            const valueFormat = valueEncoding.format;
            op.value = encodedValue;
            op.valueEncoding = valueFormat;
            if (enableWriteEvent && !siblings) {
              publicOperation.encodedValue = encodedValue;
              if (delegated) {
                publicOperation.value = encodedValue;
                publicOperation.valueEncoding = this.valueEncoding(valueFormat);
              }
            }
          }
          privateOperations[i] = op;
        }
        await this._batch(privateOperations, options);
        if (enableWriteEvent) {
          this.emit("write", publicOperations);
        }
      }
      async _batch(operations, options) {
      }
      sublevel(name, options) {
        const xopts = AbstractSublevel.defaults(options);
        const sublevel = this._sublevel(name, xopts);
        if (!this.hooks.newsub.noop) {
          try {
            this.hooks.newsub.run(sublevel, xopts);
          } catch (err) {
            throw new ModuleError("The newsub hook failed on sublevel()", {
              code: "LEVEL_HOOK_ERROR",
              cause: err
            });
          }
        }
        return sublevel;
      }
      _sublevel(name, options) {
        return new AbstractSublevel(this, name, options);
      }
      prefixKey(key, keyFormat, local) {
        return key;
      }
      async clear(options) {
        options = getOptions(options, this.#defaultOptions.empty);
        if (this.#status === "opening") {
          return this.deferAsync(() => this.clear(options));
        }
        this.#assertOpen();
        const original = options;
        const keyEncoding = this.keyEncoding(options.keyEncoding);
        const snapshot = options.snapshot;
        options = rangeOptions(options, keyEncoding);
        options.keyEncoding = keyEncoding.format;
        if (options.limit !== 0) {
          snapshot?.ref();
          try {
            await this._clear(options);
          } finally {
            snapshot?.unref();
          }
          this.emit("clear", original);
        }
      }
      async _clear(options) {
      }
      iterator(options) {
        const keyEncoding = this.keyEncoding(options?.keyEncoding);
        const valueEncoding = this.valueEncoding(options?.valueEncoding);
        options = rangeOptions(options, keyEncoding);
        options.keys = options.keys !== false;
        options.values = options.values !== false;
        options[AbstractIterator.keyEncoding] = keyEncoding;
        options[AbstractIterator.valueEncoding] = valueEncoding;
        options.keyEncoding = keyEncoding.format;
        options.valueEncoding = valueEncoding.format;
        if (this.#status === "opening") {
          return new DeferredIterator(this, options);
        }
        this.#assertOpen();
        return this._iterator(options);
      }
      _iterator(options) {
        return new AbstractIterator(this, options);
      }
      keys(options) {
        const keyEncoding = this.keyEncoding(options?.keyEncoding);
        const valueEncoding = this.valueEncoding(options?.valueEncoding);
        options = rangeOptions(options, keyEncoding);
        options[AbstractIterator.keyEncoding] = keyEncoding;
        options[AbstractIterator.valueEncoding] = valueEncoding;
        options.keyEncoding = keyEncoding.format;
        options.valueEncoding = valueEncoding.format;
        if (this.#status === "opening") {
          return new DeferredKeyIterator(this, options);
        }
        this.#assertOpen();
        return this._keys(options);
      }
      _keys(options) {
        return new DefaultKeyIterator(this, options);
      }
      values(options) {
        const keyEncoding = this.keyEncoding(options?.keyEncoding);
        const valueEncoding = this.valueEncoding(options?.valueEncoding);
        options = rangeOptions(options, keyEncoding);
        options[AbstractIterator.keyEncoding] = keyEncoding;
        options[AbstractIterator.valueEncoding] = valueEncoding;
        options.keyEncoding = keyEncoding.format;
        options.valueEncoding = valueEncoding.format;
        if (this.#status === "opening") {
          return new DeferredValueIterator(this, options);
        }
        this.#assertOpen();
        return this._values(options);
      }
      _values(options) {
        return new DefaultValueIterator(this, options);
      }
      snapshot(options) {
        this.#assertOpen();
        if (typeof options !== "object" || options === null) {
          options = this.#defaultOptions.owner;
        } else if (options.owner == null) {
          options = { ...options, owner: this };
        }
        return this._snapshot(options);
      }
      _snapshot(options) {
        throw new ModuleError("Database does not support explicit snapshots", {
          code: "LEVEL_NOT_SUPPORTED"
        });
      }
      defer(fn, options) {
        if (typeof fn !== "function") {
          throw new TypeError("The first argument must be a function");
        }
        this.#queue.add(function(abortError) {
          if (!abortError) fn();
        }, options);
      }
      deferAsync(fn, options) {
        if (typeof fn !== "function") {
          throw new TypeError("The first argument must be a function");
        }
        return new Promise((resolve, reject) => {
          this.#queue.add(function(abortError) {
            if (abortError) reject(abortError);
            else fn().then(resolve, reject);
          }, options);
        });
      }
      attachResource(resource) {
        if (typeof resource !== "object" || resource === null || typeof resource.close !== "function") {
          throw new TypeError("The first argument must be a resource object");
        }
        this.#resources.add(resource);
      }
      detachResource(resource) {
        this.#resources.delete(resource);
      }
      _chainedBatch() {
        return new DefaultChainedBatch(this);
      }
      _assertValidKey(key) {
        if (key === null || key === void 0) {
          throw new ModuleError("Key cannot be null or undefined", {
            code: "LEVEL_INVALID_KEY"
          });
        }
      }
      _assertValidValue(value) {
        if (value === null || value === void 0) {
          throw new ModuleError("Value cannot be null or undefined", {
            code: "LEVEL_INVALID_VALUE"
          });
        }
      }
      #assertOpen() {
        if (this.#status !== "open") {
          throw new ModuleError("Database is not open", {
            code: "LEVEL_DATABASE_NOT_OPEN"
          });
        }
      }
      #assertUnlocked() {
        if (this.#statusLocked) {
          throw new ModuleError("Database status is locked", {
            code: "LEVEL_STATUS_LOCKED"
          });
        }
      }
    };
    var { AbstractSublevel } = require_abstract_sublevel()({ AbstractLevel });
    exports2.AbstractLevel = AbstractLevel;
    exports2.AbstractSublevel = AbstractSublevel;
    if (typeof Symbol.asyncDispose === "symbol") {
      AbstractLevel.prototype[Symbol.asyncDispose] = async function() {
        return this.close();
      };
    }
    var formats = function(db) {
      return Object.keys(db.supports.encodings).filter((k) => !!db.supports.encodings[k]);
    };
    var closeResource = function(resource) {
      return resource.close();
    };
    var convertRejection = function(reason) {
      if (reason instanceof Error) {
        return reason;
      }
      if (Object.prototype.toString.call(reason) === "[object Error]") {
        return reason;
      }
      const hint = reason === null ? "null" : typeof reason;
      const msg = `Promise rejection reason must be an Error, received ${hint}`;
      return new TypeError(msg);
    };
    var NotOpenError = class extends ModuleError {
      constructor(cause) {
        super("Database failed to open", {
          code: "LEVEL_DATABASE_NOT_OPEN",
          cause
        });
      }
    };
    var NotClosedError = class extends ModuleError {
      constructor(cause) {
        super("Database failed to close", {
          code: "LEVEL_DATABASE_NOT_CLOSED",
          cause
        });
      }
    };
  }
});

// node_modules/abstract-level/abstract-snapshot.js
var require_abstract_snapshot = __commonJS({
  "node_modules/abstract-level/abstract-snapshot.js"(exports2) {
    "use strict";
    var ModuleError = require_module_error();
    var { noop } = require_common();
    var AbstractSnapshot = class {
      #open = true;
      #referenceCount = 0;
      #pendingClose = null;
      #closePromise = null;
      #owner;
      constructor(options) {
        const owner = options.owner;
        if (typeof owner !== "object" || owner === null) {
          const hint = owner === null ? "null" : typeof owner;
          throw new TypeError(`Owner must be an abstract-level database, received ${hint}`);
        }
        this.#owner = owner;
        this.#owner.attachResource(this);
      }
      ref() {
        if (!this.#open) {
          throw new ModuleError("Snapshot is not open: cannot use snapshot after close()", {
            code: "LEVEL_SNAPSHOT_NOT_OPEN"
          });
        }
        this.#referenceCount++;
      }
      unref() {
        if (--this.#referenceCount === 0) {
          this.#pendingClose?.();
        }
      }
      async close() {
        if (this.#closePromise !== null) {
          return this.#closePromise.catch(noop);
        }
        this.#open = false;
        this.#closePromise = new Promise((resolve, reject) => {
          this.#pendingClose = () => {
            this.#pendingClose = null;
            privateClose(this, this.#owner).then(resolve, reject);
          };
        });
        if (this.#referenceCount === 0) {
          this.#pendingClose();
        }
        return this.#closePromise;
      }
      async _close() {
      }
    };
    if (typeof Symbol.asyncDispose === "symbol") {
      AbstractSnapshot.prototype[Symbol.asyncDispose] = async function() {
        return this.close();
      };
    }
    var privateClose = async function(snapshot, owner) {
      await snapshot._close();
      owner.detachResource(snapshot);
    };
    exports2.AbstractSnapshot = AbstractSnapshot;
  }
});

// node_modules/abstract-level/index.js
var require_abstract_level2 = __commonJS({
  "node_modules/abstract-level/index.js"(exports2) {
    "use strict";
    exports2.AbstractLevel = require_abstract_level().AbstractLevel;
    exports2.AbstractSublevel = require_abstract_level().AbstractSublevel;
    exports2.AbstractIterator = require_abstract_iterator().AbstractIterator;
    exports2.AbstractKeyIterator = require_abstract_iterator().AbstractKeyIterator;
    exports2.AbstractValueIterator = require_abstract_iterator().AbstractValueIterator;
    exports2.AbstractChainedBatch = require_abstract_chained_batch().AbstractChainedBatch;
    exports2.AbstractSnapshot = require_abstract_snapshot().AbstractSnapshot;
  }
});

// chrome-level-binding:binding
var require_binding = __commonJS({
  "chrome-level-binding:binding"(exports2, module2) {
    module2.exports = require(require("node:path").join(__dirname, "ChromeLevelDB.node"));
  }
});

// node_modules/classic-level/chained-batch.js
var require_chained_batch = __commonJS({
  "node_modules/classic-level/chained-batch.js"(exports2) {
    "use strict";
    var { AbstractChainedBatch } = require_abstract_level2();
    var binding = require_binding();
    var kContext = /* @__PURE__ */ Symbol("context");
    var ChainedBatch = class extends AbstractChainedBatch {
      constructor(db, context) {
        super(db);
        this[kContext] = binding.batch_init(context);
      }
      _put(key, value) {
        binding.batch_put(this[kContext], key, value);
      }
      _del(key) {
        binding.batch_del(this[kContext], key);
      }
      _clear() {
        binding.batch_clear(this[kContext]);
      }
      async _write(options) {
        return binding.batch_write(this[kContext], options);
      }
      async _close() {
      }
    };
    exports2.ChainedBatch = ChainedBatch;
  }
});

// node_modules/classic-level/iterator.js
var require_iterator = __commonJS({
  "node_modules/classic-level/iterator.js"(exports2) {
    "use strict";
    var { AbstractIterator } = require_abstract_level2();
    var binding = require_binding();
    var kContext = /* @__PURE__ */ Symbol("context");
    var kCache = /* @__PURE__ */ Symbol("cache");
    var kFirst = /* @__PURE__ */ Symbol("first");
    var kPosition = /* @__PURE__ */ Symbol("position");
    var kState = /* @__PURE__ */ Symbol("state");
    var kSignal = /* @__PURE__ */ Symbol("signal");
    var kAbort = /* @__PURE__ */ Symbol("abort");
    var empty = [];
    var STATE_ENDED = 1;
    var Iterator = class extends AbstractIterator {
      constructor(db, context, options, snapshotCtx) {
        super(db, options);
        this[kState] = new Uint8Array(1);
        this[kContext] = binding.iterator_init(context, this[kState], options, snapshotCtx);
        this[kFirst] = true;
        this[kCache] = empty;
        this[kPosition] = 0;
        this[kAbort] = this[kAbort].bind(this);
        if (options.signal != null) {
          this[kSignal] = options.signal;
          this[kSignal].addEventListener("abort", this[kAbort], { once: true });
        } else {
          this[kSignal] = null;
        }
      }
      _seek(target, options) {
        this[kFirst] = true;
        this[kCache] = empty;
        this[kState][0] &= ~STATE_ENDED;
        this[kPosition] = 0;
        binding.iterator_seek(this[kContext], target);
      }
      async _next() {
        if (this[kPosition] < this[kCache].length) {
          return this[kCache][this[kPosition]++];
        }
        if ((this[kState][0] & STATE_ENDED) !== 0) {
          return void 0;
        }
        if (this[kFirst]) {
          this[kFirst] = false;
          this[kCache] = await binding.iterator_nextv(this[kContext], 1);
          this[kPosition] = 0;
        } else {
          this[kCache] = await binding.iterator_nextv(this[kContext], 1e3);
          this[kPosition] = 0;
        }
        if (this[kPosition] < this[kCache].length) {
          return this[kCache][this[kPosition]++];
        }
      }
      async _nextv(size, options) {
        this[kFirst] = false;
        if (this[kPosition] < this[kCache].length) {
          const length = Math.min(size, this[kCache].length - this[kPosition]);
          const chunk = this[kCache].slice(this[kPosition], this[kPosition] + length);
          this[kPosition] += length;
          return chunk;
        }
        if ((this[kState][0] & STATE_ENDED) !== 0) {
          return [];
        }
        return binding.iterator_nextv(this[kContext], size);
      }
      async _close() {
        this[kCache] = empty;
        if (this[kSignal] !== null) {
          this[kSignal].removeEventListener("abort", this[kAbort]);
          this[kSignal] = null;
        }
        binding.iterator_close(this[kContext]);
      }
      [kAbort]() {
        this[kSignal] = null;
        binding.iterator_abort(this[kContext]);
      }
      // Undocumented, exposed for tests only
      get cached() {
        return this[kCache].length - this[kPosition];
      }
    };
    exports2.Iterator = Iterator;
  }
});

// node_modules/classic-level/index.js
var require_classic_level = __commonJS({
  "node_modules/classic-level/index.js"(exports2) {
    "use strict";
    var { AbstractLevel, AbstractSnapshot } = require_abstract_level2();
    var ModuleError = require_module_error();
    var fsp = require("fs/promises");
    var binding = require_binding();
    var { ChainedBatch } = require_chained_batch();
    var { Iterator } = require_iterator();
    var kContext = /* @__PURE__ */ Symbol("context");
    var kLocation = /* @__PURE__ */ Symbol("location");
    var ClassicLevel2 = class extends AbstractLevel {
      #sharedBuffer = null;
      constructor(location, options) {
        if (typeof location !== "string" || location === "") {
          throw new TypeError("The first argument 'location' must be a non-empty string");
        }
        super({
          encodings: {
            buffer: true,
            utf8: true,
            view: true
          },
          has: true,
          createIfMissing: true,
          errorIfExists: true,
          explicitSnapshots: true,
          getSync: true,
          additionalMethods: {
            approximateSize: true,
            compactRange: true
          },
          signals: {
            iterators: true
          }
        }, options);
        this[kLocation] = location;
        this[kContext] = binding.db_init();
      }
      get location() {
        return this[kLocation];
      }
      async _open(options) {
        if (options.createIfMissing) {
          await fsp.mkdir(this[kLocation], { recursive: true });
        }
        return binding.db_open(this[kContext], this[kLocation], options);
      }
      async _close() {
        return binding.db_close(this[kContext]);
      }
      async _put(key, value, options) {
        return binding.db_put(this[kContext], key, value, options);
      }
      async _get(key, options) {
        let flags = 0;
        if (options.fillCache !== false) flags |= FLAG_FILL_CACHE;
        if (options.valueEncoding !== "utf8") flags |= FLAG_VALUE_AS_BUFFER;
        if (options.keyEncoding !== "utf8") {
          flags |= FLAG_KEY_AS_BUFFER;
          if (key.buffer.resizable) {
            key = new Uint8Array(key);
          }
        }
        return binding.db_get(
          this[kContext],
          flags,
          key,
          options.snapshot?.[kContext]
        );
      }
      _getSync(key, options) {
        let flags = 0;
        if (options.fillCache !== false) flags |= FLAG_FILL_CACHE;
        if (options.valueEncoding !== "utf8") flags |= FLAG_VALUE_AS_BUFFER;
        if (options.keyEncoding !== "utf8") {
          return binding.db_get_sync(
            this[kContext],
            flags,
            key,
            options.snapshot?.[kContext]
          );
        } else {
          let keySize;
          if (this.#sharedBuffer === null) {
            keySize = this.#createSharedBuffer(key);
          } else {
            keySize = this.#sharedBuffer.write(key);
            if (keySize === this.#sharedBuffer.byteLength) {
              keySize = this.#createSharedBuffer(key);
            }
          }
          return binding.db_get_sync(
            this[kContext],
            flags | FLAG_SHARED_KEY,
            keySize,
            options.snapshot?.[kContext]
          );
        }
      }
      #createSharedBuffer(str) {
        this.#sharedBuffer = Buffer.allocUnsafe(Buffer.byteLength(str) + 64);
        binding.db_set_shared_buffer(this[kContext], this.#sharedBuffer);
        return this.#sharedBuffer.write(str);
      }
      async _getMany(keys, options) {
        return binding.db_get_many(
          this[kContext],
          keys,
          options,
          options.snapshot?.[kContext]
        );
      }
      async _has(key, options) {
        return binding.db_has(
          this[kContext],
          key,
          options.fillCache,
          options.snapshot?.[kContext]
        );
      }
      async _hasMany(keys, options) {
        const wordCount = keys.length + 32 >>> 5;
        const buffer = new ArrayBuffer(wordCount * 4);
        const bitset = new Uint32Array(buffer);
        await binding.db_has_many(
          this[kContext],
          keys,
          options.fillCache,
          options.snapshot?.[kContext],
          buffer
        );
        const values = new Array(keys.length);
        for (let i = 0; i < values.length; i++) {
          values[i] = (bitset[i >>> 5] & 1 << (i & 31)) !== 0;
        }
        return values;
      }
      async _del(key, options) {
        return binding.db_del(this[kContext], key, options);
      }
      async _clear(options) {
        return binding.db_clear(
          this[kContext],
          options,
          options.snapshot?.[kContext]
        );
      }
      _chainedBatch() {
        return new ChainedBatch(this, this[kContext]);
      }
      async _batch(operations, options) {
        return binding.batch_do(this[kContext], operations, options);
      }
      async approximateSize(start, end, options) {
        if (arguments.length < 2) {
          throw new TypeError("The arguments 'start' and 'end' are required");
        } else if (typeof options !== "object") {
          options = null;
        }
        if (this.status === "opening") {
          return this.deferAsync(() => this.approximateSize(start, end, options));
        } else if (this.status !== "open") {
          throw new ModuleError("Database is not open: cannot call approximateSize()", {
            code: "LEVEL_DATABASE_NOT_OPEN"
          });
        } else {
          const keyEncoding = this.keyEncoding(options && options.keyEncoding);
          start = keyEncoding.encode(start);
          end = keyEncoding.encode(end);
          return binding.db_approximate_size(this[kContext], start, end);
        }
      }
      async compactRange(start, end, options) {
        if (arguments.length < 2) {
          throw new TypeError("The arguments 'start' and 'end' are required");
        } else if (typeof options !== "object") {
          options = null;
        }
        if (this.status === "opening") {
          return this.deferAsync(() => this.compactRange(start, end, options));
        } else if (this.status !== "open") {
          throw new ModuleError("Database is not open: cannot call compactRange()", {
            code: "LEVEL_DATABASE_NOT_OPEN"
          });
        } else {
          const keyEncoding = this.keyEncoding(options && options.keyEncoding);
          start = keyEncoding.encode(start);
          end = keyEncoding.encode(end);
          return binding.db_compact_range(this[kContext], start, end);
        }
      }
      getProperty(property) {
        if (typeof property !== "string") {
          throw new TypeError("The first argument 'property' must be a string");
        }
        if (this.status !== "open") {
          throw new ModuleError("Database is not open", {
            code: "LEVEL_DATABASE_NOT_OPEN"
          });
        }
        return binding.db_get_property(this[kContext], property);
      }
      _iterator(options) {
        return new Iterator(
          this,
          this[kContext],
          options,
          options.snapshot?.[kContext]
        );
      }
      _snapshot(options) {
        return new Snapshot(this[kContext], options);
      }
      static async destroy(location) {
        if (typeof location !== "string" || location === "") {
          throw new TypeError("The first argument 'location' must be a non-empty string");
        }
        return binding.destroy_db(location);
      }
      static async repair(location) {
        if (typeof location !== "string" || location === "") {
          throw new TypeError("The first argument 'location' must be a non-empty string");
        }
        return binding.repair_db(location);
      }
    };
    var Snapshot = class extends AbstractSnapshot {
      constructor(context, options) {
        super(options);
        this[kContext] = binding.snapshot_init(context);
      }
      async _close() {
        binding.snapshot_close(this[kContext]);
      }
    };
    exports2.ClassicLevel = ClassicLevel2;
    var FLAG_FILL_CACHE = 1;
    var FLAG_KEY_AS_BUFFER = 2;
    var FLAG_VALUE_AS_BUFFER = 4;
    var FLAG_SHARED_KEY = 8;
  }
});

// src/automation/chrome-mcs-framing.js
var require_chrome_mcs_framing = __commonJS({
  "src/automation/chrome-mcs-framing.js"(exports2, module2) {
    "use strict";
    var VERSION = 41;
    var DEFAULT_MAX_FRAME = 64 * 1024;
    var fault = () => Object.assign(new Error("X_CHROME_MCS_FRAME_INVALID"), { code: "X_CHROME_MCS_FRAME_INVALID" });
    function encodeLength(size) {
      const result = [];
      do {
        let byte = size % 128;
        size = Math.floor(size / 128);
        if (size) byte |= 128;
        result.push(byte);
      } while (size);
      return Buffer.from(result);
    }
    function encodeFrame(tag, payload, { first = false, maxFrame = DEFAULT_MAX_FRAME } = {}) {
      if (!Number.isInteger(tag) || tag < 0 || tag > 15 || !Buffer.isBuffer(payload) || !Number.isInteger(maxFrame) || maxFrame < 0 || maxFrame > DEFAULT_MAX_FRAME || payload.length > maxFrame || typeof first !== "boolean") throw fault();
      return Buffer.concat([first ? Buffer.from([VERSION, tag]) : Buffer.from([tag]), encodeLength(payload.length), payload]);
    }
    function createFrameDecoder({ maxFrame = DEFAULT_MAX_FRAME } = {}) {
      if (!Number.isInteger(maxFrame) || maxFrame < 0 || maxFrame > DEFAULT_MAX_FRAME) throw fault();
      let state = "version", tag, size = 0, shift = 0, count = 0, payload, position = 0, failed = false;
      function push(chunk) {
        if (failed || !Buffer.isBuffer(chunk)) throw fault();
        const frames = [];
        try {
          for (let i = 0; i < chunk.length; i++) {
            const byte = chunk[i];
            if (state === "version") {
              if (byte !== 38 && byte < VERSION) throw fault();
              state = "tag";
            } else if (state === "tag") {
              if (byte > 15) throw fault();
              tag = byte;
              size = 0;
              shift = 0;
              count = 0;
              state = "size";
            } else if (state === "size") {
              count++;
              if (count > 5 || count === 5 && byte & 240) throw fault();
              size += (byte & 127) * 2 ** shift;
              shift += 7;
              if (size > maxFrame) throw fault();
              if (!(byte & 128)) {
                if (count > 1 && byte === 0) throw fault();
                payload = Buffer.alloc(size);
                position = 0;
                if (size === 0) {
                  frames.push({ tag, payload });
                  state = "tag";
                } else state = "payload";
              }
            } else {
              const n = Math.min(size - position, chunk.length - i);
              chunk.copy(payload, position, i, i + n);
              position += n;
              i += n - 1;
              if (position === size) {
                frames.push({ tag, payload });
                state = "tag";
              }
            }
            if (frames.length > 1024) throw fault();
          }
          return frames;
        } catch (error) {
          failed = true;
          throw error;
        }
      }
      function finish() {
        if (failed || state !== "tag") {
          failed = true;
          throw fault();
        }
      }
      return { push, finish };
    }
    module2.exports = { createFrameDecoder, encodeFrame, VERSION, DEFAULT_MAX_FRAME };
  }
});

// src/automation/chrome-mcs-protobuf.js
var require_chrome_mcs_protobuf = __commonJS({
  "src/automation/chrome-mcs-protobuf.js"(exports2, module2) {
    "use strict";
    var { TextDecoder: TextDecoder2 } = require("node:util");
    var { createPrivateKey, createPublicKey, timingSafeEqual } = require("node:crypto");
    var { DEFAULT_MAX_FRAME } = require_chrome_mcs_framing();
    var fault = () => Object.assign(new Error("X_CHROME_MCS_PROTO_INVALID"), { code: "X_CHROME_MCS_PROTO_INVALID" });
    var utf8 = new TextDecoder2("utf-8", { fatal: true });
    var U64_MAX = (1n << 64n) - 1n;
    function varint(value) {
      let n = BigInt(value);
      if (n < 0n || n > U64_MAX) throw fault();
      const bytes2 = [];
      do {
        let b = Number(n & 127n);
        n >>= 7n;
        if (n) b |= 128;
        bytes2.push(b);
      } while (n);
      return Buffer.from(bytes2);
    }
    function uint(field, value) {
      return Buffer.concat([varint(field * 8), varint(value)]);
    }
    function bytes(field, value) {
      const body = Buffer.isBuffer(value) ? value : Buffer.from(value, "utf8");
      return Buffer.concat([varint(field * 8 + 2), varint(body.length), body]);
    }
    function readVarint(buffer, offset) {
      let n = 0n;
      for (let i = 0; i < 10; i++) {
        if (offset + i >= buffer.length) throw fault();
        const b = buffer[offset + i];
        if (i === 9 && b > 1) throw fault();
        n |= BigInt(b & 127) << BigInt(i * 7);
        if (!(b & 128)) return { value: n, next: offset + i + 1 };
      }
      throw fault();
    }
    function fields(buffer) {
      if (!Buffer.isBuffer(buffer) || buffer.length > DEFAULT_MAX_FRAME) throw fault();
      const result = [];
      let pos = 0;
      while (pos < buffer.length) {
        if (result.length >= 256) throw fault();
        const key = readVarint(buffer, pos);
        pos = key.next;
        const num = Number(key.value >> 3n), wire = Number(key.value & 7n);
        if (!Number.isSafeInteger(num) || num < 1 || num > 536870911) throw fault();
        let value;
        if (wire === 0) {
          const v = readVarint(buffer, pos);
          value = v.value;
          pos = v.next;
        } else if (wire === 2) {
          const len = readVarint(buffer, pos);
          pos = len.next;
          if (len.value > BigInt(buffer.length - pos)) throw fault();
          const end = pos + Number(len.value);
          value = buffer.subarray(pos, end);
          pos = end;
        } else if (wire === 1 || wire === 5) {
          const end = pos + (wire === 1 ? 8 : 4);
          if (end > buffer.length) throw fault();
          value = buffer.subarray(pos, end);
          pos = end;
        } else throw fault();
        result.push({ num, wire, value });
      }
      return result;
    }
    function one(list, num, wire, required = true) {
      const hits = list.filter((field) => field.num === num);
      if (hits.length > 1 || required && hits.length !== 1 || hits.length && hits[0].wire !== wire) throw fault();
      return hits[0]?.value;
    }
    function text(value, max = 2048) {
      if (!Buffer.isBuffer(value) || value.length > max) throw fault();
      try {
        return utf8.decode(value);
      } catch {
        throw fault();
      }
    }
    function decimal(value) {
      if (typeof value !== "string" || !/^(?:0|[1-9][0-9]{0,19})$/.test(value)) throw fault();
      const number = BigInt(value);
      if (number === 0n || number > U64_MAX) throw fault();
      return number;
    }
    function loginRequest({ deviceId, securityToken, clientVersion, receivedIds = [] }) {
      const id = decimal(deviceId);
      decimal(securityToken);
      if (typeof clientVersion !== "string" || !/^[0-9.]{1,40}$/.test(clientVersion) || !Array.isArray(receivedIds) || receivedIds.length > 100) throw fault();
      const setting = Buffer.concat([bytes(1, "new_vc"), bytes(2, "1")]);
      const result = [
        bytes(1, "chrome-" + clientVersion),
        bytes(2, "mcs.android.com"),
        bytes(3, deviceId),
        bytes(4, deviceId),
        bytes(5, securityToken),
        bytes(6, "android-" + id.toString(16)),
        bytes(8, setting)
      ];
      for (const entry of receivedIds) {
        if (typeof entry !== "string" || !entry || Buffer.byteLength(entry) > 256) throw fault();
        result.push(bytes(10, entry));
      }
      result.push(uint(12, 0), uint(14, 1), uint(16, 2), uint(17, 1));
      return Buffer.concat(result);
    }
    function loginResponse(buffer) {
      const list = fields(buffer);
      text(one(list, 1, 2));
      const error = one(list, 3, 2, false);
      if (error) {
        const info = fields(error);
        const code = one(info, 1, 0);
        if (code > 0x7fffffffn) throw fault();
        if (code !== 0n) return { accepted: false, code: Number(code) };
      }
      const config = one(list, 7, 2, false);
      if (config) {
        const interval = one(fields(config), 3, 0, false);
        if (interval !== void 0 && interval > 0n) {
          if (interval < 1000n || interval > 3600000n) throw fault();
          return { accepted: true, heartbeatIntervalMs: Number(interval) };
        }
      }
      return { accepted: true };
    }
    function dataMessage(buffer, { expectedCategory, expectedAppId, expectedSender }) {
      if (typeof expectedCategory !== "string" || !expectedCategory || Buffer.byteLength(expectedCategory) > 256 || typeof expectedAppId !== "string" || !expectedAppId || Buffer.byteLength(expectedAppId) > 256 || typeof expectedSender !== "string" || !expectedSender || Buffer.byteLength(expectedSender) > 1024) throw fault();
      const list = fields(buffer);
      const category = text(one(list, 5, 2), 256);
      if (category !== expectedCategory) return { matches: false };
      let subtype;
      for (const entry of list.filter((field) => field.num === 7)) {
        if (entry.wire !== 2) throw fault();
        const pair = fields(entry.value), key = text(one(pair, 1, 2), 128);
        if (key === "subtype") {
          if (subtype !== void 0) throw fault();
          subtype = text(one(pair, 2, 2), 256);
        }
      }
      if (subtype !== expectedAppId) return { matches: false };
      const from = text(one(list, 3, 2), 1024);
      if (from !== expectedSender) return { matches: false };
      const persistent = one(list, 9, 2, false);
      const raw = one(list, 21, 2, false);
      const headers = /* @__PURE__ */ Object.create(null);
      let messageType;
      for (const entry of list.filter((field) => field.num === 7)) {
        if (entry.wire !== 2) throw fault();
        const pair = fields(entry.value);
        const key = text(one(pair, 1, 2), 128), value = text(one(pair, 2, 2), 4096);
        if (key === "message_type") {
          if (messageType !== void 0) throw fault();
          messageType = value;
        }
        if (["content-encoding", "crypto-key", "encryption", "_googRawData"].includes(key)) {
          if (Object.hasOwn(headers, key)) throw fault();
          headers[key] = value;
        }
      }
      if (messageType === "deleted_messages" || messageType === "send_error")
        return { matches: true, control: messageType, persistentId: persistent?.length ? text(persistent, 256) : null };
      if (messageType !== void 0 && messageType !== "gcm") throw fault();
      return {
        matches: true,
        from,
        persistentId: persistent ? text(persistent, 256) : null,
        rawData: raw ? Buffer.from(raw) : Buffer.alloc(0),
        headers
      };
    }
    function inspectControlMessage(buffer) {
      const list = fields(buffer), category = text(one(list, 5, 2), 256);
      if (category !== "com.google.android.gsf.gtalkservice") return null;
      let idle = false;
      for (const entry of list.filter((item) => item.num === 7)) {
        if (entry.wire !== 2) throw fault();
        const pair = fields(entry.value), key = text(one(pair, 1, 2), 128);
        if (key === "IdleNotification") idle = true;
      }
      return { idle };
    }
    function idleResponse(lastReceived, nowMs) {
      if (!Number.isSafeInteger(nowMs) || nowMs < 0) throw fault();
      const appData = Buffer.concat([bytes(1, "IdleNotification"), bytes(2, "false")]);
      const sent = Math.floor(nowMs / 1e3) + 11644473600;
      return Buffer.concat([
        bytes(3, "gcm@android.com"),
        bytes(5, "com.google.android.gsf.gtalkservice"),
        bytes(7, appData),
        uint(11, sequence(lastReceived)),
        uint(17, 0),
        uint(18, sent)
      ]);
    }
    function encryptedPayload(message) {
      if (!message || message.matches !== true || !Buffer.isBuffer(message.rawData) || !message.headers) throw fault();
      const encoding = message.headers["content-encoding"];
      let data = message.rawData;
      if (!data.length && typeof message.headers._googRawData === "string") {
        const raw = message.headers._googRawData;
        if (!/^[A-Za-z0-9+/]+={0,2}$/.test(raw) || raw.length > DEFAULT_MAX_FRAME) throw fault();
        data = Buffer.from(raw, "base64");
        if (data.toString("base64").replace(/=+$/, "") !== raw.replace(/=+$/, "")) throw fault();
      }
      if (!data.length || data.length > DEFAULT_MAX_FRAME) throw fault();
      if (encoding === "aes128gcm") return { data, headers: { encoding } };
      if ((encoding === void 0 || encoding === "aesgcm") && message.headers.encryption && message.headers["crypto-key"])
        return { data, headers: { encoding: "aesgcm", encryption: message.headers.encryption, crypto_key: message.headers["crypto-key"] } };
      throw fault();
    }
    function selectiveAck(ids) {
      if (!Array.isArray(ids) || ids.length < 1 || ids.length > 100) throw fault();
      const ack = Buffer.concat(ids.map((id) => {
        if (typeof id !== "string" || !id || Buffer.byteLength(id) > 256) throw fault();
        return bytes(1, id);
      }));
      const extension = Buffer.concat([uint(1, 12), bytes(2, ack)]);
      return Buffer.concat([uint(2, 1), bytes(3, ""), bytes(7, extension)]);
    }
    function sequence(value) {
      if (!Number.isInteger(value) || value < 1 || value > 2147483647) throw fault();
      return value;
    }
    function streamAck(lastReceived) {
      const extension = Buffer.concat([uint(1, 13), bytes(2, "")]);
      return Buffer.concat([uint(2, 1), bytes(3, ""), bytes(7, extension), uint(10, sequence(lastReceived))]);
    }
    function heartbeatAck(lastReceived) {
      return uint(2, sequence(lastReceived));
    }
    function lastStreamReceived(tag, buffer) {
      const fieldByTag = { 0: 2, 1: 2, 3: 6, 7: 10, 8: 11 };
      if (!Object.hasOwn(fieldByTag, tag)) throw fault();
      const value = one(fields(buffer), fieldByTag[tag], 0, false);
      if (value === void 0 || value === 0n) return 0;
      if (value > 0x7fffffffn) throw fault();
      return Number(value);
    }
    function readEncryptionData(buffer, { expectedAppId, expectedPublicKey, expectedAuthSecret }) {
      if (typeof expectedAppId !== "string" || !expectedAppId || !Buffer.isBuffer(expectedPublicKey) || expectedPublicKey.length !== 65 || !Buffer.isBuffer(expectedAuthSecret) || expectedAuthSecret.length !== 16) throw fault();
      const list = fields(buffer);
      if (list.some((item) => item.num === 2)) throw fault();
      const appId = text(one(list, 1, 2), 256);
      if (appId !== expectedAppId) throw fault();
      const entityBytes = one(list, 4, 2, false);
      const authorizedEntity = entityBytes === void 0 ? "" : text(entityBytes, 1024);
      const auth = one(list, 3, 2), der = one(list, 5, 2);
      if (auth.length !== 16 || !timingSafeEqual(auth, expectedAuthSecret) || der.length > 1024) throw fault();
      try {
        const key = createPrivateKey({ key: der, format: "der", type: "pkcs8" });
        const jwk = key.export({ format: "jwk" });
        if (jwk.kty !== "EC" || jwk.crv !== "P-256") throw fault();
        const pub = createPublicKey(key).export({ format: "jwk" });
        const publicBytes = Buffer.concat([Buffer.from([4]), Buffer.from(pub.x, "base64url"), Buffer.from(pub.y, "base64url")]);
        if (publicBytes.length !== 65 || !timingSafeEqual(publicBytes, expectedPublicKey)) throw fault();
        return { authorizedEntity, privateKey: { kty: "EC", crv: "P-256", x: jwk.x, y: jwk.y, d: jwk.d } };
      } catch {
        throw fault();
      }
    }
    module2.exports = { loginRequest, loginResponse, dataMessage, inspectControlMessage, idleResponse, encryptedPayload, selectiveAck, streamAck, heartbeatAck, lastStreamReceived, readEncryptionData };
  }
});

// src/automation/chrome-x-transfer.js
var require_chrome_x_transfer = __commonJS({
  "src/automation/chrome-x-transfer.js"(exports2, module2) {
    "use strict";
    var { createECDH, createHash, timingSafeEqual } = require("node:crypto");
    var INVALID = () => Object.assign(new Error("X_CHROME_TRANSFER_INVALID"), { code: "X_CHROME_TRANSFER_INVALID" });
    var UUID_PART = "[0-9A-F]{8}-[0-9A-F]{4}-4[0-9A-F]{3}-[89AB][0-9A-F]{3}-[0-9A-F]{9}-V2";
    var APP_ID = new RegExp(`^wp:https://x\\.com/#${UUID_PART}$`);
    var U64_MAX = (1n << 64n) - 1n;
    function object(value, allowed) {
      if (!value || typeof value !== "object" || Array.isArray(value) || ![Object.prototype, null].includes(Object.getPrototypeOf(value))) throw INVALID();
      const descriptors = Object.getOwnPropertyDescriptors(value);
      const keys = Reflect.ownKeys(descriptors);
      if (keys.length !== allowed.length || keys.some((key) => typeof key !== "string" || !allowed.includes(key) || !Object.hasOwn(descriptors[key], "value"))) throw INVALID();
    }
    function decimal(value) {
      if (typeof value !== "string" || !/^[1-9][0-9]{0,19}$/.test(value) || BigInt(value) > U64_MAX) throw INVALID();
      return value;
    }
    function base64url(value, size) {
      if (typeof value !== "string" || !/^[A-Za-z0-9_-]+$/.test(value)) throw INVALID();
      const result = Buffer.from(value, "base64url");
      if (result.length !== size || result.toString("base64url") !== value) throw INVALID();
      return result;
    }
    function normalizeChromeTransfer(file, { allowMac = true, allowBraveMac = false } = {}) {
      try {
        object(file, ["format", "version", "provenance", "push"]);
        if (file.format !== "x-notification-subscription" || file.version !== 2) throw INVALID();
        const kindDescriptor = file.provenance && Object.getOwnPropertyDescriptor(file.provenance, "kind");
        const isBrave = kindDescriptor && Object.hasOwn(kindDescriptor, "value") && kindDescriptor.value === "brave-gcm";
        object(file.provenance, isBrave ? ["kind", "adapterVersion", "browserVersion", "engineVersion", "readMethod"] : ["kind", "adapterVersion", "browserVersion", "readMethod"]);
        const provenance = file.provenance;
        const versionPattern = /^[0-9]{1,3}(?:\.[0-9]{1,5}){3}$/;
        if (!isBrave && (provenance.kind !== "chrome-gcm" || provenance.readMethod !== "chrome-gcm-snapshot") || isBrave && (provenance.readMethod !== "brave-gcm-snapshot" || typeof provenance.engineVersion !== "string" || !versionPattern.test(provenance.engineVersion)) || provenance.adapterVersion !== "1.0.0" || typeof provenance.browserVersion !== "string" || !versionPattern.test(provenance.browserVersion)) throw INVALID();
        object(file.push, [
          "deviceId",
          "securityToken",
          "appId",
          "productCategory",
          "authorizedEntity",
          "scope",
          "p256dhPublicKey",
          "authenticationSecret",
          "p256dhPrivateKey"
        ]);
        const push = file.push;
        decimal(push.deviceId);
        decimal(push.securityToken);
        if (typeof push.appId !== "string" || !APP_ID.test(push.appId) || !(isBrave ? push.productCategory === "com.brave.windows" || allowMac === true && allowBraveMac === true && push.productCategory === "com.brave.macosx" : push.productCategory === "com.chrome.windows" || allowMac === true && push.productCategory === "com.chrome.macosx") || push.scope !== "https://x.com/" || typeof push.authorizedEntity !== "string" || !/^[A-Za-z0-9_-]{1,1024}$/.test(push.authorizedEntity)) throw INVALID();
        const publicKey = base64url(push.p256dhPublicKey, 65);
        base64url(push.authenticationSecret, 16);
        object(push.p256dhPrivateKey, ["kty", "crv", "x", "y", "d"]);
        const jwk = push.p256dhPrivateKey;
        if (jwk.kty !== "EC" || jwk.crv !== "P-256") throw INVALID();
        const x = base64url(jwk.x, 32), y = base64url(jwk.y, 32), d = base64url(jwk.d, 32);
        const expected = Buffer.concat([Buffer.from([4]), x, y]);
        const ecdh = createECDH("prime256v1");
        ecdh.setPrivateKey(d);
        if (!timingSafeEqual(publicKey, expected) || !timingSafeEqual(publicKey, ecdh.getPublicKey())) throw INVALID();
        return {
          format: file.format,
          version: 2,
          provenance: {
            kind: provenance.kind,
            adapterVersion: provenance.adapterVersion,
            browserVersion: provenance.browserVersion,
            ...isBrave ? { engineVersion: provenance.engineVersion } : {},
            readMethod: provenance.readMethod
          },
          push: {
            deviceId: push.deviceId,
            securityToken: push.securityToken,
            appId: push.appId,
            productCategory: push.productCategory,
            authorizedEntity: push.authorizedEntity,
            scope: push.scope,
            p256dhPublicKey: push.p256dhPublicKey,
            authenticationSecret: push.authenticationSecret,
            p256dhPrivateKey: { kty: "EC", crv: "P-256", x: jwk.x, y: jwk.y, d: jwk.d }
          }
        };
      } catch {
        throw INVALID();
      }
    }
    function identifyChromeTransfer(file) {
      const normalized = normalizeChromeTransfer(file), hash = (data) => createHash("sha256").update(data).digest("hex");
      return {
        deviceHash: hash("chrome-device\0" + normalized.push.deviceId),
        // Browser upgrades change provenance, not the Push subscription. Bind
        // idempotency to all device, routing and cryptographic material.
        appHash: hash("chrome-app\0" + normalized.push.appId),
        contentHash: hash(JSON.stringify(normalized.push))
      };
    }
    module2.exports = { normalizeChromeTransfer, identifyChromeTransfer, isChromeAppId: (value) => typeof value === "string" && APP_ID.test(value) };
  }
});

// src/automation/chrome-snapshot-reader.js
var require_chrome_snapshot_reader = __commonJS({
  "src/automation/chrome-snapshot-reader.js"(exports2, module2) {
    "use strict";
    var { readEncryptionData } = require_chrome_mcs_protobuf();
    var { normalizeChromeTransfer, isChromeAppId } = require_chrome_x_transfer();
    var fault = (code) => Object.assign(new Error(code), { code });
    function dataObject(value) {
      if (!value || typeof value !== "object" || Array.isArray(value) || ![Object.prototype, null].includes(Object.getPrototypeOf(value))) throw fault("X_CHROME_SNAPSHOT_INVALID");
      const descriptors = Object.getOwnPropertyDescriptors(value);
      if (Reflect.ownKeys(descriptors).some((key) => typeof key !== "string" || !Object.hasOwn(descriptors[key], "value"))) throw fault("X_CHROME_SNAPSHOT_INVALID");
      return value;
    }
    function bytes(value, length) {
      if (typeof value !== "string" || !/^[A-Za-z0-9_-]+$/.test(value)) throw fault("X_CHROME_SNAPSHOT_INVALID");
      const decoded = Buffer.from(value, "base64url");
      if (decoded.length !== length || decoded.toString("base64url") !== value) throw fault("X_CHROME_SNAPSHOT_INVALID");
      return decoded;
    }
    function selectChromeMapping(preferences, { allowMac = false, allowBraveMac = false } = {}) {
      dataObject(preferences);
      const gcm = dataObject(preferences.gcm);
      const map = dataObject(gcm.push_messaging_application_id_map);
      if (!["com.chrome.windows", "com.brave.windows"].includes(gcm.product_category_for_subtypes) && !(allowMac === true && gcm.product_category_for_subtypes === "com.chrome.macosx") && !(allowMac === true && allowBraveMac === true && gcm.product_category_for_subtypes === "com.brave.macosx")) throw fault("X_CHROME_SNAPSHOT_UNSUPPORTED");
      const entries = Object.entries(map);
      if (entries.length > 64 || entries.some(([id, value]) => typeof id !== "string" || typeof value !== "string" || value.length > 2048))
        throw fault("X_CHROME_SNAPSHOT_INVALID");
      const selected = entries.filter(([, value]) => value.split("#")[0] === "https://x.com/");
      if (selected.length !== 1) throw fault(selected.length ? "X_CHROME_SNAPSHOT_AMBIGUOUS" : "X_CHROME_SNAPSHOT_NOT_FOUND");
      if (!isChromeAppId(selected[0][0])) throw fault("X_CHROME_SNAPSHOT_INVALID");
      return { appId: selected[0][0], productCategory: gcm.product_category_for_subtypes, otherSubscriptionCount: entries.length - 1 };
    }
    function buildChromeTransfer({ preferences, subscription, records, deviceId, securityToken, browserVersion, engineVersion, allowMac = false, allowBraveMac = false }) {
      try {
        const selected = selectChromeMapping(preferences, { allowMac, allowBraveMac });
        dataObject(subscription);
        dataObject(subscription.keys);
        const origin = new URL(subscription.scope);
        const endpoint = new URL(subscription.endpoint);
        if (origin.origin !== "https://x.com" || origin.username || origin.password || origin.hash || origin.search || endpoint.protocol !== "https:" || endpoint.hostname !== "fcm.googleapis.com" || endpoint.port || endpoint.username || endpoint.password || endpoint.hash || endpoint.search || !endpoint.pathname.startsWith("/fcm/send/"))
          throw fault("X_CHROME_SNAPSHOT_INVALID");
        const appId = selected.appId;
        if (!Array.isArray(records) || records.length > 4) throw fault("X_CHROME_SNAPSHOT_INVALID");
        const candidates = records.filter((record) => {
          dataObject(record);
          return typeof record.key === "string" && (record.key === appId || record.key.startsWith(appId + ","));
        });
        if (candidates.length !== 1 || !Buffer.isBuffer(candidates[0].value)) throw fault("X_CHROME_SNAPSHOT_AMBIGUOUS");
        const keys = readEncryptionData(candidates[0].value, {
          expectedAppId: appId,
          expectedPublicKey: bytes(subscription.keys.p256dh, 65),
          expectedAuthSecret: bytes(subscription.keys.auth, 16)
        });
        if (!keys.authorizedEntity || candidates[0].key !== `${appId},${keys.authorizedEntity}`) throw fault("X_CHROME_SNAPSHOT_INVALID");
        const isBrave = ["com.brave.windows", "com.brave.macosx"].includes(selected.productCategory);
        const file = normalizeChromeTransfer({
          format: "x-notification-subscription",
          version: 2,
          provenance: isBrave ? { kind: "brave-gcm", adapterVersion: "1.0.0", browserVersion, engineVersion, readMethod: "brave-gcm-snapshot" } : { kind: "chrome-gcm", adapterVersion: "1.0.0", browserVersion, readMethod: "chrome-gcm-snapshot" },
          push: {
            deviceId,
            securityToken,
            appId,
            productCategory: selected.productCategory,
            authorizedEntity: keys.authorizedEntity,
            scope: "https://x.com/",
            p256dhPublicKey: subscription.keys.p256dh,
            authenticationSecret: subscription.keys.auth,
            p256dhPrivateKey: keys.privateKey
          }
        }, { allowMac, allowBraveMac });
        return { file, otherSubscriptionCount: selected.otherSubscriptionCount };
      } catch (error) {
        const code = typeof error?.code === "string" && /^X_CHROME_SNAPSHOT_[A-Z_]+$/.test(error.code) ? error.code : "X_CHROME_SNAPSHOT_INVALID";
        throw fault(code);
      }
    }
    module2.exports = { buildChromeTransfer, selectChromeMapping };
  }
});

// src/automation/chrome-mac-token-crypto.js
var require_chrome_mac_token_crypto = __commonJS({
  "src/automation/chrome-mac-token-crypto.js"(exports2, module2) {
    "use strict";
    var { pbkdf2Sync, createDecipheriv } = require("node:crypto");
    var fail = () => Object.assign(new Error("X_CHROME_MAC_TOKEN_INVALID"), { code: "X_CHROME_MAC_TOKEN_INVALID" });
    var MAX_U64 = (1n << 64n) - 1n;
    function decryptMacChromiumDeviceToken(encrypted, password) {
      if (!Buffer.isBuffer(encrypted) || ![19, 35].includes(encrypted.length) || !encrypted.subarray(0, 3).equals(Buffer.from("v10")) || !Buffer.isBuffer(password) || password.length < 1 || password.length > 4096) throw fail();
      let key, plain, partial, final;
      try {
        key = pbkdf2Sync(password, "saltysalt", 1003, 16, "sha1");
        const decipher = createDecipheriv("aes-128-cbc", key, Buffer.alloc(16, 32));
        partial = decipher.update(encrypted.subarray(3));
        final = decipher.final();
        plain = Buffer.concat([partial, final]);
        if (!plain.length || plain.length > 20 || plain.some((byte) => byte < 48 || byte > 57)) throw fail();
        const token = plain.toString("ascii");
        if (!/^[1-9][0-9]{0,19}$/.test(token) || BigInt(token) > MAX_U64) throw fail();
        return token;
      } catch {
        throw fail();
      } finally {
        key?.fill(0);
        partial?.fill(0);
        final?.fill(0);
        plain?.fill(0);
      }
    }
    module2.exports = { decryptMacChromiumDeviceToken };
  }
});

// src/automation/chrome-snapshot-io.js
var require_chrome_snapshot_io = __commonJS({
  "src/automation/chrome-snapshot-io.js"(exports2, module2) {
    "use strict";
    var fs = require("node:fs/promises");
    var path = require("node:path");
    var { createDecipheriv } = require("node:crypto");
    var { TextDecoder: TextDecoder2 } = require("node:util");
    var { buildChromeTransfer, selectChromeMapping } = require_chrome_snapshot_reader();
    var fault = (code) => Object.assign(new Error(code), { code });
    async function checked(root, parts, kind) {
      let current = root;
      for (const [index, component] of parts.entries()) {
        if (!component || component === "." || component === ".." || component.includes("/") || component.includes("\\")) throw fault("X_CHROME_SNAPSHOT_INVALID");
        current = path.join(current, component);
        const stat = await fs.lstat(current);
        if (stat.isSymbolicLink() || (index < parts.length - 1 ? !stat.isDirectory() : kind === "directory" ? !stat.isDirectory() : !stat.isFile()))
          throw fault("X_CHROME_SNAPSHOT_INVALID");
      }
      return current;
    }
    async function readBounded(root, parts, limit) {
      const filename = await checked(root, parts, "file"), handle = await fs.open(filename, "r");
      try {
        const stat = await handle.stat();
        if (!stat.isFile() || stat.size < 1 || stat.size > limit) throw fault("X_CHROME_SNAPSHOT_INVALID");
        const content = Buffer.alloc(stat.size + 1);
        let offset = 0;
        while (offset < content.length) {
          const { bytesRead } = await handle.read(content, offset, content.length - offset, offset);
          if (!bytesRead) break;
          offset += bytesRead;
        }
        if (offset !== stat.size) throw fault("X_CHROME_SNAPSHOT_INVALID");
        try {
          return new TextDecoder2("utf-8", { fatal: true }).decode(content.subarray(0, offset));
        } catch {
          throw fault("X_CHROME_SNAPSHOT_INVALID");
        }
      } finally {
        await handle.close();
      }
    }
    function b64(value) {
      if (typeof value !== "string" || !/^[A-Za-z0-9+/]+={0,2}$/.test(value) || value.length > 8192) throw fault("X_CHROME_SNAPSHOT_INVALID");
      const result = Buffer.from(value, "base64");
      if (result.toString("base64").replace(/=+$/, "") !== value.replace(/=+$/, "")) throw fault("X_CHROME_SNAPSHOT_INVALID");
      return result;
    }
    async function verifyLeveldb(directory, allowEncryptionDirectory) {
      const entries = await fs.readdir(directory, { withFileTypes: true });
      if (entries.length > 256) throw fault("X_CHROME_SNAPSHOT_INVALID");
      let total = 0;
      for (const entry of entries) {
        const candidate = path.join(directory, entry.name), stat = await fs.lstat(candidate);
        if (stat.isSymbolicLink()) throw fault("X_CHROME_SNAPSHOT_INVALID");
        if (entry.name === "Encryption" && allowEncryptionDirectory && stat.isDirectory()) continue;
        if (!stat.isFile() || !/^(?:CURRENT|LOCK|LOG|LOG\.old|MANIFEST-[0-9]+|[0-9]+\.(?:log|ldb|sst))$/.test(entry.name))
          throw fault("X_CHROME_SNAPSHOT_INVALID");
        total += stat.size;
        if (stat.size > 64 * 1024 * 1024 || total > 128 * 1024 * 1024) throw fault("X_CHROME_SNAPSHOT_INVALID");
      }
    }
    async function readChromeSnapshot2({ snapshotPath, token, subscription, browserVersion, engineVersion, dbFactory, unprotect, parseJson, platform = "windows", macPassword }) {
      let deviceStore, encryptionStore, key;
      try {
        if (typeof snapshotPath !== "string" || !path.isAbsolute(snapshotPath) || !/^[0-9a-f]{32}$/.test(token) || path.basename(snapshotPath) !== `chrome-snapshot-${token}` || typeof dbFactory !== "function" || !["windows", "macos"].includes(platform) || platform === "windows" && typeof unprotect !== "function" || platform === "macos" && !Buffer.isBuffer(macPassword) || typeof parseJson !== "function") throw fault("X_CHROME_SNAPSHOT_INVALID");
        const root = path.resolve(snapshotPath), rootStat = await fs.lstat(root), resolved = await fs.realpath(root);
        if (rootStat.isSymbolicLink() || !rootStat.isDirectory() || (process.platform === "win32" ? resolved.toLowerCase() !== root.toLowerCase() : resolved !== root)) throw fault("X_CHROME_SNAPSHOT_INVALID");
        const marker = parseJson(await readBounded(root, ["snapshot-owner.json"], 4096));
        if (!marker || marker.appId !== "x-notification-setup" || marker.kind !== "chrome-snapshot-v1" || marker.token !== token || Object.keys(marker).sort().join(",") !== "appId,kind,token") throw fault("X_CHROME_SNAPSHOT_INVALID");
        const preferences = parseJson(await readBounded(root, ["Default", "Preferences"], 4 * 1024 * 1024));
        const { appId, productCategory } = selectChromeMapping(preferences, { allowMac: platform === "macos" });
        if (platform === "macos" !== (productCategory === "com.chrome.macosx")) throw fault("X_CHROME_SNAPSHOT_UNSUPPORTED");
        if (platform === "windows") {
          const localState = parseJson(await readBounded(root, ["Local State"], 1024 * 1024));
          const wrapped = b64(localState?.os_crypt?.encrypted_key);
          if (wrapped.subarray(0, 5).toString("ascii") !== "DPAPI" || wrapped.length <= 5) throw fault("X_CHROME_SNAPSHOT_UNSUPPORTED");
          key = await unprotect(Buffer.from(wrapped.subarray(5)));
          if (!Buffer.isBuffer(key) || key.length !== 32) throw fault("X_CHROME_SNAPSHOT_UNSUPPORTED");
        }
        const storePath = await checked(root, ["Default", "GCM Store"], "directory");
        const encryptionPath = await checked(root, ["Default", "GCM Store", "Encryption"], "directory");
        await verifyLeveldb(storePath, true);
        await verifyLeveldb(encryptionPath, false);
        deviceStore = dbFactory(storePath);
        encryptionStore = dbFactory(encryptionPath);
        await deviceStore.open();
        await encryptionStore.open();
        const deviceId = (await deviceStore.get("device_aid_key")).toString("utf8");
        const tokenBytes = await deviceStore.get("device_token_key");
        let securityToken;
        if (platform === "macos") securityToken = require_chrome_mac_token_crypto().decryptMacChromiumDeviceToken(tokenBytes, macPassword);
        else {
          if (!Buffer.isBuffer(tokenBytes) || tokenBytes.length < 32 || tokenBytes.subarray(0, 3).toString("ascii") !== "v10")
            throw fault("X_CHROME_SNAPSHOT_UNSUPPORTED");
          const decipher = createDecipheriv("aes-256-gcm", key, tokenBytes.subarray(3, 15));
          decipher.setAuthTag(tokenBytes.subarray(-16));
          securityToken = Buffer.concat([decipher.update(tokenBytes.subarray(15, -16)), decipher.final()]).toString("utf8");
        }
        const records = [];
        for await (const [recordKey, value] of encryptionStore.iterator({ gte: appId, lt: appId + "\uFFFF", limit: 5 })) {
          if (records.length >= 4) throw fault("X_CHROME_SNAPSHOT_AMBIGUOUS");
          records.push({ key: recordKey, value });
        }
        return buildChromeTransfer({ preferences, subscription, records, deviceId, securityToken, browserVersion, engineVersion, allowMac: platform === "macos" });
      } catch (error) {
        const code = typeof error?.code === "string" && /^X_CHROME_SNAPSHOT_[A-Z_]+$/.test(error.code) ? error.code : "X_CHROME_SNAPSHOT_INVALID";
        throw fault(code);
      } finally {
        if (Buffer.isBuffer(key)) key.fill(0);
        if (encryptionStore) await encryptionStore.close().catch(() => {
        });
        if (deviceStore) await deviceStore.close().catch(() => {
        });
      }
    }
    module2.exports = { readChromeSnapshot: readChromeSnapshot2 };
  }
});

// src/automation/strict-json.js
var require_strict_json = __commonJS({
  "src/automation/strict-json.js"(exports2, module2) {
    "use strict";
    function parseUniqueJson2(source, maxDepth = 12) {
      const reject = () => {
        throw new Error("INVALID_JSON");
      };
      if (typeof source !== "string" || !Number.isInteger(maxDepth) || maxDepth < 1 || maxDepth > 64) reject();
      let offset = 0;
      const stringToken = /"(?:[^"\\\u0000-\u001f]|\\(?:["\\/bfnrt]|u[0-9a-fA-F]{4}))*"/y;
      const numberToken = /-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/y;
      const whitespace = () => {
        while (offset < source.length && /[ \t\r\n]/.test(source[offset])) offset++;
      };
      function readString() {
        stringToken.lastIndex = offset;
        const match = stringToken.exec(source);
        if (!match) reject();
        offset = stringToken.lastIndex;
        return JSON.parse(match[0]);
      }
      function value(depth) {
        if (depth > maxDepth) reject();
        whitespace();
        if (source[offset] === "{") {
          offset++;
          whitespace();
          const names = /* @__PURE__ */ new Set();
          if (source[offset] === "}") {
            offset++;
            return;
          }
          while (true) {
            whitespace();
            const name = readString();
            if (names.has(name) || ["__proto__", "prototype", "constructor"].includes(name)) reject();
            names.add(name);
            whitespace();
            if (source[offset++] !== ":") reject();
            value(depth + 1);
            whitespace();
            const next = source[offset++];
            if (next === "}") return;
            if (next !== ",") reject();
          }
        }
        if (source[offset] === "[") {
          offset++;
          whitespace();
          if (source[offset] === "]") {
            offset++;
            return;
          }
          while (true) {
            value(depth + 1);
            whitespace();
            const next = source[offset++];
            if (next === "]") return;
            if (next !== ",") reject();
          }
        }
        if (source[offset] === '"') {
          readString();
          return;
        }
        for (const literal of ["true", "false", "null"]) {
          if (source.startsWith(literal, offset)) {
            offset += literal.length;
            return;
          }
        }
        numberToken.lastIndex = offset;
        if (!numberToken.exec(source)) reject();
        offset = numberToken.lastIndex;
      }
      value(0);
      whitespace();
      if (offset !== source.length) reject();
      return JSON.parse(source);
    }
    module2.exports = { parseUniqueJson: parseUniqueJson2 };
  }
});

// scripts/chrome-setup-reader.cjs
var { ClassicLevel } = require_classic_level();
var { readChromeSnapshot } = require_chrome_snapshot_io();
var { parseUniqueJson } = require_strict_json();
async function main() {
  const chunks = [];
  let size = 0;
  for await (const chunk of process.stdin) {
    size += chunk.length;
    if (size > 32768) throw new Error("X_CHROME_READER_INPUT_INVALID");
    chunks.push(chunk);
  }
  const input = parseUniqueJson(Buffer.concat(chunks).toString("utf8"));
  if (!input || typeof input !== "object" || Array.isArray(input) || !["browserVersion,profileKey,snapshotPath,subscription,token", "browserVersion,engineVersion,profileKey,snapshotPath,subscription,token"].includes(Object.keys(input).sort().join(",")) || typeof input.profileKey !== "string" || !/^[A-Za-z0-9_-]{43}$/.test(input.profileKey)) throw new Error("X_CHROME_READER_INPUT_INVALID");
  const profileKey = Buffer.from(input.profileKey, "base64url");
  if (profileKey.length !== 32 || profileKey.toString("base64url") !== input.profileKey) throw new Error("X_CHROME_READER_INPUT_INVALID");
  try {
    const result = await readChromeSnapshot({
      snapshotPath: input.snapshotPath,
      token: input.token,
      subscription: input.subscription,
      browserVersion: input.browserVersion,
      engineVersion: input.engineVersion,
      unprotect: async () => Buffer.from(profileKey),
      parseJson: (text) => parseUniqueJson(text, 64),
      dbFactory: (location) => new ClassicLevel(location, { createIfMissing: false, keyEncoding: "utf8", valueEncoding: "buffer" })
    });
    process.stdout.write(JSON.stringify({ ok: true, ...result }));
  } finally {
    profileKey.fill(0);
  }
}
main().catch((error) => {
  const code = /^X_CHROME_(?:READER|SNAPSHOT)_[A-Z_]+$/.test(String(error?.code || error?.message || "")) ? String(error.code || error.message) : "X_CHROME_READER_FAILED";
  process.stdout.write(JSON.stringify({ ok: false, errorCode: code }));
  process.exitCode = 1;
});
