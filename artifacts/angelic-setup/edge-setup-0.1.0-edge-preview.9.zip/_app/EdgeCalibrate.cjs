"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// src/automation/strict-json.js
var require_strict_json = __commonJS({
  "src/automation/strict-json.js"(exports2, module2) {
    "use strict";
    function parseUniqueJson2(source, maxDepth = 12) {
      const reject = () => {
        throw new Error("INVALID_JSON");
      };
      if (typeof source !== "string" || !Number.isInteger(maxDepth) || maxDepth < 1 || maxDepth > 64) reject();
      let offset = 0;
      const stringToken = /"(?:[^"\\\u0000-\u001f]|\\(?:["\\/bfnrt]|u[0-9a-fA-F]{4}))*"/y;
      const numberToken = /-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/y;
      const whitespace = () => {
        while (offset < source.length && /[ \t\r\n]/.test(source[offset])) offset++;
      };
      function readString() {
        stringToken.lastIndex = offset;
        const match = stringToken.exec(source);
        if (!match) reject();
        offset = stringToken.lastIndex;
        return JSON.parse(match[0]);
      }
      function value(depth) {
        if (depth > maxDepth) reject();
        whitespace();
        if (source[offset] === "{") {
          offset++;
          whitespace();
          const names = /* @__PURE__ */ new Set();
          if (source[offset] === "}") {
            offset++;
            return;
          }
          while (true) {
            whitespace();
            const name = readString();
            if (names.has(name) || ["__proto__", "prototype", "constructor"].includes(name)) reject();
            names.add(name);
            whitespace();
            if (source[offset++] !== ":") reject();
            value(depth + 1);
            whitespace();
            const next = source[offset++];
            if (next === "}") return;
            if (next !== ",") reject();
          }
        }
        if (source[offset] === "[") {
          offset++;
          whitespace();
          if (source[offset] === "]") {
            offset++;
            return;
          }
          while (true) {
            value(depth + 1);
            whitespace();
            const next = source[offset++];
            if (next === "]") return;
            if (next !== ",") reject();
          }
        }
        if (source[offset] === '"') {
          readString();
          return;
        }
        for (const literal of ["true", "false", "null"]) {
          if (source.startsWith(literal, offset)) {
            offset += literal.length;
            return;
          }
        }
        numberToken.lastIndex = offset;
        if (!numberToken.exec(source)) reject();
        offset = numberToken.lastIndex;
      }
      value(0);
      whitespace();
      if (offset !== source.length) reject();
      return JSON.parse(source);
    }
    module2.exports = { parseUniqueJson: parseUniqueJson2 };
  }
});

// src/automation/edge-windows-peer.js
var require_edge_windows_peer = __commonJS({
  "src/automation/edge-windows-peer.js"(exports2, module2) {
    "use strict";
    var path2 = require("node:path");
    var { spawn } = require("node:child_process");
    var { parseUniqueJson: parseUniqueJson2 } = require_strict_json();
    var fail = () => Object.assign(new Error("X_EDGE_CALIBRATION_PEER_FAILED"), { code: "X_EDGE_CALIBRATION_PEER_FAILED" });
    function createWindowsEdgePeerVerifier2({ powershellPath, helperPath, timeoutMs = 1e4, spawnProcess = spawn }) {
      if (typeof powershellPath !== "string" || !path2.isAbsolute(powershellPath) || path2.basename(powershellPath).toLowerCase() !== "powershell.exe" || typeof helperPath !== "string" || !path2.isAbsolute(helperPath) || path2.basename(helperPath) !== "EdgePeerVerify.ps1" || !Number.isSafeInteger(timeoutMs) || timeoutMs < 100 || timeoutMs > 3e4 || typeof spawnProcess !== "function") throw fail();
      async function invoke(args) {
        return new Promise((resolve, reject) => {
          let child, done = false, data = Buffer.alloc(0), timer;
          function finish(error, value) {
            if (done) return;
            done = true;
            clearTimeout(timer);
            data.fill(0);
            if (error) reject(fail());
            else resolve(value);
          }
          try {
            child = spawnProcess(
              powershellPath,
              ["-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", helperPath, ...args],
              { shell: false, windowsHide: true, stdio: ["ignore", "pipe", "ignore"] }
            );
            if (!child || !child.stdout || typeof child.kill !== "function" || typeof child.once !== "function") throw new Error();
            timer = setTimeout(() => {
              try {
                child.kill();
              } catch {
              }
              finish(true);
            }, timeoutMs);
            child.stdout.on("data", (chunk) => {
              if (!Buffer.isBuffer(chunk) || data.length + chunk.length > 1024) {
                try {
                  child.kill();
                } catch {
                }
                finish(true);
                return;
              }
              data = Buffer.concat([data, chunk]);
            });
            child.stdout.once("error", () => {
              try {
                child.kill();
              } catch {
              }
              finish(true);
            });
            child.once("error", () => finish(true));
            child.once("close", (code) => {
              if (code !== 0) {
                finish(true);
                return;
              }
              try {
                finish(false, parseUniqueJson2(data.toString("utf8")));
              } catch {
                finish(true);
              }
            });
          } catch {
            if (child) try {
              child.kill();
            } catch {
            }
            finish(true);
          }
        });
      }
      async function captureIdentity(pid, executable) {
        if (!Number.isSafeInteger(pid) || pid <= 4 || typeof executable !== "string" || !path2.isAbsolute(executable)) throw fail();
        const result = await invoke(["-Mode", "Identity", "-BrowserPid", String(pid), "-BrowserExecutable", executable]);
        if (!result || Object.keys(result).sort().join(",") !== "ok,startTicks" || result.ok !== true || typeof result.startTicks !== "string" || !/^\d{18}$/.test(result.startTicks)) throw fail();
        return result.startTicks;
      }
      async function verifyExecutable(executable) {
        if (typeof executable !== "string" || !path2.isAbsolute(executable) || path2.basename(executable).toLowerCase() !== "msedge.exe") return false;
        try {
          const result = await invoke(["-Mode", "Verify", "-BrowserExecutable", executable]);
          return Boolean(result && Object.keys(result).join(",") === "ok" && result.ok === true);
        } catch {
          return false;
        }
      }
      async function authorizePeer({ clientPort, serverPort, browserPid, browserStartTicks, browserExecutable }) {
        if (!Number.isInteger(clientPort) || clientPort < 1024 || clientPort > 65535 || !Number.isInteger(serverPort) || serverPort < 1024 || serverPort > 65535 || !Number.isSafeInteger(browserPid) || browserPid <= 4 || typeof browserStartTicks !== "string" || !/^\d{18}$/.test(browserStartTicks) || typeof browserExecutable !== "string" || !path2.isAbsolute(browserExecutable)) return false;
        try {
          const result = await invoke([
            "-Mode",
            "Peer",
            "-BrowserPid",
            String(browserPid),
            "-BrowserExecutable",
            browserExecutable,
            "-BrowserStartTicks",
            browserStartTicks,
            "-ClientPort",
            String(clientPort),
            "-ServerPort",
            String(serverPort)
          ]);
          return Boolean(result && Object.keys(result).join(",") === "ok" && result.ok === true);
        } catch {
          return false;
        }
      }
      return Object.freeze({ verifyExecutable, captureIdentity, authorizePeer });
    }
    module2.exports = { createWindowsEdgePeerVerifier: createWindowsEdgePeerVerifier2 };
  }
});

// src/automation/edge-cdp-pipe.js
var require_edge_cdp_pipe = __commonJS({
  "src/automation/edge-cdp-pipe.js"(exports2, module2) {
    "use strict";
    var fault = (code) => Object.assign(new Error(code), { code });
    function createChromePipe(chrome, { origin = "https://x.com", timeoutMs = 1e4, includeApplicationServerKey = false, browserMode = "chrome", calibration = false } = {}) {
      if (!chrome?.stdio?.[3] || !chrome?.stdio?.[4] || typeof origin !== "string" || typeof includeApplicationServerKey !== "boolean" || typeof calibration !== "boolean" || !["chrome", "edge"].includes(browserMode) || !Number.isSafeInteger(timeoutMs) || timeoutMs < 100 || timeoutMs > 6e4 || origin !== "https://x.com" && !/^http:\/\/127\.0\.0\.1:[1-9][0-9]{0,4}$/.test(origin)) throw fault("X_CHROME_PIPE_INVALID");
      if (calibration) {
        try {
          if (browserMode !== "edge" || origin === "https://x.com" || new URL(origin).origin !== origin) throw new Error();
        } catch {
          throw fault("X_CHROME_PIPE_INVALID");
        }
      }
      const input = chrome.stdio[3], output = chrome.stdio[4], waiting = /* @__PURE__ */ new Map();
      let sequence = 0, buffer = Buffer.alloc(0), failed = false;
      function abort() {
        if (failed) return;
        failed = true;
        for (const item of waiting.values()) {
          clearTimeout(item.timer);
          item.reject(fault("X_CHROME_PIPE_CLOSED"));
        }
        waiting.clear();
      }
      output.on("data", (chunk) => {
        if (failed) return;
        if (!Buffer.isBuffer(chunk) || buffer.length + chunk.length > 1024 * 1024) {
          abort();
          return;
        }
        buffer = Buffer.concat([buffer, chunk]);
        for (; ; ) {
          const end = buffer.indexOf(0);
          if (end < 0) break;
          const frame = buffer.subarray(0, end);
          buffer = buffer.subarray(end + 1);
          try {
            const message = JSON.parse(frame.toString("utf8"));
            if (!Number.isSafeInteger(message.id) || !waiting.has(message.id)) continue;
            const item = waiting.get(message.id);
            waiting.delete(message.id);
            clearTimeout(item.timer);
            if (message.error || !message.result) item.reject(fault("X_CHROME_PIPE_COMMAND_FAILED"));
            else item.resolve(message.result);
          } catch {
            abort();
            return;
          }
        }
      });
      output.on("error", abort);
      output.on("end", abort);
      input.on("error", abort);
      chrome.on("error", abort);
      chrome.on("exit", abort);
      function call(method, params = {}, sessionId) {
        if (failed || waiting.size >= 4 || sequence >= Number.MAX_SAFE_INTEGER) return Promise.reject(fault("X_CHROME_PIPE_CLOSED"));
        const id = ++sequence, data = Buffer.from(JSON.stringify({ id, method, params, ...sessionId ? { sessionId } : {} }) + "\0");
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            waiting.delete(id);
            reject(fault("X_CHROME_PIPE_TIMEOUT"));
          }, timeoutMs);
          waiting.set(id, { resolve, reject, timer });
          try {
            input.write(data, (error) => {
              if (error) abort();
            });
          } catch {
            abort();
          }
        });
      }
      async function ready() {
        const version = await call("Browser.getVersion");
        const pattern = browserMode === "edge" ? /^Edg\/[0-9]{1,3}(?:\.[0-9]{1,5}){3}$/ : /^Chrome\/[0-9]{1,3}(?:\.[0-9]{1,5}){3}$/;
        if (typeof version.product !== "string" || !pattern.test(version.product)) throw fault("X_CHROME_PIPE_INVALID");
        return version.product.slice(version.product.indexOf("/") + 1);
      }
      async function capture() {
        const result = await call("Target.getTargets");
        if (!Array.isArray(result.targetInfos) || result.targetInfos.length > 256) throw fault("X_CHROME_CAPTURE_INVALID");
        const matches = result.targetInfos.filter((target) => {
          try {
            return target && target.type === "page" && new URL(target.url).origin === origin;
          } catch {
            return false;
          }
        });
        if (!matches.length) throw fault("X_CHROME_CAPTURE_NOT_FOUND");
        if (matches.length > 8 || new Set(matches.map((target) => target.browserContextId || "")).size !== 1 || matches.some((target) => typeof target.targetId !== "string" || !target.targetId || target.targetId.length > 256) || new Set(matches.map((target) => target.targetId)).size !== matches.length) throw fault("X_CHROME_CAPTURE_AMBIGUOUS");
        const captureTarget = async (target) => {
          const attached = await call("Target.attachToTarget", { targetId: target.targetId, flatten: true });
          if (typeof attached.sessionId !== "string" || attached.sessionId.length > 256) throw fault("X_CHROME_CAPTURE_INVALID");
          try {
            const expression = `(async()=>{if(location.origin!==${JSON.stringify(origin)})throw Error('origin');const found=[];for(const r of await navigator.serviceWorker.getRegistrations()){if(new URL(r.scope).origin!==${JSON.stringify(origin)})continue;const s=await r.pushManager.getSubscription();if(s){const v={scope:r.scope,...s.toJSON()};` + (includeApplicationServerKey ? `const k=s.options?.applicationServerKey;if(!k||k.byteLength!==65)throw Error('key');v.applicationServerKey=btoa(String.fromCharCode(...new Uint8Array(k))).replace(/\\+/g,'-').replace(/\\//g,'_').replace(/=+$/,'');` : "") + `found.push(v);}}if(location.origin!==${JSON.stringify(origin)}||found.length!==1)throw Error('subscription');return found[0]})()`;
            const response = await call("Runtime.evaluate", { expression, awaitPromise: true, returnByValue: true }, attached.sessionId);
            const value = response.result?.value;
            if (response.exceptionDetails || response.result?.type !== "object" || !value || typeof value.scope !== "string" || typeof value.endpoint !== "string" || value.scope.length > 4096 || value.endpoint.length > 4096 || !value.keys || typeof value.keys.p256dh !== "string" || typeof value.keys.auth !== "string" || includeApplicationServerKey && (typeof value.applicationServerKey !== "string" || !/^[A-Za-z0-9_-]{87}$/.test(value.applicationServerKey) || Buffer.from(value.applicationServerKey, "base64url").toString("base64url") !== value.applicationServerKey)) throw fault("X_CHROME_CAPTURE_INVALID");
            return {
              scope: value.scope,
              endpoint: value.endpoint,
              keys: { p256dh: value.keys.p256dh, auth: value.keys.auth },
              ...includeApplicationServerKey ? { applicationServerKey: value.applicationServerKey } : {}
            };
          } finally {
            await call("Target.detachFromTarget", { sessionId: attached.sessionId }).catch(() => {
            });
          }
        };
        let selected;
        for (const target of matches) {
          let value;
          try {
            value = await captureTarget(target);
          } catch (error) {
            if (matches.length > 1) throw fault("X_CHROME_CAPTURE_AMBIGUOUS");
            throw error;
          }
          if (selected && (value.scope !== selected.scope || value.endpoint !== selected.endpoint || value.keys.p256dh !== selected.keys.p256dh || value.keys.auth !== selected.keys.auth || includeApplicationServerKey && value.applicationServerKey !== selected.applicationServerKey))
            throw fault("X_CHROME_CAPTURE_AMBIGUOUS");
          selected = value;
        }
        return selected;
      }
      async function closeBrowser() {
        if (chrome.exitCode !== null) return;
        const exited = new Promise((resolve) => chrome.once("exit", resolve));
        await call("Browser.close").catch(() => {
        });
        let timer;
        try {
          await Promise.race([exited, new Promise((_resolve, reject) => {
            timer = setTimeout(() => reject(fault("X_CHROME_CAPTURE_TIMEOUT")), 15e3);
          })]);
        } finally {
          clearTimeout(timer);
        }
      }
      async function prepareCalibration(applicationServerKey) {
        if (!calibration || typeof applicationServerKey !== "string" || !/^[A-Za-z0-9_-]{87}$/.test(applicationServerKey)) throw fault("X_CHROME_PIPE_INVALID");
        const key = Buffer.from(applicationServerKey, "base64url");
        try {
          if (key.length !== 65 || key.toString("base64url") !== applicationServerKey || key[0] !== 4) throw fault("X_CHROME_PIPE_INVALID");
          require("node:crypto").ECDH.convertKey(key, "prime256v1", void 0, void 0, "uncompressed");
        } catch {
          throw fault("X_CHROME_PIPE_INVALID");
        } finally {
          key.fill(0);
        }
        await call("Browser.grantPermissions", { origin, permissions: ["notifications"] });
        const target = await call("Target.createTarget", { url: "about:blank" });
        if (typeof target.targetId !== "string" || !target.targetId || target.targetId.length > 256) throw fault("X_CHROME_PIPE_INVALID");
        const attached = await call("Target.attachToTarget", { targetId: target.targetId, flatten: true });
        if (typeof attached.sessionId !== "string" || !attached.sessionId || attached.sessionId.length > 256) throw fault("X_CHROME_PIPE_INVALID");
        try {
          await call("Page.enable", {}, attached.sessionId);
          await call("Page.navigate", { url: `${origin}/` }, attached.sessionId);
          const deadline = Date.now() + timeoutMs;
          let loaded = false;
          while (Date.now() < deadline) {
            const state = await call("Runtime.evaluate", { expression: "location.origin", returnByValue: true }, attached.sessionId);
            if (state.result?.value === origin) {
              loaded = true;
              break;
            }
            await new Promise((resolve) => setTimeout(resolve, 100));
          }
          if (!loaded) throw fault("X_CHROME_PIPE_TIMEOUT");
          const expression = `(async()=>{if(location.origin!==${JSON.stringify(origin)})throw Error('origin');const v=${JSON.stringify(applicationServerKey)}.replace(/-/g,'+').replace(/_/g,'/');const key=Uint8Array.from(atob(v),c=>c.charCodeAt(0));const r=await navigator.serviceWorker.register('/sw.js');await navigator.serviceWorker.ready;const s=await r.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:key});return Boolean(s&&s.endpoint)})()`;
          const response = await call("Runtime.evaluate", { expression, awaitPromise: true, returnByValue: true }, attached.sessionId);
          if (response.exceptionDetails || response.result?.value !== true) throw fault("X_CHROME_PIPE_INVALID");
          return true;
        } finally {
          await call("Target.detachFromTarget", { sessionId: attached.sessionId }).catch(() => {
          });
        }
      }
      return { ready, capture, closeBrowser, ...calibration ? { prepareCalibration } : {} };
    }
    module2.exports = { createChromePipe };
  }
});

// src/automation/edge-wns-framing.js
var require_edge_wns_framing = __commonJS({
  "src/automation/edge-wns-framing.js"(exports2, module2) {
    "use strict";
    var MAX_HEADER = 512;
    var MAX_PAYLOAD = 256 * 1024;
    var MAX_CHUNK = MAX_HEADER + 2 + MAX_PAYLOAD;
    var MAX_FRAMES_PER_CHUNK = 1024;
    var fail = () => Object.assign(new Error("X_EDGE_WNS_FRAME_INVALID"), { code: "X_EDGE_WNS_FRAME_INVALID" });
    function createFrameDecoder({ maxPayload = MAX_PAYLOAD } = {}) {
      if (!Number.isSafeInteger(maxPayload) || maxPayload < 0 || maxPayload > MAX_PAYLOAD) throw fail();
      const header = Buffer.alloc(MAX_HEADER);
      let headerLength = 0, sawCr = false;
      let payload = null, payloadLength = 0, payloadPosition = 0, failed = false, finished = false;
      function clear() {
        header.fill(0);
        payload?.fill(0);
        payload = null;
        headerLength = 0;
        payloadLength = 0;
        payloadPosition = 0;
        sawCr = false;
      }
      function emit(frames) {
        const frame = Buffer.allocUnsafe(headerLength + 2 + payloadLength);
        header.copy(frame, 0, 0, headerLength);
        frame[headerLength] = 13;
        frame[headerLength + 1] = 10;
        if (payloadLength) payload.copy(frame, headerLength + 2);
        frames.push(frame);
        clear();
        if (frames.length > MAX_FRAMES_PER_CHUNK) throw fail();
      }
      function push(chunk) {
        if (failed || finished) throw fail();
        if (!Buffer.isBuffer(chunk) || chunk.length > MAX_CHUNK) {
          clear();
          failed = true;
          throw fail();
        }
        const frames = [];
        try {
          for (let i = 0; i < chunk.length; i++) {
            if (payload !== null) {
              const count = Math.min(payloadLength - payloadPosition, chunk.length - i);
              chunk.copy(payload, payloadPosition, i, i + count);
              payloadPosition += count;
              i += count - 1;
              if (payloadPosition === payloadLength) emit(frames);
              continue;
            }
            const byte = chunk[i];
            if (sawCr) {
              if (byte !== 10) throw fail();
              const line = header.subarray(0, headerLength).toString("ascii");
              if (!/^[\x21-\x7e]+(?: [\x21-\x7e]+)* [0-9]{1,6}$/.test(line)) throw fail();
              const size = Number(line.slice(line.lastIndexOf(" ") + 1));
              if (size > maxPayload) throw fail();
              payloadLength = size;
              payloadPosition = 0;
              sawCr = false;
              if (!size) emit(frames);
              else payload = Buffer.alloc(size);
            } else if (byte === 13) sawCr = true;
            else {
              if (byte < 32 || byte > 126 || headerLength >= MAX_HEADER) throw fail();
              header[headerLength++] = byte;
            }
          }
          return frames;
        } catch (error) {
          for (const frame of frames) frame.fill(0);
          clear();
          failed = true;
          throw error;
        }
      }
      function finish() {
        if (failed || finished || headerLength || sawCr || payload !== null) {
          clear();
          failed = true;
          throw fail();
        }
        clear();
        finished = true;
      }
      return Object.freeze({ push, finish });
    }
    module2.exports = { createFrameDecoder, MAX_HEADER, MAX_PAYLOAD, MAX_CHUNK };
  }
});

// src/automation/edge-wns-client-metadata.js
var require_edge_wns_client_metadata = __commonJS({
  "src/automation/edge-wns-client-metadata.js"(exports2, module2) {
    "use strict";
    var { MAX_HEADER, MAX_PAYLOAD } = require_edge_wns_framing();
    var fail = () => Object.assign(new Error("X_EDGE_WNS_METADATA_INVALID"), { code: "X_EDGE_WNS_METADATA_INVALID" });
    function occurrences(buffer, text) {
      const needle = Buffer.from(text, "ascii");
      let index = 0, count = 0;
      while ((index = buffer.indexOf(needle, index)) !== -1) {
        count++;
        index += needle.length;
      }
      return count;
    }
    function parseEdgeClientMetadata(frame) {
      try {
        if (!Buffer.isBuffer(frame) || frame.length > MAX_HEADER + 2 + MAX_PAYLOAD) throw fail();
        const end = frame.indexOf("\r\n"), separator = frame.indexOf("\r\n\r\n", end + 2);
        if (end < 0 || end > MAX_HEADER || separator < end + 2 || separator - end - 2 > 8192) throw fail();
        const head = frame.subarray(0, end);
        if (head.some((byte) => byte < 32 || byte > 126)) throw fail();
        const parts = head.toString("ascii").split(" "), size = parts.at(-1);
        if (parts.length !== 5 || parts[0] !== "BND" || !/^[1-9]\d{0,6}$/.test(parts[1]) || parts[2] !== "CON\\WNS" || !/^[0-9a-f]{1,16}$/i.test(parts[3]) || !/^\d{1,6}$/.test(size) || Number(size) !== frame.length - end - 2) throw fail();
        const headers = frame.subarray(end + 2, separator);
        if (headers.some((byte) => byte !== 9 && byte !== 10 && byte !== 13 && (byte < 32 || byte > 126))) throw fail();
        for (const line of headers.toString("ascii").split("\r\n")) {
          const colon = line.indexOf(":");
          if (colon < 1 || !/^[A-Za-z][A-Za-z0-9-]{0,63}$/.test(line.slice(0, colon)) || /[\r\n]/.test(line.slice(colon + 1))) throw fail();
        }
        const body = frame.subarray(separator + 4);
        if (!body.length || body.length > 16384 || body.some((byte) => byte < 32 || byte > 126) || body.includes(Buffer.from("&")) || body.includes(Buffer.from("<!")) || body.includes(Buffer.from("<?")) || !body.subarray(-15).equals(Buffer.from("</client></wns>"))) throw fail();
        if (occurrences(body, "<client>") !== 1 || occurrences(body, "</client>") !== 1 || occurrences(body, "<name>") !== 1 || occurrences(body, "</name>") !== 1 || occurrences(body, "<ver>") !== 2 || occurrences(body, "</ver>") !== 2) throw fail();
        const prefix = body.subarray(0, Math.min(body.length, 512)).toString("ascii");
        const match = /^<wns><ver>([^<]{1,32})<\/ver><client><name>([^<]{1,128})<\/name><ver>([^<]{1,64})<\/ver>/.exec(prefix);
        if (!match || match.slice(1).some((value) => !/^[\x20-\x7e]+$/.test(value) || /[<>&]/.test(value))) throw fail();
        return { channel: parts[3], protocolVersion: match[1], clientName: match[2], clientVersion: match[3] };
      } catch {
        throw fail();
      }
    }
    module2.exports = { parseEdgeClientMetadata };
  }
});

// src/automation/edge-wns-agent-metadata.js
var require_edge_wns_agent_metadata = __commonJS({
  "src/automation/edge-wns-agent-metadata.js"(exports2, module2) {
    "use strict";
    var { MAX_HEADER, MAX_PAYLOAD } = require_edge_wns_framing();
    var fail = () => Object.assign(new Error("X_EDGE_WNS_AGENT_INVALID"), { code: "X_EDGE_WNS_AGENT_INVALID" });
    function parseEdgeAgentMetadata(frame) {
      try {
        if (!Buffer.isBuffer(frame) || frame.length > MAX_HEADER + 2 + MAX_PAYLOAD) throw fail();
        const end = frame.indexOf("\r\n"), separator = frame.indexOf("\r\n\r\n", end + 2);
        if (end < 0 || end > MAX_HEADER || separator < end + 2 || separator - end - 2 > 8192) throw fail();
        const command = frame.subarray(0, end);
        if (command.some((byte) => byte < 32 || byte > 126)) throw fail();
        const parts = command.toString("ascii").split(" "), size = parts.at(-1);
        if (parts.length !== 4 || parts[0] !== "CNT" || !/^[1-9]\d{0,6}$/.test(parts[1]) || parts[2] !== "CON" || !/^\d{1,6}$/.test(size) || Number(size) !== frame.length - end - 2) throw fail();
        const headers = frame.subarray(end + 2, separator);
        if (headers.some((byte) => byte !== 9 && byte !== 10 && byte !== 13 && (byte < 32 || byte > 126))) throw fail();
        for (const line of headers.toString("ascii").split("\r\n")) {
          const colon = line.indexOf(":");
          if (colon < 1 || !/^[A-Za-z][A-Za-z0-9-]{0,63}$/.test(line.slice(0, colon)) || /[\r\n]/.test(line.slice(colon + 1))) throw fail();
        }
        const body = frame.subarray(separator + 4);
        if (!body.length || body.length > 4096 || body.some((byte) => byte < 32 || byte > 126)) throw fail();
        const match = /^<connect><ver>([12])<\/ver><agent><os>([^<>&]{1,128})<\/os><osVer>([^<>&]{1,128})<\/osVer><proc>([^<>&]{1,128})<\/proc><lcid>([^<>&]{1,128})<\/lcid><\/agent><\/connect>$/.exec(body.toString("ascii"));
        if (!match) throw fail();
        return { connectVersion: match[1], agent: { os: match[2], osVersion: match[3], architecture: match[4], locale: match[5] } };
      } catch {
        throw fail();
      }
    }
    module2.exports = { parseEdgeAgentMetadata };
  }
});

// src/automation/edge-calibration-relay.js
var require_edge_calibration_relay = __commonJS({
  "src/automation/edge-calibration-relay.js"(exports2, module2) {
    "use strict";
    var tls = require("node:tls");
    var { Transform } = require("node:stream");
    var { createFrameDecoder } = require_edge_wns_framing();
    var { parseEdgeClientMetadata } = require_edge_wns_client_metadata();
    var { parseEdgeAgentMetadata } = require_edge_wns_agent_metadata();
    var fail = (code) => Object.assign(new Error(code), { code });
    async function createEdgeCalibrationRelay({ pfx, passphrase, authorizePeer, connectUpstream = void 0, timeoutMs = 1e4, captureAgent = false }) {
      if (!Buffer.isBuffer(pfx) || !pfx.length || pfx.length > 65536 || typeof passphrase !== "string" || !passphrase.length || passphrase.length > 256 || typeof authorizePeer !== "function" || connectUpstream !== void 0 && typeof connectUpstream !== "function" || typeof captureAgent !== "boolean" || !Number.isSafeInteger(timeoutMs) || timeoutMs < 100 || timeoutMs > 3e4) throw fail("X_EDGE_CALIBRATION_CONFIG_INVALID");
      const clients = /* @__PURE__ */ new Set(), upstreams = /* @__PURE__ */ new Set();
      let closed = false, pending = 0, active = false, completed = false, resolveMetadata, rejectMetadata;
      const metadata = new Promise((resolve, reject) => {
        resolveMetadata = resolve;
        rejectMetadata = reject;
      });
      metadata.catch(() => {
      });
      function finishError(code) {
        if (!completed) {
          completed = true;
          rejectMetadata(fail(code));
        }
      }
      const pfxCopy = Buffer.from(pfx);
      let server;
      try {
        server = tls.createServer({ pfx: pfxCopy, passphrase, handshakeTimeout: timeoutMs, ALPNProtocols: ["h2", "http/1.1"] }, (incoming) => {
          incoming.pause();
          clients.add(incoming);
          incoming.once("close", () => clients.delete(incoming));
          incoming.on("error", () => incoming.destroy());
          if (closed || pending >= 4 || active || incoming.remoteAddress !== "127.0.0.1" || !Number.isInteger(incoming.remotePort)) {
            incoming.destroy();
            return;
          }
          pending++;
          const serverPort = server.address()?.port, clientPort = incoming.remotePort;
          let timer;
          const authTimeout = new Promise((resolve) => {
            timer = setTimeout(() => resolve(false), timeoutMs);
          });
          let onClose;
          const disconnected = new Promise((resolve) => {
            onClose = () => resolve(false);
            incoming.once("close", onClose);
          });
          Promise.race([Promise.resolve().then(() => authorizePeer({ clientPort, serverPort })).catch(() => false), authTimeout, disconnected]).then((allowed) => {
            incoming.removeListener("close", onClose);
            clearTimeout(timer);
            pending--;
            if (allowed !== true || closed || active || incoming.destroyed) {
              incoming.destroy();
              return;
            }
            active = true;
            let upstream;
            try {
              upstream = connectUpstream ? connectUpstream() : tls.connect({
                host: "client.wns.windows.com",
                port: 443,
                servername: "client.wns.windows.com",
                rejectUnauthorized: true,
                ALPNProtocols: incoming.alpnProtocol ? [incoming.alpnProtocol] : ["http/1.1"]
              });
              if (!upstream || typeof upstream.on !== "function" || typeof upstream.destroy !== "function") throw new Error();
            } catch {
              active = false;
              incoming.destroy();
              finishError("X_EDGE_CALIBRATION_CONNECT_FAILED");
              return;
            }
            upstreams.add(upstream);
            upstream.once("close", () => {
              upstreams.delete(upstream);
              active = false;
            });
            const decoder = createFrameDecoder();
            let parsed = false, connect;
            const inspect = new Transform({ transform(chunk, _encoding, done) {
              if (parsed) {
                done(null, chunk);
                return;
              }
              let frames, found;
              try {
                frames = decoder.push(chunk);
                for (const frame of frames) {
                  if (captureAgent && frame.subarray(0, 4).toString("ascii") === "CNT ") {
                    if (connect || found) throw new Error();
                    connect = parseEdgeAgentMetadata(frame);
                  }
                  if (frame.subarray(0, 4).toString("ascii") === "BND ") {
                    if (completed || found || captureAgent && !connect) throw new Error();
                    found = parseEdgeClientMetadata(frame);
                  }
                }
                if (found) {
                  parsed = true;
                  completed = true;
                  try {
                    decoder.finish();
                  } catch {
                  }
                  resolveMetadata(captureAgent ? { ...connect, client: found } : found);
                }
                done(null, chunk);
              } catch {
                done(fail("X_EDGE_CALIBRATION_PROTOCOL_INVALID"));
              } finally {
                if (frames) for (const frame of frames) frame.fill(0);
              }
            } });
            inspect.on("error", () => {
              finishError("X_EDGE_CALIBRATION_PROTOCOL_INVALID");
              incoming.destroy();
              upstream.destroy();
            });
            incoming.once("close", () => {
              try {
                decoder.finish();
              } catch {
              }
              upstream.destroy();
            });
            upstream.once("error", () => {
              finishError("X_EDGE_CALIBRATION_CONNECT_FAILED");
              incoming.destroy();
            });
            upstream.once("secureConnect", () => {
              if (closed || incoming.destroyed) {
                upstream.destroy();
                return;
              }
              incoming.pipe(inspect).pipe(upstream);
              upstream.pipe(incoming);
            });
          }).catch(() => {
            incoming.removeListener("close", onClose);
            clearTimeout(timer);
            pending--;
            incoming.destroy();
          });
        });
      } finally {
        pfxCopy.fill(0);
      }
      server.maxConnections = 8;
      server.on("tlsClientError", () => {
      });
      server.on("error", () => finishError("X_EDGE_CALIBRATION_LISTEN_FAILED"));
      try {
        await new Promise((resolve, reject) => {
          server.once("error", reject);
          server.listen({ host: "127.0.0.1", port: 0 }, () => resolve());
        });
      } catch {
        finishError("X_EDGE_CALIBRATION_LISTEN_FAILED");
        throw fail("X_EDGE_CALIBRATION_LISTEN_FAILED");
      }
      const address = server.address();
      if (!address || typeof address === "string" || address.address !== "127.0.0.1") {
        server.close();
        finishError("X_EDGE_CALIBRATION_LISTEN_FAILED");
        throw fail("X_EDGE_CALIBRATION_LISTEN_FAILED");
      }
      return Object.freeze({ port: address.port, metadata, async close() {
        if (closed) return;
        closed = true;
        finishError("X_EDGE_CALIBRATION_STOPPED");
        for (const socket of clients) socket.destroy();
        for (const socket of upstreams) socket.destroy();
        await new Promise((resolve) => server.close(resolve));
      } });
    }
    module2.exports = { createEdgeCalibrationRelay };
  }
});

// src/automation/edge-calibration-runner.js
var require_edge_calibration_runner = __commonJS({
  "src/automation/edge-calibration-runner.js"(exports2, module2) {
    "use strict";
    var fs = require("node:fs/promises");
    var path2 = require("node:path");
    var http = require("node:http");
    var { spawn } = require("node:child_process");
    var { createECDH, createHash, X509Certificate } = require("node:crypto");
    var { parseUniqueJson: parseUniqueJson2 } = require_strict_json();
    var { createChromePipe } = require_edge_cdp_pipe();
    var { createEdgeCalibrationRelay } = require_edge_calibration_relay();
    var fail = (code) => Object.assign(new Error(code), { code });
    async function checkRoot(rootPath, token) {
      if (typeof rootPath !== "string" || !path2.isAbsolute(rootPath) || typeof token !== "string" || !/^[0-9a-f]{32}$/.test(token) || path2.basename(rootPath) !== `edge-calibration-${token}`) throw fail("X_EDGE_CALIBRATION_CONFIG_INVALID");
      const root = path2.resolve(rootPath), stat = await fs.lstat(root), actual = await fs.realpath(root);
      if (stat.isSymbolicLink() || !stat.isDirectory() || (process.platform === "win32" ? actual.toLowerCase() !== root.toLowerCase() : actual !== root))
        throw fail("X_EDGE_CALIBRATION_CONFIG_INVALID");
      const markerPath = path2.join(root, "owner.json"), markerStat = await fs.lstat(markerPath);
      if (markerStat.isSymbolicLink() || !markerStat.isFile() || markerStat.size < 1 || markerStat.size > 4096) throw fail("X_EDGE_CALIBRATION_CONFIG_INVALID");
      const owner = parseUniqueJson2(await fs.readFile(markerPath, "utf8"));
      if (!owner || typeof owner !== "object" || Array.isArray(owner) || Object.keys(owner).sort().join(",") !== "appId,kind,token" || owner.appId !== "x-notification-setup" || owner.kind !== "edge-calibration-v1" || owner.token !== token) throw fail("X_EDGE_CALIBRATION_CONFIG_INVALID");
      const profile = path2.join(root, "profile"), profileStat = await fs.lstat(profile), profileActual = await fs.realpath(profile);
      if (profileStat.isSymbolicLink() || !profileStat.isDirectory() || (process.platform === "win32" ? profileActual.toLowerCase() !== profile.toLowerCase() : profileActual !== profile) || (await fs.readdir(profile)).length !== 0) throw fail("X_EDGE_CALIBRATION_CONFIG_INVALID");
      return profile;
    }
    async function runEdgeCalibration2({ rootPath, token, edgePath, pfx, passphrase, certificate, captureIdentity, authorizePeer, signal, timeoutMs = 6e4, spawnBrowser = spawn, platform = "windows" }) {
      if (!["windows", "macos"].includes(platform) || typeof edgePath !== "string" || !path2.isAbsolute(edgePath) || path2.basename(edgePath).toLowerCase() !== (platform === "macos" ? "microsoft edge" : "msedge.exe") || !Buffer.isBuffer(pfx) || !Buffer.isBuffer(certificate) || typeof captureIdentity !== "function" || typeof authorizePeer !== "function" || typeof spawnBrowser !== "function" || signal !== void 0 && !(signal instanceof AbortSignal) || !Number.isSafeInteger(timeoutMs) || timeoutMs < 1e3 || timeoutMs > 12e4) throw fail("X_EDGE_CALIBRATION_CONFIG_INVALID");
      let profile, pageServer, relay, browser, pipe, version, spki, closing;
      const controller = new AbortController();
      let abortCode = "X_EDGE_CALIBRATION_STOPPED";
      const abort = () => {
        controller.abort();
        if (browser && browser.exitCode === null && browser.signalCode === null) {
          try {
            browser.kill();
          } catch {
          }
        }
      };
      const timer = setTimeout(() => {
        abortCode = "X_EDGE_CALIBRATION_TIMEOUT";
        abort();
      }, timeoutMs);
      if (signal?.aborted) abort();
      else signal?.addEventListener("abort", abort, { once: true });
      const stopped = new Promise((_resolve, reject) => {
        if (controller.signal.aborted) reject(fail(abortCode));
        else controller.signal.addEventListener("abort", () => reject(fail(abortCode)), { once: true });
      });
      stopped.catch(() => {
      });
      const wait = (work) => Promise.race([work, stopped]);
      async function closeBrowser() {
        if (closing) return closing;
        if (!browser) return;
        const owned = browser, currentPipe = pipe;
        closing = (async () => {
          try {
            if (owned.exitCode === null && owned.signalCode === null && currentPipe) await currentPipe.closeBrowser();
          } catch {
            if (owned.exitCode === null && owned.signalCode === null) {
              let timer2, onExit;
              const exited = new Promise((resolve) => {
                onExit = resolve;
                owned.once("exit", onExit);
              });
              try {
                if (!owned.kill() && owned.exitCode === null && owned.signalCode === null) throw fail("X_EDGE_CALIBRATION_CLEANUP_FAILED");
                await Promise.race([exited, new Promise((_resolve, reject) => {
                  timer2 = setTimeout(() => reject(fail("X_EDGE_CALIBRATION_CLEANUP_FAILED")), 5e3);
                })]);
              } finally {
                clearTimeout(timer2);
                owned.removeListener("exit", onExit);
              }
            }
          } finally {
            if (browser === owned) {
              browser = null;
              pipe = null;
            }
          }
        })();
        try {
          await closing;
        } finally {
          closing = null;
        }
      }
      try {
        profile = await wait(checkRoot(rootPath, token));
        const cert = new X509Certificate(certificate);
        if (!cert.checkHost("localhost") || !cert.checkIP("127.0.0.1")) throw fail("X_EDGE_CALIBRATION_CONFIG_INVALID");
        spki = createHash("sha256").update(cert.publicKey.export({ type: "spki", format: "der" })).digest("base64");
        pageServer = http.createServer((request, response) => {
          if (request.method !== "GET" || !["/", "/sw.js"].includes(request.url)) {
            response.writeHead(404);
            response.end();
            return;
          }
          if (request.url === "/sw.js") {
            response.writeHead(200, { "content-type": "application/javascript", "cache-control": "no-store" });
            response.end('self.addEventListener("push",e=>e.waitUntil(self.registration.showNotification("fixture")))');
          } else {
            response.writeHead(200, { "content-type": "text/html", "cache-control": "no-store" });
            response.end("<!doctype html><title>Setup</title>");
          }
        });
        pageServer.maxConnections = 8;
        pageServer.on("connection", (socket) => socket.setTimeout(5e3, () => socket.destroy()));
        await wait(new Promise((resolve, reject) => {
          pageServer.once("error", reject);
          pageServer.listen({ host: "127.0.0.1", port: 0 }, resolve);
        }));
        const address = pageServer.address();
        if (!address || typeof address === "string" || address.address !== "127.0.0.1") throw fail("X_EDGE_CALIBRATION_LISTEN_FAILED");
        const origin = `http://127.0.0.1:${address.port}`;
        const key = createECDH("prime256v1");
        key.generateKeys();
        const publicKey = key.getPublicKey().toString("base64url");
        const start = (args) => {
          browser = spawnBrowser(edgePath, args, { windowsHide: true, stdio: ["ignore", "ignore", "ignore", "pipe", "pipe"] });
          if (!browser || !Number.isInteger(browser.pid) || browser.pid <= 4) throw fail("X_EDGE_CALIBRATION_BROWSER_FAILED");
          pipe = createChromePipe(browser, { origin, browserMode: "edge", calibration: true, timeoutMs: Math.min(timeoutMs, 6e4) });
          return { browser, pipe };
        };
        const common = ["--headless=new", "--remote-debugging-pipe", `--user-data-dir=${profile}`, "--no-first-run", "--no-default-browser-check", "--disable-sync"];
        const initial = start([...common, "about:blank"]);
        if (typeof initial.pipe.prepareCalibration !== "function") throw fail("X_EDGE_CALIBRATION_CONFIG_INVALID");
        version = await wait(initial.pipe.ready());
        await wait(initial.pipe.prepareCalibration(publicKey));
        await wait(closeBrowser());
        if (controller.signal.aborted) throw fail(abortCode);
        let identityPromise;
        relay = await wait(createEdgeCalibrationRelay({ pfx, passphrase, timeoutMs: Math.min(timeoutMs, 3e4), captureAgent: platform === "macos", authorizePeer: async (ports) => {
          const identity = await identityPromise;
          const identityPattern = platform === "macos" ? /^[1-9]\d{0,19}:[0-9]{6}$/ : /^\d{18}$/;
          if (controller.signal.aborted || !identity || typeof identity.startTicks !== "string" || !identityPattern.test(identity.startTicks)) return false;
          return await authorizePeer({ ...ports, browserPid: identity.pid, browserStartTicks: identity.startTicks, browserExecutable: edgePath }) === true;
        } }));
        const resumed = start([...common, `--edge-wns-push-server-url=https://127.0.0.1:${relay.port}`, `--ignore-certificate-errors-spki-list=${spki}`, "about:blank"]);
        const pid = resumed.browser.pid;
        identityPromise = Promise.resolve().then(() => captureIdentity(pid, edgePath)).then((startTicks) => ({ pid, startTicks }));
        identityPromise.catch(() => {
        });
        const secondVersion = await wait(resumed.pipe.ready());
        if (secondVersion !== version) throw fail("X_EDGE_CALIBRATION_BROWSER_CHANGED");
        const [metadata] = await wait(Promise.all([relay.metadata, identityPromise]));
        return platform === "macos" ? { browserVersion: version, connectVersion: metadata.connectVersion, agent: metadata.agent, client: metadata.client } : { browserVersion: version, client: metadata };
      } catch (error) {
        if (controller.signal.aborted) throw fail(abortCode);
        if (typeof error?.code === "string" && /^X_EDGE_CALIBRATION_[A-Z_]+$/.test(error.code)) throw error;
        throw fail("X_EDGE_CALIBRATION_FAILED");
      } finally {
        clearTimeout(timer);
        signal?.removeEventListener("abort", abort);
        let cleanupFailed = false;
        if (relay) try {
          await relay.close();
        } catch {
          cleanupFailed = true;
        }
        try {
          await closeBrowser();
        } catch {
          cleanupFailed = true;
        }
        if (pageServer) try {
          await new Promise((resolve) => {
            pageServer.close(resolve);
            pageServer.closeAllConnections?.();
          });
        } catch {
          cleanupFailed = true;
        }
        if (cleanupFailed) throw fail("X_EDGE_CALIBRATION_CLEANUP_FAILED");
      }
    }
    module2.exports = { runEdgeCalibration: runEdgeCalibration2 };
  }
});

// scripts/edge-setup-calibrate.cjs
var path = require("node:path");
var { parseUniqueJson } = require_strict_json();
var { createWindowsEdgePeerVerifier } = require_edge_windows_peer();
var { runEdgeCalibration } = require_edge_calibration_runner();
var invalid = () => Object.assign(new Error("X_EDGE_CALIBRATION_CONFIG_INVALID"), { code: "X_EDGE_CALIBRATION_CONFIG_INVALID" });
function decode(value, max) {
  if (typeof value !== "string" || !/^[A-Za-z0-9_-]+$/.test(value) || value.length > Math.ceil(max * 4 / 3)) throw invalid();
  const bytes = Buffer.from(value, "base64url");
  if (!bytes.length || bytes.length > max || bytes.toString("base64url") !== value) {
    bytes.fill(0);
    throw invalid();
  }
  return bytes;
}
async function main() {
  if (process.platform !== "win32") throw invalid();
  const chunks = [], secrets = [];
  let total = 0, combined;
  const controller = new AbortController();
  const abort = () => controller.abort();
  process.once("SIGINT", abort);
  process.once("SIGTERM", abort);
  try {
    for await (const chunk of process.stdin) {
      total += chunk.length;
      if (total > 131072) throw invalid();
      chunks.push(chunk);
    }
    combined = Buffer.concat(chunks);
    const input = parseUniqueJson(combined.toString("utf8"));
    if (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).sort().join(",") !== "certificate,edgePath,passphrase,pfx,rootPath,token") throw invalid();
    const pfx = decode(input.pfx, 65536);
    secrets.push(pfx);
    const certificate = decode(input.certificate, 8192);
    secrets.push(certificate);
    const systemRoot = process.env.SystemRoot;
    if (typeof systemRoot !== "string" || !path.isAbsolute(systemRoot)) throw invalid();
    const peer = createWindowsEdgePeerVerifier({
      powershellPath: path.join(systemRoot, "System32", "WindowsPowerShell", "v1.0", "powershell.exe"),
      helperPath: path.resolve(__dirname, "EdgePeerVerify.ps1")
    });
    if (!await peer.verifyExecutable(input.edgePath)) throw invalid();
    const result = await runEdgeCalibration({
      rootPath: input.rootPath,
      token: input.token,
      edgePath: input.edgePath,
      pfx,
      passphrase: input.passphrase,
      certificate,
      captureIdentity: peer.captureIdentity,
      authorizePeer: peer.authorizePeer,
      signal: controller.signal
    });
    process.stdout.write(JSON.stringify({ ok: true, ...result }));
  } finally {
    process.removeListener("SIGINT", abort);
    process.removeListener("SIGTERM", abort);
    combined?.fill(0);
    for (const chunk of chunks) chunk.fill(0);
    for (const item of secrets) item.fill(0);
  }
}
main().catch((error) => {
  const code = /^X_EDGE_CALIBRATION_[A-Z_]+$/.test(String(error?.code || "")) ? error.code : "X_EDGE_CALIBRATION_FAILED";
  process.stdout.write(JSON.stringify({ ok: false, errorCode: code }));
  process.exitCode = 1;
});
